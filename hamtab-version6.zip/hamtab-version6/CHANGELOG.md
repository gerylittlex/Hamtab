# CHANGELOG.md

## [1.0.0] — Full-stack rebuild

### Added
- Real backend (`server/`): Node built-in `http` router, SQLite database
  (`node:sqlite`), scrypt+HMAC auth, no external dependencies.
- Real authentication: register, login, `/me`, logout-everywhere,
  password change — replacing the hardcoded `isAuthenticated: true`.
- New pages: `pages/login.html`, `pages/register.html` (did not exist
  before).
- Real order flow: server-authoritative pricing, idempotency-key
  support, a payment adapter (dev simulator + production stub), and
  transactional order→system provisioning.
- Real persistence for profile, orders, notifications, neighborhoods,
  solar systems, and calculator history — all previously in-memory mock
  arrays that reset on refresh.
- Real controller telemetry pipeline: dev simulator clearly tagged
  `source: 'dev-simulator'`, a real `POST /api/systems/:id/ingest` entry
  point for actual hardware, and LIVE/STALE/DISCONNECTED/UNKNOWN
  connection-state detection based on data age.
- Anti-IDOR ownership checks on every user-scoped resource.
- Duplicate-neighborhood-join prevention via a DB `UNIQUE` constraint.
- Automated integration test suite (`server/tests/`, Node's built-in
  test runner, 11 tests).
- Security headers, request-size limits, path-traversal guarding, and
  rate limiting on auth endpoints.
- Documentation set: `AUDIT_REPORT.md`, `ARCHITECTURE.md`, `API.md`,
  `DATABASE.md`, `SECURITY.md`, `DEPLOYMENT.md`, `TESTING.md`,
  `FINAL_REPORT.md`.

### Changed
- `js/mock-data.js` replaced by `js/api-client.js` (same call
  signatures where practical) — every page's data now comes from the
  real backend.
- `js/pages/projects.js`: "order" buttons now create a real order and
  run it through the real (simulated) payment flow instead of showing a
  toast with no effect.
- `js/pages/dashboard.js`: profile/password forms now persist for real;
  added an auth guard (redirects to `login.html` if not authenticated).
- `js/pages/controller.js`: replaced the client-side `Math.random()`
  telemetry loop with polling of real backend data; added a real
  connection-state indicator; mode toggles and the battery-reserve
  slider now persist to the database.
- `js/pages/neighborhood.js`: join/create now call the real API, with
  real error handling for "already joined" / "already full", and
  require authentication.
- `js/navigation.js`: `applyAuthState` now reflects a real, possibly
  unauthenticated user (previously always true) and wires the new
  logout button.
- Header/mobile-nav markup on every page: added guest-only "login /
  register" link and an authenticated-only logout button.
- Package catalog moved from `js/mock-data.js` into the database,
  seeded by `server/seed.js`.

### Removed
- `js/mock-data.js` (superseded by `js/api-client.js` + the real
  backend; no longer referenced anywhere).
- Every "success" toast that previously fired without an underlying
  data change (order placement, profile save, password change,
  neighborhood join).

### Fixed (bugs found during this rebuild's own testing)
- `server/tests/`: the test suite's `npm test` script did not actually
  set `NODE_ENV=test` before Node evaluated the database module (ES
  module import ordering meant an in-line `process.env.NODE_ENV =
  "test"` inside the test helper ran too late), so tests were silently
  writing into the real development SQLite file instead of an isolated
  in-memory database — caught because running the suite surfaced
  unexplained `409`/`401` failures from cross-run data leakage. Fixed by
  setting `NODE_ENV=test` in the npm script itself.
- `solar_calculations.suggested_package_id` had a foreign-key
  constraint against `packages`, which broke the calculator on a fresh
  database with no packages seeded yet (a legitimate use case — the
  calculator should work before/without a seeded catalog). Relaxed to
  an informational column with no FK constraint.

## 2026-09-19 — Final independent audit

- Fixed open redirect on login/register redirect parameter.
- Made successful payment + system provisioning fully transactional.
- Added HTML escaping for dynamic UI strings (toasts, notifications, cards).
- Mapped toast type `error` to danger styling.
- Removed empty junk directory `server/src/{routes,services,middleware}`.
- Allowed `DB_PATH` env override for SQLite file location.
- Added FINAL_AUDIT_REPORT.md, BUG_FIX_LOG.md, TEST_RESULTS.md, PRODUCTION_READINESS.md.

## Admin panel (2026-09-19)
- Added `/api/admin/*` routes (stats, packages CRUD, orders status, users role, neighborhoods).
- Added `pages/admin.html`, `js/pages/admin.js`, `css/pages/admin.css`.
- Seed creates `admin@hamtab.local` / `Admin123!`.
- Nav shows «مدیریت» only for role ADMIN.
