# DEPLOYMENT.md

## Requirements

- **Node.js ≥ 22.5** (for `node:sqlite`; verified on 22.22.2). Pin this
  exactly in production — `node:sqlite` is still experimental and its
  behavior could change between Node versions.
- No database server, no external services required.

## Local / development

```bash
cd server
cp .env.example .env        # edit SESSION_SECRET at minimum
npm run seed                # populates packages + sample neighborhoods
npm run dev                 # NODE_ENV=development node server.js
```
Open `http://localhost:4000` (or your `PORT`). The frontend is served by
the same process — no separate frontend build/server needed.

## Production checklist

1. Set real environment variables (`server/.env`, not committed):
   - `NODE_ENV=production`
   - `SESSION_SECRET` — long random value (the process refuses to start
     without one in production)
   - `ENABLE_TELEMETRY_SIMULATOR=false` — the dev telemetry simulator
     must be off; real data should arrive via
     `POST /api/systems/:id/ingest` from actual hardware
   - `PAYMENT_PROVIDER=<real provider name>` once one is integrated —
     until then, leaving it unset/`dev-simulator` is the honest state
     for a deployment without a real payment gateway
2. `npm run seed` once against the production database.
3. Run behind a reverse proxy (nginx/Caddy) that terminates TLS — the
   app itself speaks plain HTTP. `Strict-Transport-Security` is already
   sent when `NODE_ENV=production`, but only meaningful once TLS is
   actually terminated somewhere in front of it.
4. Process manager: run `node server.js` under `systemd`, `pm2`, or a
   container restart policy — there's no built-in clustering/daemonizing.
5. **Back up `server/data/hamtab.db`** on a schedule (see
   `DATABASE.md` "Backups"). SQLite is a single file — losing the file
   loses everything, so this is not optional.
6. The in-memory rate limiter (`middleware/rate-limit.js`) and telemetry
   simulator's `setInterval` both assume a single process. If you scale
   to multiple instances behind a load balancer, move rate-limit state
   to a shared store (Redis, etc.) — noted here rather than silently
   left broken.

## Rollback

Since there's no migration numbering (see `DATABASE.md`), rolling back
code is safe (schema changes so far are additive only), but rolling back
the **database file** to an earlier backup is the only way to undo data
changes — there's no down-migration tooling.

## What's NOT set up

- CI/CD pipeline — not built; not requested, and would need a real repo
  host to hook into.
- Containerization (Dockerfile) — not built. The app has no OS-level
  dependencies beyond Node itself, so a minimal `FROM node:22-slim`
  image copying the repo and running `node server/server.js` would work,
  but wasn't created since it wasn't verified end-to-end here.
- HTTPS/TLS termination — expected to be handled by a reverse proxy, not
  the Node process itself.
