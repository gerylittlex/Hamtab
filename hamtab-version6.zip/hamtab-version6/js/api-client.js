/* =========================================================
   هم‌تاب (HamTab) — Real API client
   -----------------------------------------------------------
   Replaces the old js/mock-data.js. Same window.HamTabData
   interface where practical, so existing page scripts needed
   minimal changes, but every call now hits the real backend
   (server/) instead of an in-memory fake.
   ========================================================= */
(function (global) {
  "use strict";

  const TOKEN_KEY = "hamtab_token";

  function getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }
  function setToken(t) {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  }

  async function request(method, path, { body, idempotencyKey } = {}) {
    const headers = { "Content-Type": "application/json" };
    const token = getToken();
    if (token) headers["Authorization"] = "Bearer " + token;
    if (idempotencyKey) headers["Idempotency-Key"] = idempotencyKey;

    const res = await fetch(path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });

    let json = null;
    try {
      json = await res.json();
    } catch {
      /* empty body */
    }

    if (!res.ok) {
      const err = new Error((json && json.error) || `Request failed (${res.status})`);
      err.status = res.status;
      err.details = json && json.details;
      throw err;
    }
    return json;
  }

  let cachedUser = undefined; // undefined = not fetched yet this page load

  const api = {
    /* ---------- auth ---------- */
    async register({ name, email, phone, password }) {
      const data = await request("POST", "/api/auth/register", { body: { name, email, phone, password } });
      setToken(data.token);
      cachedUser = data.user;
      return data.user;
    },

    async login({ email, password }) {
      const data = await request("POST", "/api/auth/login", { body: { email, password } });
      setToken(data.token);
      cachedUser = data.user;
      return data.user;
    },

    async logout() {
      setToken(null);
      cachedUser = null;
    },

    async getCurrentUser() {
      if (!getToken()) {
        cachedUser = null;
        return { isAuthenticated: false, name: "", avatarInitials: "", email: "" };
      }
      if (cachedUser !== undefined) return cachedUser || { isAuthenticated: false };
      try {
        const data = await request("GET", "/api/auth/me");
        cachedUser = data.user;
        return data.user || { isAuthenticated: false, name: "", avatarInitials: "", email: "" };
      } catch {
        setToken(null);
        return { isAuthenticated: false, name: "", avatarInitials: "", email: "" };
      }
    },

    async updateProfile(payload) {
      const data = await request("PUT", "/api/profile", { body: payload });
      cachedUser = data.user;
      return data.user;
    },

    async changePassword(payload) {
      return request("PUT", "/api/profile/password", { body: payload });
    },

    /* ---------- packages ---------- */
    async getPackages() {
      const data = await request("GET", "/api/packages");
      return data.packages;
    },
    async getPackageById(id) {
      try {
        const data = await request("GET", "/api/packages/" + encodeURIComponent(id));
        return data.package;
      } catch (err) {
        if (err.status === 404) return null;
        throw err;
      }
    },

    /* ---------- calculator ---------- */
    async calculateSolarSystem(input) {
      const data = await request("POST", "/api/solar/calculate", { body: input });
      return data.result;
    },
    async simulate12MonthBill(input) {
      const data = await request("POST", "/api/solar/simulate-bill", { body: input });
      return data.simulation;
    },

    /* ---------- orders ---------- */
    async getOrders() {
      const data = await request("GET", "/api/orders");
      return data.orders;
    },
    async createOrder(packageId, address) {
      const idempotencyKey = "order-" + packageId + "-" + Date.now();
      const data = await request("POST", "/api/orders", { body: { packageId, address }, idempotencyKey });
      return data.order;
    },
    async payOrder(orderId) {
      const data = await request("POST", `/api/orders/${encodeURIComponent(orderId)}/pay`);
      return data;
    },

    /* ---------- systems / controller ---------- */
    async getPublicSystem(token) {
      const data = await request("GET", "/api/public/systems/" + encodeURIComponent(token));
      return data.system;
    },
    async getSystemQr(systemId) {
      const data = await request("GET", "/api/systems/" + encodeURIComponent(systemId) + "/qr");
      return data;
    },
    async getSystems() {
      const data = await request("GET", "/api/systems");
      return data.systems;
    },
    async getSystemWarranty(systemId) {
      const data = await request("GET", "/api/systems/" + encodeURIComponent(systemId) + "/warranty");
      return data.warranty;
    },
    async getSystemSummary() {
      const systems = await api.getSystems();
      const s = systems[0];
      if (!s) return null;
      return {
        packageName: s.packageName,
        capacityKw: s.capacityKw,
        installedOn: s.installedOn,
        totalGeneratedKwh: s.totalGeneratedKwh,
        totalSavedToman: s.totalSavedToman,
        batteryPercent: s.batteryPercent,
      };
    },
    async getControllerState() {
      const systems = await api.getSystems();
      const s = systems[0];
      if (!s) return null;
      const data = await request("GET", `/api/systems/${encodeURIComponent(s.id)}/controller`);
      const st = data.state || { solarProductionKw: 0, homeConsumptionKw: 0, batteryPercent: s.batteryPercent, gridUsageKw: 0 };
      return {
        systemId: s.id,
        solarProductionKw: st.solarProductionKw,
        homeConsumptionKw: st.homeConsumptionKw,
        batteryPercent: st.batteryPercent,
        gridUsageKw: st.gridUsageKw,
        connection: data.connection,
        energySavedTodayToman: Math.round((st.solarProductionKw || 0) * 6000),
        dailyProductionKwh: (data.hourlyProductionKw || []).reduce((a, b) => a + b, 0),
        monthlyProductionKwh: s.totalGeneratedKwh,
        batteryCharging: (st.solarProductionKw || 0) > (st.homeConsumptionKw || 0),
        batteryTimeRemaining: data.connection === "DISCONNECTED" ? "—" : "در حال محاسبه...",
        modes: data.modes || {},
        componentHealth: data.componentHealth || [],
        hourlyProduction: data.hourlyProductionKw || [],
      };
    },
    async updateSystemModes(systemId, modes) {
      const data = await request("PUT", `/api/systems/${encodeURIComponent(systemId)}/modes`, { body: modes });
      return data.modes;
    },

    /* ---------- notifications ---------- */
    async getNotifications() {
      const data = await request("GET", "/api/notifications");
      return data.notifications;
    },
    async markNotificationRead(id) {
      return request("POST", `/api/notifications/${encodeURIComponent(id)}/read`);
    },

    /* ---------- neighborhoods ---------- */
    async getNeighborhoods() {
      const data = await request("GET", "/api/neighborhoods");
      return data.neighborhoods;
    },
    async getNeighborhoodActivity() {
      const data = await request("GET", "/api/neighborhoods/activity");
      return data.activity;
    },
    async getNeighborhoodComparison() {
      const data = await request("GET", "/api/neighborhoods/comparison");
      return data.comparison;
    },
    async joinNeighborhood(id) {
      const data = await request("POST", `/api/neighborhoods/${encodeURIComponent(id)}/join`);
      return data.neighborhood;
    },
    async createNeighborhoodRequest(payload) {
      const data = await request("POST", "/api/neighborhoods", { body: payload });
      return data.neighborhood;
    },

    /* ---------- admin ---------- */
    async adminGetStats() {
      const data = await request("GET", "/api/admin/stats");
      return data.stats;
    },
    async adminGetUsers() {
      const data = await request("GET", "/api/admin/users");
      return data.users;
    },
    async adminSetUserRole(userId, role) {
      const data = await request("PATCH", "/api/admin/users/" + encodeURIComponent(userId) + "/role", {
        body: { role },
      });
      return data.user;
    },
    async adminGetPackages() {
      const data = await request("GET", "/api/admin/packages");
      return data.packages;
    },
    async adminCreatePackage(payload) {
      const data = await request("POST", "/api/admin/packages", { body: payload });
      return data.package;
    },
    async adminUpdatePackage(id, payload) {
      const data = await request("PUT", "/api/admin/packages/" + encodeURIComponent(id), { body: payload });
      return data.package;
    },
    async adminDiscontinuePackage(id) {
      const data = await request("DELETE", "/api/admin/packages/" + encodeURIComponent(id));
      return data.package;
    },
    async adminGetOrders() {
      const data = await request("GET", "/api/admin/orders");
      return data.orders;
    },
    async adminSetOrderStatus(orderId, status) {
      const data = await request("PATCH", "/api/admin/orders/" + encodeURIComponent(orderId) + "/status", {
        body: { status },
      });
      return data.order;
    },
    async adminGetNeighborhoods() {
      const data = await request("GET", "/api/admin/neighborhoods");
      return data.neighborhoods;
    },
    async adminCreateNeighborhood(payload) {
      const data = await request("POST", "/api/admin/neighborhoods", { body: payload });
      return data.neighborhood;
    },
    async adminUpdateNeighborhood(id, payload) {
      const data = await request("PUT", "/api/admin/neighborhoods/" + encodeURIComponent(id), { body: payload });
      return data.neighborhood;
    },
  

    /* ---------- bookings (site visit) ---------- */
    async getBookingSlots({ days } = {}) {
      const q = new URLSearchParams();
      if (days) q.set("days", String(days));
      const qs = q.toString() ? "?" + q.toString() : "";
      const data = await request("GET", "/api/bookings/slots" + qs);
      return data; // { days: [...] }
    },
    async createBooking(payload) {
      const data = await request("POST", "/api/bookings", { body: payload });
      return data.booking;
    },
    async getMyBookings() {
      const data = await request("GET", "/api/bookings/me");
      return data.bookings;
    },
    async adminGetBookings() {
      const data = await request("GET", "/api/bookings");
      return data.bookings;
    },
    async adminSetBookingStatus(id, status) {
      const data = await request("PATCH", "/api/bookings/" + encodeURIComponent(id) + "/status", {
        body: { status },
      });
      return data.booking;
    },

    /* ---------- energy score / referral ---------- */
    async getEnergyScore() {
      return request("GET", "/api/profile/energy-score");
    },
    async applyReferralCode(code) {
      return request("POST", "/api/profile/referral", { body: { code } });
    },

    async getWeatherOutlook({ city, days } = {}) {
      const q = new URLSearchParams();
      if (city) q.set("city", city);
      if (days) q.set("days", String(days));
      const qs = q.toString() ? "?" + q.toString() : "";
      const data = await request("GET", "/api/weather/outlook" + qs);
      return data.outlook;
    },

  };

  global.HamTabData = api;
})(window);
