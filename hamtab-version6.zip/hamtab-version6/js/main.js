/* =========================================================
   هم‌تاب (HamTab) — Main Entry Script
   Loaded on every page after api-client.js, navigation.js,
   animations.js and components.js.
   Includes Exhibition / Booth mode for fair demos.
   ========================================================= */

(function () {
  "use strict";

  var BOOTH_KEY = "hamtab_booth_mode";

  function isBoothQuery() {
    try {
      var q = new URLSearchParams(location.search);
      return q.get("mode") === "booth" || q.get("demo") === "1" || q.get("booth") === "1";
    } catch (e) {
      return false;
    }
  }

  function isBoothStored() {
    try {
      return localStorage.getItem(BOOTH_KEY) === "1";
    } catch (e) {
      return false;
    }
  }

  function setBoothStored(on) {
    try {
      if (on) localStorage.setItem(BOOTH_KEY, "1");
      else localStorage.removeItem(BOOTH_KEY);
    } catch (e) {
      /* ignore */
    }
  }

  function buildBoothChrome() {
    if (document.getElementById("boothChrome")) return;

    var bar = document.createElement("div");
    bar.id = "boothChrome";
    bar.className = "booth-chrome";
    bar.setAttribute("role", "region");
    bar.setAttribute("aria-label", "حالت نمایشگاهی");
    bar.innerHTML =
      '<div class="booth-chrome__inner">' +
      '<span class="booth-chrome__badge">حالت نمایشگاهی · DEMO</span>' +
      '<nav class="booth-chrome__nav" aria-label="مسیر دمو">' +
      '<a data-booth-link="home" href="#">خانه</a>' +
      '<a data-booth-link="calculator" href="#">محاسبه‌گر</a>' +
      '<a data-booth-link="report" href="#">گزارش</a>' +
      '<a data-booth-link="controller" href="#">کنترلر</a>' +
      '<a data-booth-link="booking" href="#">رزرو بازدید</a>' +
      "</nav>" +
      '<div class="booth-chrome__actions">' +
      '<button type="button" class="btn btn-outline btn-sm" id="boothResetBtn">ریست دمو</button>' +
      '<button type="button" class="btn btn-ghost btn-sm" id="boothExitBtn">خروج از حالت نمایشگاه</button>' +
      "</div></div>";

    document.body.appendChild(bar);

    var inPages = /\/pages\//.test(location.pathname);
    var root = inPages ? "../" : "";
    var map = {
      home: root + "index.html?mode=booth",
      calculator: root + (inPages ? "" : "pages/") + "calculator.html?mode=booth",
      report: root + (inPages ? "" : "pages/") + "report.html?mode=booth",
      controller: root + (inPages ? "" : "pages/") + "controller.html?mode=booth",
      booking: root + (inPages ? "" : "pages/") + "booking.html?mode=booth",
    };
    bar.querySelectorAll("[data-booth-link]").forEach(function (a) {
      var k = a.getAttribute("data-booth-link");
      if (map[k]) a.setAttribute("href", map[k]);
    });
    // fix reset/exit to use same root

    document.getElementById("boothResetBtn").addEventListener("click", function () {
      try {
        if (window.HamTabOffline) {
          window.HamTabOffline.clear(window.HamTabOffline.CACHE_KEYS.CONTROLLER);
          window.HamTabOffline.clear(window.HamTabOffline.CACHE_KEYS.DASHBOARD);
        }
        sessionStorage.clear();
      } catch (e) {
        /* ignore */
      }
      location.href = ( /\/pages\//.test(location.pathname) ? "../" : "" ) + "index.html?mode=booth&reset=1";
    });

    document.getElementById("boothExitBtn").addEventListener("click", function () {
      setBoothStored(false);
      var url = new URL(location.href);
      url.searchParams.delete("mode");
      url.searchParams.delete("demo");
      url.searchParams.delete("booth");
      location.href = url.pathname + (url.search || "");
    });
  }

  function initBoothMode() {
    var active = isBoothQuery() || isBoothStored();
    if (isBoothQuery()) setBoothStored(true);
    if (!active) return;

    document.body.classList.add("booth-mode");
    document.documentElement.classList.add("booth-mode");
    buildBoothChrome();

    document.querySelectorAll("[data-demo-source], .wx-panel, #weatherAlertBanner").forEach(function (el) {
      if (!el.querySelector(".demo-data-tag")) {
        var tag = document.createElement("span");
        tag.className = "demo-data-tag";
        tag.textContent = "داده نمونه / DEMO";
        el.classList.add("has-demo-tag");
        el.insertBefore(tag, el.firstChild);
      }
    });
  }

  function initSiteLoader() {
    if (document.getElementById("siteLoader")) return;
    var el = document.createElement("div");
    el.id = "siteLoader";
    el.className = "site-loader";
    el.setAttribute("aria-live", "polite");
    el.setAttribute("aria-label", "در حال بارگذاری");
    el.innerHTML =
      '<div class="site-loader__inner">' +
      '<div class="site-loader__sun" aria-hidden="true">' +
      '<span class="site-loader__ray"></span><span class="site-loader__ray"></span>' +
      '<span class="site-loader__ray"></span><span class="site-loader__ray"></span>' +
      '<span class="site-loader__ray"></span><span class="site-loader__ray"></span>' +
      '<span class="site-loader__ray"></span><span class="site-loader__ray"></span>' +
      '<span class="site-loader__core"></span></div>' +
      '<div class="site-loader__panel" aria-hidden="true">' +
      '<span class="site-loader__cell"></span><span class="site-loader__cell"></span>' +
      '<span class="site-loader__cell"></span><span class="site-loader__cell"></span>' +
      '<span class="site-loader__cell"></span><span class="site-loader__cell"></span>' +
      '<span class="site-loader__cell"></span><span class="site-loader__cell"></span></div>' +
      '<div class="site-loader__brand">هم<span>تاب</span></div>' +
      '<div class="site-loader__text">در حال آماده‌سازی پنل خورشیدی…</div></div>';
    document.body.appendChild(el);
    var hide = function () {
      el.classList.add("is-done");
    };
    if (document.readyState === "complete") setTimeout(hide, 480);
    else window.addEventListener("load", function () {
      setTimeout(hide, 480);
    });
    setTimeout(hide, 2800);
  }

  document.addEventListener("DOMContentLoaded", function () {
    initBoothMode();
    initSiteLoader();
    if (window.HamTabUI) {
      HamTabUI.initModalTriggers();
      HamTabUI.initTabs();
      HamTabUI.initDropdowns();
    }

    document.querySelectorAll("[data-toast-demo]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        HamTabUI.showToast({
          title: btn.dataset.toastTitle || "انجام شد",
          message: btn.dataset.toastMessage || "",
          type: btn.dataset.toastType || "success",
        });
      });
    });

    if (window.HamTabUI) {
      var counterEl = document.querySelector("[data-count-to]");
      if (counterEl) {
        HamTabUI.animateCounter(counterEl, parseFloat(counterEl.dataset.countTo), {
          decimals: parseInt(counterEl.dataset.decimals || "0", 10),
          suffix: counterEl.dataset.suffix || "",
        });
      }
      var barEl = document.querySelector("[data-progress-to]");
      if (barEl) HamTabUI.animateProgressBar(barEl, parseFloat(barEl.dataset.progressTo));
    }
  });
})();
