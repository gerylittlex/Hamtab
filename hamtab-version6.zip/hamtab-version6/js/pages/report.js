/* =========================================================
   HamTab — One-page solar estimate report
   ========================================================= */
(function () {
  "use strict";

  const STORAGE_KEY = "hamtab_report_payload";

  function $(id) {
    return document.getElementById(id);
  }

  function formatToman(n) {
    if (n == null || !Number.isFinite(Number(n))) return "—";
    const rounded = Math.round(Number(n) / 1000) * 1000;
    return rounded.toLocaleString("fa-IR") + " تومان";
  }

  function formatNum(n, suffix) {
    if (n == null || !Number.isFinite(Number(n))) return "—";
    return Number(n).toLocaleString("fa-IR") + (suffix ? " " + suffix : "");
  }

  function todayFa() {
    try {
      return new Intl.DateTimeFormat("fa-IR", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }).format(new Date());
    } catch {
      return new Date().toISOString().slice(0, 10);
    }
  }

  function readPayload() {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  function render(simulation, input) {
    const sizing = simulation.sizing || {};
    const annual = simulation.annual || {};
    const months = simulation.months || [];
    const assumptions = simulation.assumptions || {};

    $("reportDate").textContent = todayFa();

    $("reportKpis").innerHTML =
      kpi("ظرفیت پیشنهادی", formatNum(sizing.recommendedCapacityKw, "kW")) +
      kpi("تعداد پنل", formatNum(sizing.estimatedPanels, "عدد")) +
      kpi("پوشش انرژی", formatNum(sizing.coveragePercent, "%")) +
      kpi("پس‌انداز سالانه (تقریبی)", formatToman(annual.savingsExpectedToman));

    $("reportInputs").innerHTML =
      row("قبض ماهانه", input.monthlyBill ? formatToman(Number(input.monthlyBill)) : "—") +
      row("مصرف ماهانه", input.monthlyUsage ? formatNum(Number(input.monthlyUsage), "kWh") : "از روی قبض برآورد شده") +
      row("مساحت نصب", input.roofArea ? formatNum(Number(input.roofArea), "m²") : "—") +
      row("موقعیت", input.location || "—") +
      row("هدف استقلال", input.independence ? formatNum(Number(input.independence), "%") : "—");

    $("reportSystem").innerHTML =
      row("ظرفیت", formatNum(sizing.recommendedCapacityKw, "kW")) +
      row("پنل تخمینی", formatNum(sizing.estimatedPanels)) +
      row("تولید ماهانه میانگین", formatNum(sizing.monthlyProductionKwh, "kWh")) +
      row("باتری پیشنهادی", formatNum(sizing.batteryRecommendationKwh, "kWh")) +
      row("کد پکیج پیشنهادی", sizing.suggestedPackageId || "—");

    $("reportFinance").innerHTML =
      finCard("قبض سالانه فعلی", formatToman(annual.billCurrentToman), "") +
      finCard("با خورشیدی (مورد انتظار)", formatToman(annual.billExpectedToman), "پس‌انداز " + formatToman(annual.savingsExpectedToman)) +
      finCard("محافظه‌کارانه", formatToman(annual.billConservativeToman), "پس‌انداز " + formatToman(annual.savingsConservativeToman));

    const tbody = document.querySelector("#reportMonthTable tbody");
    tbody.innerHTML = months
      .map(
        (m) =>
          "<tr><td>" +
          (m.label || "") +
          "</td><td>" +
          formatToman(m.billCurrentToman) +
          "</td><td>" +
          formatToman(m.billExpectedToman) +
          "</td><td>" +
          formatToman(m.savingsExpectedToman) +
          "</td></tr>"
      )
      .join("");

    const ass = [];
    if (assumptions.panelWattage) ass.push("توان پنل فرضی: " + assumptions.panelWattage + " وات");
    if (assumptions.avgPeakSunHours) ass.push("ساعات اوج خورشید میانگین: " + assumptions.avgPeakSunHours + " ساعت/روز");
    if (assumptions.tariffTomanPerKwh)
      ass.push("تعرفه تقریبی: " + Number(assumptions.tariffTomanPerKwh).toLocaleString("fa-IR") + " تومان/kWh");
    if (assumptions.conservativeDerate != null)
      ass.push("سناریوی محافظه‌کارانه: حدود " + Math.round((1 - assumptions.conservativeDerate) * 100) + "% کاهش تولید");
    if (assumptions.note) ass.push(assumptions.note);
    $("reportAssumptions").innerHTML = ass.map((x) => "<li>" + x + "</li>").join("");
    $("reportDisclaimer").textContent =
      simulation.disclaimer || "ESTIMATED — این گزارش تضمین مهندسی یا مالی نیست.";

    if (sizing.suggestedPackageId) {
      $("reportPackageLink").href = "projects.html?package=" + encodeURIComponent(sizing.suggestedPackageId);
    }

    $("reportLoading").hidden = true;
    $("reportEmpty").hidden = true;
    $("reportBody").hidden = false;
  }

  function kpi(label, value) {
    return (
      '<div class="report-kpi"><span class="report-kpi__label">' +
      label +
      '</span><strong class="report-kpi__value">' +
      value +
      "</strong></div>"
    );
  }

  function row(dt, dd) {
    return "<div><dt>" + dt + "</dt><dd>" + dd + "</dd></div>";
  }

  function finCard(title, value, sub) {
    return (
      '<div class="report-fin-card"><span>' +
      title +
      "</span><strong>" +
      value +
      "</strong>" +
      (sub ? '<em>' + sub + "</em>" : "") +
      "</div>"
    );
  }

  async function boot() {
    $("reportDate").textContent = todayFa();
    const payload = readPayload();
    if (!payload || !payload.input) {
      $("reportLoading").hidden = true;
      $("reportEmpty").hidden = false;
      return;
    }

    try {
      let simulation = payload.simulation;
      if (!simulation || !simulation.annual) {
        if (!window.HamTabData || !window.HamTabData.simulate12MonthBill) {
          throw new Error("سرویس شبیه‌سازی در دسترس نیست");
        }
        simulation = await window.HamTabData.simulate12MonthBill(payload.input);
      }
      render(simulation, payload.input || {});
    } catch (err) {
      $("reportLoading").hidden = true;
      $("reportEmpty").hidden = false;
      $("reportEmpty").querySelector("p").textContent =
        err.message || "آماده‌سازی گزارش ناموفق بود. دوباره از محاسبه‌گر اقدام کنید.";
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    $("btnPrint")?.addEventListener("click", function () {
      window.print();
    });
    boot();
  });
})();
