/* =========================================================
   هم‌تاب — Solar Neighborhood Page Logic
   ========================================================= */

(function () {
  "use strict";

  function esc(v) {
    return window.HamTabUI && HamTabUI.escapeHtml ? HamTabUI.escapeHtml(v) : String(v ?? "");
  }

  function fa(n) {
    try {
      if (window.HamTabUI && typeof HamTabUI.toFa === "function") return HamTabUI.toFa(n);
    } catch (_) {}
    return String(n ?? "");
  }

  const STATUS_FA = {
    COLLECTING: "در حال جمع‌آوری",
    JUST_STARTED: "تازه شروع‌شده",
    NEARLY_COMPLETE: "نزدیک به تکمیل",
    FUNDED: "تأمین شده",
    INSTALLING: "در حال نصب",
    COMPLETED: "تکمیل‌شده",
  };

  function statusLabel(status) {
    return STATUS_FA[status] || status || "—";
  }

  function statusBadgeClass(status) {
    if (status === "NEARLY_COMPLETE" || status === "COMPLETED" || status === "FUNDED") return "badge-success";
    if (status === "JUST_STARTED" || status === "INSTALLING") return "badge-info";
    return "badge-accent";
  }

  let neighborhoods = [];

  function neighborhoodCardHTML(nb) {
    const required = Number(nb.required) || 1;
    const participants = Number(nb.participants) || 0;
    const percent = Math.min(100, Math.round((participants / required) * 100));
    const circumference = 2 * Math.PI * 30;
    const offset = circumference - (percent / 100) * circumference;
    const remaining = Math.max(0, required - participants);
    const label = statusLabel(nb.status);

    return `
      <div class="card nb-card" data-reveal data-nb-id="${esc(nb.id)}">
        <div class="nb-card__top">
          <div>
            <div class="nb-card__name">${esc(nb.name)}</div>
            <div class="nb-card__city">${esc(nb.city || "—")}</div>
          </div>
          <span class="badge ${statusBadgeClass(nb.status)}">${esc(label)}</span>
        </div>

        <div class="nb-card__progress-row">
          <svg class="nb-progress-ring" width="72" height="72" viewBox="0 0 72 72">
            <circle class="progress-ring__track" cx="36" cy="36" r="30" stroke-width="7" fill="none" />
            <circle class="progress-ring__bar" cx="36" cy="36" r="30" stroke-width="7" fill="none"
              transform="rotate(-90 36 36)"
              stroke-dasharray="${circumference}" stroke-dashoffset="${offset}" />
            <text x="36" y="41" text-anchor="middle">${fa(percent)}%</text>
          </svg>
          <div style="flex:1;">
            <div class="nb-card__count">${fa(participants)} <span>/ ${fa(required)} عضو</span></div>
            <div class="progress progress-sm" style="margin-top:6px;"><div class="progress__bar" style="width:${percent}%;"></div></div>
          </div>
        </div>

        <div class="nb-card__meta">
          <span>تخمین پنل: ${fa(nb.estimatedPanels || 0)}</span>
          <span>ظرفیت: ${fa(nb.estimatedKw || 0)} kW</span>
        </div>

        <button class="btn btn-cta btn-block" data-join-nb="${esc(nb.id)}" ${remaining === 0 || nb.joined ? "disabled" : ""}>
          ${nb.joined ? "قبلاً پیوسته‌اید" : remaining === 0 ? "ظرفیت تکمیل شد" : "پیوستن به درخواست محله"}
        </button>
      </div>
    `;
  }

  function afterRenderReveal(root) {
    if (window.HamTabAnimations && HamTabAnimations.revealNew) {
      HamTabAnimations.revealNew();
    } else if (root) {
      root.querySelectorAll("[data-reveal]").forEach((el) => el.classList.add("is-visible"));
    }
  }

  function renderNeighborhoods() {
    const grid = document.getElementById("nbGrid");
    if (!grid) return;
    if (!neighborhoods.length) {
      grid.innerHTML = HamTabUI.emptyBlockHTML({
        icon: "🏘️",
        title: "هنوز محله‌ای ثبت نشده",
        desc: "از فرم پایین یک درخواست جدید بسازید یا از پنل مدیریت اضافه کنید.",
      });
      return;
    }
    grid.innerHTML = neighborhoods.map(neighborhoodCardHTML).join("");
    bindJoinButtons();
    afterRenderReveal(grid);
  }

  function bindJoinButtons() {
    document.querySelectorAll("[data-join-nb]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const user = await window.HamTabData.getCurrentUser();
        if (!user || !user.isAuthenticated) {
          HamTabUI.showToast({ title: "ابتدا وارد حساب کاربری شوید", type: "warning" });
          location.href = "login.html?redirect=" + encodeURIComponent("pages/neighborhood.html");
          return;
        }
        btn.disabled = true;
        btn.textContent = "در حال پیوستن…";
        try {
          const updated = await window.HamTabData.joinNeighborhood(btn.dataset.joinNb);
          const idx = neighborhoods.findIndex((n) => n.id === updated.id);
          if (idx >= 0) neighborhoods[idx] = { ...neighborhoods[idx], ...updated, joined: true };
          else neighborhoods.unshift({ ...updated, joined: true });
          renderNeighborhoods();
          renderActivity();
          HamTabUI.showToast({ title: "با موفقیت به محله پیوستید", type: "success" });
        } catch (err) {
          btn.disabled = false;
          btn.textContent = "پیوستن به درخواست محله";
          HamTabUI.showToast({ title: "پیوستن انجام نشد", message: err.message, type: "error" });
        }
      });
    });
  }

  async function renderActivity() {
    const list = document.getElementById("activityList");
    if (!list) return;
    try {
      const activity = await window.HamTabData.getNeighborhoodActivity();
      list.innerHTML = activity.length
        ? activity
            .map(
              (a) => `
        <li class="activity-item">
          <span class="activity-item__dot"></span>
          <div>${esc(a.text)}<time>${esc(a.time || "")}</time></div>
        </li>`
            )
            .join("")
        : `<li>${HamTabUI.emptyBlockHTML({ icon: "📍", title: "فعالیتی ثبت نشده است." })}</li>`;
    } catch (err) {
      list.innerHTML = `<li class="text-muted">بارگذاری فعالیت‌ها ناموفق بود.</li>`;
    }
  }

  function bindCreateForm() {
    const form = document.getElementById("createNbForm");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = new FormData(form);
      const payload = {
        name: (data.get("nbName") || "").toString().trim(),
        location: (data.get("nbLocation") || "").toString().trim(),
        homes: data.get("nbHomes"),
        interestedHomes: data.get("nbInterested"),
        contact: data.get("nbContact"),
      };
      if (!payload.name || !payload.location) {
        HamTabUI.showToast({ title: "لطفاً نام و موقعیت محله را وارد کنید", type: "warning" });
        return;
      }
      const user = await window.HamTabData.getCurrentUser();
      if (!user || !user.isAuthenticated) {
        HamTabUI.showToast({ title: "برای ثبت محله باید وارد شوید", type: "warning" });
        location.href = "login.html?redirect=" + encodeURIComponent("pages/neighborhood.html");
        return;
      }
      try {
        const created = await window.HamTabData.createNeighborhoodRequest(payload);
        neighborhoods.unshift({ ...created, joined: true });
        renderNeighborhoods();
        form.reset();
        renderActivity();
        HamTabUI.showToast({
          title: "درخواست محله ثبت شد",
          message: `${created.name} به لیست اضافه شد.`,
          type: "success",
        });
      } catch (err) {
        HamTabUI.showToast({ title: "ثبت محله ناموفق بود", message: err.message, type: "error" });
      }
    });
  }

  async function init() {
    const grid = document.getElementById("nbGrid");
    const countEl = document.getElementById("nbCountLabel");
    try {
      if (!window.HamTabData) throw new Error("API client load failed");
      neighborhoods = await window.HamTabData.getNeighborhoods();
      if (!Array.isArray(neighborhoods)) neighborhoods = [];
      if (countEl) {
        countEl.textContent = neighborhoods.length
          ? `${neighborhoods.length} محله فعال`
          : "بدون محله";
      }
      renderNeighborhoods();
    } catch (err) {
      console.error(err);
      if (countEl) countEl.textContent = "خطا در بارگذاری";
      if (grid) {
        grid.innerHTML = HamTabUI.emptyBlockHTML({
          icon: "⚠️",
          title: "بارگذاری محله‌ها ناموفق بود",
          desc: "سرور را با npm run dev اجرا کنید و از http://localhost:4000 باز کنید. " + (err.message || ""),
        });
      }
      HamTabUI.showToast({ title: "خطا در دریافت محله‌ها", message: err.message, type: "error" });
    }
    renderActivity();
    bindCreateForm();
    const refreshBtn = document.getElementById("nbRefreshBtn");
    if (refreshBtn) {
      refreshBtn.addEventListener("click", async () => {
        try {
          neighborhoods = await window.HamTabData.getNeighborhoods();
          renderNeighborhoods();
          renderActivity();
          HamTabUI.showToast({ title: "لیست به‌روز شد", type: "success" });
        } catch (err) {
          HamTabUI.showToast({ title: "بارگذاری ناموفق", message: err.message, type: "error" });
        }
      });
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
