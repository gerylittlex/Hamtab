/* =========================================================
   هم‌تاب — Site visit booking page
   ========================================================= */
(function () {
  "use strict";

  const state = {
    step: 1,
    days: [],
    selectedDate: null,
    selectedSlot: null,
    selectedSlotLabel: null,
  };

  function $(id) {
    return document.getElementById(id);
  }

  function setStep(n) {
    state.step = n;
    document.querySelectorAll(".booking-step").forEach(function (el) {
      el.classList.toggle("is-active", Number(el.dataset.step) === n);
    });
    document.querySelectorAll("#bookingSteps .step-indicator__item").forEach(function (el) {
      const s = Number(el.dataset.step);
      el.classList.toggle("is-active", s === n);
      el.classList.toggle("is-done", s < n);
    });
  }

  function formatDateFa(iso) {
    try {
      const [y, m, d] = iso.split("-").map(Number);
      return new Intl.DateTimeFormat("fa-IR", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      }).format(new Date(Date.UTC(y, m - 1, d, 12)));
    } catch {
      return iso;
    }
  }

  async function loadSlots() {
    const loading = $("slotsLoading");
    const errEl = $("slotsError");
    const list = $("daysList");
    loading.hidden = false;
    errEl.hidden = true;
    list.hidden = true;
    try {
      const data = await window.HamTabData.getBookingSlots({ days: 14 });
      state.days = data.days || [];
      renderDays();
      loading.hidden = true;
      list.hidden = false;
    } catch (e) {
      loading.hidden = true;
      errEl.hidden = false;
      errEl.textContent = e.message || "بارگذاری نوبت‌ها ناموفق بود. صفحه را تازه کنید.";
    }
  }

  function renderDays() {
    const list = $("daysList");
    if (!state.days.length) {
      list.innerHTML = '<p class="text-secondary">نوبت آزادی در بازهٔ فعلی نیست.</p>';
      return;
    }

    list.innerHTML = state.days
      .map(function (day) {
        const slotsHtml = day.slots
          .map(function (s) {
            const disabled = !s.available;
            const selected =
              state.selectedDate === day.date && state.selectedSlot === s.id ? " is-selected" : "";
            return (
              '<button type="button" class="slot-chip' +
              selected +
              (disabled ? " is-disabled" : "") +
              '" data-date="' +
              day.date +
              '" data-slot="' +
              s.id +
              '" data-label="' +
              s.label +
              '"' +
              (disabled ? " disabled" : "") +
              ">" +
              s.label +
              (disabled ? " (پر)" : "") +
              "</button>"
            );
          })
          .join("");

        return (
          '<div class="day-block' +
          (day.hasAvailability ? "" : " is-empty") +
          '">' +
          '<div class="day-block__date">' +
          formatDateFa(day.date) +
          "</div>" +
          '<div class="day-block__slots">' +
          slotsHtml +
          "</div>" +
          "</div>"
        );
      })
      .join("");

    list.querySelectorAll(".slot-chip:not(.is-disabled)").forEach(function (btn) {
      btn.addEventListener("click", function () {
        state.selectedDate = btn.getAttribute("data-date");
        state.selectedSlot = btn.getAttribute("data-slot");
        state.selectedSlotLabel = btn.getAttribute("data-label");
        list.querySelectorAll(".slot-chip").forEach(function (b) {
          b.classList.toggle("is-selected", b === btn);
        });
        $("toStep2").disabled = false;
      });
    });
  }

  function validateContact() {
    const name = $("bkName").value.trim();
    const phone = $("bkPhone").value.trim();
    let ok = true;
    if (name.length < 2) {
      $("bkName").closest(".field").classList.add("has-error");
      ok = false;
    } else {
      $("bkName").closest(".field").classList.remove("has-error");
    }
    if (phone.length < 8) {
      $("bkPhone").closest(".field").classList.add("has-error");
      ok = false;
    } else {
      $("bkPhone").closest(".field").classList.remove("has-error");
    }
    return ok;
  }

  function renderSummary() {
    $("bookingSummary").innerHTML =
      "<dl class='summary-dl'>" +
      "<div><dt>تاریخ</dt><dd>" +
      formatDateFa(state.selectedDate) +
      "</dd></div>" +
      "<div><dt>بازه زمانی</dt><dd>" +
      (state.selectedSlotLabel || state.selectedSlot) +
      "</dd></div>" +
      "<div><dt>نام</dt><dd>" +
      escapeHtml($("bkName").value.trim()) +
      "</dd></div>" +
      "<div><dt>موبایل</dt><dd>" +
      escapeHtml($("bkPhone").value.trim()) +
      "</dd></div>" +
      ($("bkCity").value.trim()
        ? "<div><dt>شهر</dt><dd>" + escapeHtml($("bkCity").value.trim()) + "</dd></div>"
        : "") +
      ($("bkAddress").value.trim()
        ? "<div><dt>آدرس</dt><dd>" + escapeHtml($("bkAddress").value.trim()) + "</dd></div>"
        : "") +
      "</dl>";
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  async function submit() {
    const btn = $("submitBooking");
    const hint = $("submitHint");
    btn.disabled = true;
    hint.hidden = false;
    hint.textContent = "در حال ثبت…";
    try {
      const booking = await window.HamTabData.createBooking({
        name: $("bkName").value.trim(),
        phone: $("bkPhone").value.trim(),
        email: $("bkEmail").value.trim() || undefined,
        city: $("bkCity").value.trim() || undefined,
        address: $("bkAddress").value.trim() || undefined,
        notes: $("bkNotes").value.trim() || undefined,
        preferredDate: state.selectedDate,
        preferredSlot: state.selectedSlot,
        source: "web-booking-page",
      });
      $("bookingCard").hidden = true;
      $("bookingSteps").hidden = true;
      $("bookingSuccess").hidden = false;
      $("successDetail").textContent =
        "کد پیگیری: " +
        booking.id +
        " — " +
        formatDateFa(booking.preferredDate) +
        "، " +
        (booking.preferredSlotLabel || booking.preferredSlot);
      if (window.HamTabUI) {
        HamTabUI.showToast({ title: "رزرو ثبت شد", type: "success" });
      }
    } catch (e) {
      hint.textContent = e.message || "ثبت ناموفق بود. دوباره تلاش کنید.";
      btn.disabled = false;
      if (window.HamTabUI) {
        HamTabUI.showToast({ title: "خطا در ثبت", message: e.message, type: "error" });
      }
    }
  }

  function bind() {
    $("toStep2").addEventListener("click", function () {
      if (!state.selectedDate || !state.selectedSlot) return;
      setStep(2);
    });
    $("backTo1").addEventListener("click", function () {
      setStep(1);
    });
    $("toStep3").addEventListener("click", function () {
      if (!validateContact()) {
        if (window.HamTabUI) {
          HamTabUI.showToast({ title: "نام و موبایل الزامی است", type: "warning" });
        }
        return;
      }
      renderSummary();
      setStep(3);
    });
    $("backTo2").addEventListener("click", function () {
      setStep(2);
    });
    $("submitBooking").addEventListener("click", submit);
  }

  document.addEventListener("DOMContentLoaded", function () {
    bind();
    loadSlots();
  });
})();
