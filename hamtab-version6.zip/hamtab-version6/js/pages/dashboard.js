/* =========================================================
   هم‌تاب — User Dashboard Page Logic
   ========================================================= */

(function () {
  "use strict";

  function esc(v) { return (window.HamTabUI && HamTabUI.escapeHtml) ? HamTabUI.escapeHtml(v) : String(v ?? ""); }

  function switchSection(name) {
    document.querySelectorAll(".dash-section").forEach((el) => {
      el.classList.toggle("is-active", el.dataset.section === name);
    });
    document.querySelectorAll("[data-section-link]").forEach((el) => {
      el.classList.toggle("is-active", el.dataset.sectionLink === name);
    });
  }

  function bindSectionNav() {
    document.querySelectorAll("[data-section-link]").forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        const name = link.dataset.sectionLink;
        switchSection(name);
        history.replaceState(null, "", "#" + name);
      });
    });
    const initial = location.hash ? location.hash.slice(1) : "overview";
    switchSection(initial);
  }

  const ORDER_STATUS_FA = {
    PENDING: "در انتظار پرداخت",
    PAID: "پرداخت‌شده",
    CONFIRMED: "تأیید شده",
    SCHEDULED: "زمان‌بندی شده",
    INSTALLING: "در حال نصب",
    INSTALLED: "نصب‌شده",
    ACTIVE: "فعال",
    CANCELLED: "لغو شده",
  };
  const ORDER_STATUS_BADGE = {
    PENDING: "badge-warning",
    PAID: "badge-info",
    CONFIRMED: "badge-info",
    SCHEDULED: "badge-info",
    INSTALLING: "badge-info",
    INSTALLED: "badge-success",
    ACTIVE: "badge-success",
    CANCELLED: "badge-danger",
  };
  const PAYMENT_STATUS_FA = {
    UNPAID: "پرداخت‌نشده",
    PAID: "پرداخت‌شده",
    FAILED: "ناموفق",
    REFUNDED: "بازگردانده‌شده",
  };

  function orderStatusBadge(status) {
    return `<span class="badge ${ORDER_STATUS_BADGE[status] || ""}">${ORDER_STATUS_FA[status] || status}</span>`;
  }
  function paymentLabel(payment) {
    return PAYMENT_STATUS_FA[payment] || payment;
  }

  
  function formatDateFa(iso) {
    if (!iso) return "—";
    try {
      const [y, m, d] = String(iso).split("-").map(Number);
      return new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "long", day: "numeric" }).format(new Date(Date.UTC(y, m - 1, d, 12)));
    } catch { return iso; }
  }
  async function renderWarranty() {
    const host = document.getElementById("warrantyList");
    if (!host) return;
    let systems = [];
    try {
      systems = await window.HamTabData.getSystems();
    } catch (e) {
      host.innerHTML = '<div class="card" style="padding:20px">خطا: ' + esc(e.message || "") + "</div>";
      return;
    }
    if (!systems.length) {
      host.innerHTML =
        '<div class="card" style="padding:24px"><h3 style="margin-top:0">هنوز سیستم فعالی ندارید</h3><p class="text-secondary" style="font-size:var(--fs-sm)">بعد از سفارش و پرداخت (یا تأیید ادمین)، گارانتی اینجا می‌آید.</p><a class="btn btn-cta btn-sm" href="projects.html">پکیج‌ها</a></div>';
      return;
    }
    const labels = {
      panels: "پنل‌ها",
      inverter: "اینورتر",
      battery: "باتری",
      workmanship: "نصب و اجرا",
      monitoring: "مانیتورینگ",
    };
    const cards = [];
    for (const s of systems) {
      let w = null;
      try {
        if (window.HamTabData.getSystemWarranty) w = await window.HamTabData.getSystemWarranty(s.id);
      } catch (e) {}
      if (!w && s.warranty) {
        w = {
          warrantyCode: s.warranty.code,
          serialNumber: s.warranty.serialNumber,
          status: s.warranty.status,
          endsOn: s.warranty.endsOn,
          years: s.warranty.years,
          startsOn: s.installedOn,
          packageName: s.packageName,
          capacityKw: s.capacityKw,
          coverage: {
            panels: "۱۰ سال",
            inverter: "۵ سال",
            battery: "۵ سال",
            workmanship: "۲ سال",
            monitoring: "۱ سال",
          },
          disclaimer: "کارت گارانتی دیجیتال هم‌تاب.",
        };
      }
      if (!w || !w.warrantyCode) {
        cards.push(
          '<div class="card" style="padding:16px;margin-bottom:12px">سیستم ' +
            esc(s.packageName) +
            " — گارانتی در دسترس نیست.</div>"
        );
        continue;
      }

      let qrBlock = "";
      try {
        if (window.HamTabData.getSystemQr) {
          const qr = await window.HamTabData.getSystemQr(s.id);
          const path = qr.path || ("/pages/system.html?t=" + encodeURIComponent(qr.publicToken || ""));
          const abs =
            location.origin +
            (path.startsWith("/") ? path : "/" + path);
          let qrImg = "";
          try {
            if (typeof qrcode === "function") {
              const qr = qrcode(4, "L");
              qr.addData(abs);
              qr.make();
              qrImg = qr.createDataURL(4, 6);
            }
          } catch (qrErr) {
            console.warn(qrErr);
          }
          if (!qrImg) {
            // last-resort: draw placeholder (link still works)
            qrImg = "";
          }
          qrBlock =
            '<div class="warranty-qr" style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin:14px 0;padding:12px;border:1px dashed var(--border-color);border-radius:12px;">' +
            '<img src="' +
            qrImg +
            '" width="120" height="120" alt="QR سیستم" style="border-radius:8px;background:#fff;' + (qrImg ? '' : 'display:none;') + '" />' +
            (qrImg ? '' : '<div style="width:120px;height:120px;border:1px dashed #ccc;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#8792a3;text-align:center;padding:8px">لینک زیر را کپی کنید</div>') +
            "<div style=\"font-size:var(--fs-sm);\"><strong>QR فیزیکی سیستم</strong>" +
            '<p class="text-muted" style="margin:4px 0 8px;font-size:var(--fs-xs);">برای نصب روی تابلو/پنل. صفحه عمومی بدون اطلاعات شخصی مالک باز می‌شود.</p>' +
            '<a class="btn btn-outline btn-sm" href="' +
            esc(path) +
            '" target="_blank" rel="noopener">پیش‌نمایش صفحه عمومی</a> ' +
            '<button type="button" class="btn btn-ghost btn-sm" data-copy-qr="' +
            esc(abs) +
            '">کپی لینک</button></div></div>';
        }
      } catch (e) {
        console.warn("qr", e);
      }

      const statusFa = w.status === "EXPIRED" ? "منقضی" : "فعال";
      const cov = Object.entries(w.coverage || {})
        .map(function (pair) {
          return (
            '<div class="warranty-cov"><span>' +
            (labels[pair[0]] || pair[0]) +
            "</span><strong>" +
            esc(pair[1]) +
            "</strong></div>"
          );
        })
        .join("");
      cards.push(
        '<article class="warranty-card ' +
          (w.status === "EXPIRED" ? "is-expired" : "is-active") +
          '"><div class="warranty-card__top"><div><div class="warranty-card__brand">هم‌تاب · گارانتی دیجیتال</div><h2 class="warranty-card__title">' +
          esc(w.packageName || s.packageName) +
          '</h2><p class="warranty-card__sub">' +
          esc(w.capacityKw || s.capacityKw) +
          " kW · سریال " +
          esc(w.serialNumber || "—") +
          '</p></div><div class="warranty-card__badge">' +
          statusFa +
          '</div></div><div class="warranty-card__code">کد گارانتی: <strong>' +
          esc(w.warrantyCode) +
          "</strong></div><div class=\"warranty-card__dates\"><div><span>شروع</span><strong>" +
          formatDateFa(w.startsOn || s.installedOn) +
          "</strong></div><div><span>پایان</span><strong>" +
          formatDateFa(w.endsOn) +
          "</strong></div><div><span>مدت</span><strong>" +
          esc(w.years || 10) +
          ' سال</strong></div></div><div class="warranty-card__coverage">' +
          cov +
          "</div>" +
          qrBlock +
          '<p class="warranty-card__disclaimer">' +
          esc(w.disclaimer || "") +
          '</p><div class="warranty-card__actions"><button type="button" class="btn btn-outline btn-sm" data-print-warranty>چاپ کارت</button></div></article>'
      );
    }
    host.innerHTML = cards.join("");
    host.querySelectorAll("[data-print-warranty]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const card = btn.closest(".warranty-card");
        if (!card) return;
        printWarrantyCard(card);
      });
    });
    host.querySelectorAll("[data-copy-qr]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const url = btn.getAttribute("data-copy-qr");
        if (navigator.clipboard && url) {
          navigator.clipboard.writeText(url).then(function () {
            if (window.HamTabUI) HamTabUI.showToast({ title: "لینک کپی شد", type: "success" });
          });
        }
      });
    });
  }

  /** Reliable print via hidden iframe (fixes noopener / silent popup failure). */
  function printWarrantyCard(card) {
    const clone = card.cloneNode(true);
    const actions = clone.querySelector(".warranty-card__actions");
    if (actions) actions.remove();

    const css = [
      "*{box-sizing:border-box}",
      "body{font-family:Tahoma,Vazirmatn,sans-serif;padding:24px;margin:0;color:#101a2e;background:#fff}",
      ".warranty-card{background:#fff;border:2px solid #1b2a4a;border-radius:16px;padding:28px;max-width:560px;margin:0 auto;position:relative;overflow:hidden}",
      ".warranty-card::before{content:'';position:absolute;top:0;right:0;left:0;height:4px;background:linear-gradient(90deg,#1b2a4a,#d97b3f)}",
      ".warranty-card__top{display:flex;justify-content:space-between;gap:12px;margin-bottom:12px}",
      ".warranty-card__brand{font-size:11px;color:#8792a3;margin-bottom:4px}",
      ".warranty-card__title{margin:0 0 4px;font-size:1.25rem}",
      ".warranty-card__sub{margin:0;font-size:13px;color:#4c5a73}",
      ".warranty-card__badge{padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600;background:#e4f4ec;color:#2e8b57;height:fit-content}",
      ".warranty-card.is-expired .warranty-card__badge{background:#fbe7e3;color:#c24435}",
      ".warranty-card__code{background:#f8fafc;border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:14px}",
      ".warranty-card__dates{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px;font-size:13px}",
      ".warranty-card__dates span{display:block;font-size:11px;color:#8792a3}",
      ".warranty-cov{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px dashed #e2e8f0;font-size:13px}",
      ".warranty-card__disclaimer{font-size:11px;color:#8792a3;margin:14px 0 0}",
      "@media print{body{padding:0}.warranty-card{box-shadow:none;page-break-inside:avoid}}",
    ].join("");

    const html =
      "<!DOCTYPE html><html lang=\"fa\" dir=\"rtl\"><head><meta charset=\"UTF-8\" />" +
      "<title>کارت گارانتی هم‌تاب</title><style>" +
      css +
      "</style></head><body>" +
      clone.outerHTML +
      "</body></html>";

    try {
      const iframe = document.createElement("iframe");
      iframe.setAttribute("aria-hidden", "true");
      iframe.style.cssText =
        "position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none";
      document.body.appendChild(iframe);

      const doc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document);
      if (!doc) {
        document.body.removeChild(iframe);
        throw new Error("print-frame-unavailable");
      }
      doc.open();
      doc.write(html);
      doc.close();

      const doPrint = function () {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } catch (err) {
          console.warn(err);
          if (window.HamTabUI) {
            HamTabUI.showToast({
              title: "چاپ انجام نشد",
              message: "لطفاً دوباره تلاش کنید یا از میانبر چاپ مرورگر استفاده کنید.",
              type: "error",
            });
          }
        }
        setTimeout(function () {
          if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
        }, 1500);
      };

      setTimeout(doPrint, 300);
    } catch (e) {
      console.warn(e);
      if (window.HamTabUI) {
        HamTabUI.showToast({
          title: "چاپ انجام نشد",
          message: "مرورگر اجازه چاپ نداد. صفحه را رفرش کنید و دوباره امتحان کنید.",
          type: "error",
        });
      }
    }
  }



  function fallbackScoreFromSystems(systems) {
    const list = systems || [];
    const totalKwh = list.reduce(function (a, s) { return a + (Number(s.totalGeneratedKwh) || 0); }, 0);
    const fromSystems = Math.min(300, list.length * 100);
    const fromEnergy = Math.min(500, Math.floor(totalKwh / 10));
    const score = fromSystems + fromEnergy;
    let level = { id: "bronze", label: "برنزی" };
    if (score >= 800) level = { id: "platinum", label: "پلاتین" };
    else if (score >= 400) level = { id: "gold", label: "طلایی" };
    else if (score >= 150) level = { id: "silver", label: "نقره‌ای" };
    return {
      score: score,
      level: level,
      breakdown: { systems: fromSystems, energy: fromEnergy, referrals: 0, bonus: 0 },
      referralCode: null,
      _fallback: true,
    };
  }

  async function renderEnergyScore() {
    const card = document.getElementById("energyScoreCard");
    if (!card) return;
    const scoreEl = document.getElementById("energyScoreValue");
    const levelEl = document.getElementById("energyScoreLevel");
    const breakEl = document.getElementById("energyScoreBreakdown");
    const refEl = document.getElementById("energyScoreReferral");
    let data = null;
    try {
      if (window.HamTabData.getEnergyScore) {
        data = await window.HamTabData.getEnergyScore();
      }
    } catch (e) {
      console.warn("energy score api", e);
      try {
        const systems = await window.HamTabData.getSystems();
        data = fallbackScoreFromSystems(systems);
      } catch (e2) {
        console.warn(e2);
      }
    }
    if (!data) {
      if (scoreEl) scoreEl.textContent = "۰";
      if (levelEl) levelEl.textContent = "—";
      if (breakEl) {
        breakEl.innerHTML =
          '<p class="text-muted" style="margin:0;font-size:var(--fs-sm);grid-column:1/-1;">برای دیدن امتیاز وارد حساب شوید. اگر وارد هستید، سرور را ریستارت کنید.</p>';
      }
      return;
    }
    try {
      if (scoreEl) HamTabUI.animateCounter(scoreEl, data.score || 0, { decimals: 0 });
      if (levelEl) levelEl.textContent = (data.level && data.level.label) || "برنزی";
      if (breakEl && data.breakdown) {
        const b = data.breakdown;
        const items = [
          ["سیستم‌ها", b.systems],
          ["تولید انرژی", b.energy],
          ["معرفی", b.referrals],
          ["ویژه", b.bonus],
        ];
        breakEl.innerHTML = items
          .map(function (pair) {
            return (
              '<div class="card" style="padding:10px 12px;text-align:center;box-shadow:none;border:1px solid var(--border-color);">' +
              '<div style="font-size:var(--fs-xs);color:var(--text-muted);margin-bottom:4px;">' +
              pair[0] +
              "</div><strong style=\"font-size:var(--fs-md);\">" +
              HamTabUI.toFa(pair[1] || 0) +
              "</strong></div>"
            );
          })
          .join("");
      }
      if (refEl) {
        if (data.referralCode) {
          const code = data.referralCode;
          refEl.innerHTML =
            '<div class="flex-between" style="gap:12px;flex-wrap:wrap;align-items:center;">' +
            "<div><strong>کد معرفی شما:</strong> <code style=\"letter-spacing:0.06em;font-size:1rem;\">" +
            code +
            "</code>" +
            '<p class="text-muted" style="margin:4px 0 0;font-size:var(--fs-xs);">با اشتراک‌گذاری این کد، پس از نصب سیستم همسایه امتیاز می‌گیرید.</p></div>' +
            '<button type="button" class="btn btn-outline btn-sm" id="btnCopyReferral">کپی کد</button></div>';
          const btn = document.getElementById("btnCopyReferral");
          if (btn) {
            btn.addEventListener("click", function () {
              if (navigator.clipboard && code) {
                navigator.clipboard.writeText(code).then(function () {
                  HamTabUI.showToast({ title: "کد کپی شد", type: "success" });
                });
              }
            });
          }
        } else if (data._fallback) {
          refEl.innerHTML =
            '<p class="text-muted" style="margin:0;font-size:var(--fs-xs);">امتیاز از دادهٔ سیستم‌های شما محاسبه شد (حالت پشتیبان).</p>';
        }
      }
    } catch (e) {
      console.warn("energy score render", e);
    }
  }

  async function renderOverview() {
    const [summary, orders, notifications] = await Promise.all([
      window.HamTabData.getSystemSummary(),
      window.HamTabData.getOrders(),
      window.HamTabData.getNotifications(),
    ]);

    HamTabUI.animateCounter(document.getElementById("ovGenerated"), summary ? summary.totalGeneratedKwh : 0, { decimals: 0, suffix: " kWh" });
    document.getElementById("ovSaved").textContent = HamTabUI.formatToman(summary ? summary.totalSavedToman : 0);
    document.getElementById("ovPackage").textContent = summary ? summary.packageName : "هنوز سیستمی ثبت نشده";
    document.getElementById("ovBattery").textContent = summary ? HamTabUI.toFa(summary.batteryPercent) + "٪" : "—";

    const emptyHost = document.getElementById("dashSystemsEmpty");
    if (emptyHost) {
      if (!summary) {
        emptyHost.innerHTML = `<div class="card" style="padding:24px;margin-bottom:16px">
          <h3 style="margin-top:0">مسیر روز اول</h3>
          <p class="text-secondary" style="font-size:var(--fs-sm)">هنوز سیستمی فعال نیست. این ترتیب را پیشنهاد می‌کنیم:</p>
          <ol style="font-size:var(--fs-sm);color:var(--text-secondary);line-height:1.8">
            <li>محاسبه ظرفیت در محاسبه‌گر</li>
            <li>انتخاب پکیج و ثبت سفارش</li>
            <li>پیگیری وضعیت از بخش سفارش‌ها</li>
            <li>پس از نصب، پایش از کنترلر هوشمند</li>
          </ol>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
            <a class="btn btn-cta btn-sm" href="calculator.html">محاسبه</a>
            <a class="btn btn-outline btn-sm" href="projects.html">پکیج‌ها</a>
          </div>
        </div>`;
      } else {
        emptyHost.innerHTML = "";
      }
    }

    const ring = document.getElementById("ovBatteryRing");
    HamTabUI.animateProgressRing(ring, summary ? summary.batteryPercent : 0, 44);

    const latestOrder = orders[orders.length - 1];
    document.getElementById("ovRecentOrder").innerHTML = latestOrder
      ? `<strong>${esc(latestOrder.packageName)}</strong><p class="text-muted" style="font-size:var(--fs-xs);margin-top:4px;">${latestOrder.date}</p>${orderStatusBadge(latestOrder.status)}`
      : HamTabUI.stateBlockHTML({ icon: "🧾", title: "هنوز سفارشی ثبت نکرده‌اید." });

    
    try {
      if (window.HamTabData.getWeatherOutlook) {
        const outlook = await window.HamTabData.getWeatherOutlook({ days: 3 });
        const host = document.getElementById("dashWeather");
        if (host && outlook) {
          const s = outlook.summary || {};
          host.hidden = false;
          const impact = s.worstImpactPercent || 0;
          host.innerHTML = '<div class="dash-wx"><div class="dash-wx__top"><div><span class="dash-wx__eye">آب‌وهوا و تولید</span><strong>' + (s.hasAlert ? (s.worstConditionFa || "هشدار") : "شرایط نسبتاً مناسب") + '</strong></div><span class="dash-wx__badge">' + (impact === 0 ? "۰٪ افت" : impact + "٪") + '</span></div><p class="dash-wx__body">' + (s.hasAlert ? "بدترین روز " + (s.worstDay || "") + " — حدود " + Math.abs(impact) + "٪ افت تولید تخمینی نسبت به روز صاف." : "در ۳ روز آینده افت جدی تولید پیش‌بینی نشده (مدل تخمینی).") + '</p><a href="controller.html" class="btn btn-outline btn-sm">جزئیات در کنترلر</a></div>';
        }
      }
    } catch (e) { console.warn(e); }

    await renderEnergyScore();
    await renderNeighborhoodComparison();

    const notifList = document.getElementById("notifList");
    notifList.innerHTML = notifications.length
      ? notifications
          .map(
            (n) => `
        <div class="notif-item">
          <span class="notif-dot ${n.type}"></span>
          <div style="flex:1;">
            <strong>${esc(n.title)}</strong>
            <p>${esc(n.body)}</p>
          </div>
          <time>${n.time}</time>
        </div>`
          )
          .join("")
      : HamTabUI.stateBlockHTML({ icon: "🔔", title: "اعلانی وجود ندارد." });
  }

  async function renderOrders() {
    const orders = await window.HamTabData.getOrders();
    const tableWrap = document.getElementById("ordersTableWrap");
    const cardsWrap = document.getElementById("ordersCardsWrap");

    if (!orders.length) {
      const empty = HamTabUI.stateBlockHTML({ icon: "🧾", title: "هنوز سفارشی ثبت نکرده‌اید.", desc: "پس از خرید پکیج، سفارش شما اینجا نمایش داده می‌شود." });
      tableWrap.innerHTML = empty;
      cardsWrap.innerHTML = "";
      return;
    }

    tableWrap.innerHTML = `
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>شماره سفارش</th><th>محصول / پکیج</th><th>تاریخ</th><th>مبلغ</th><th>وضعیت</th><th>پرداخت</th><th></th></tr></thead>
          <tbody>
            ${orders
              .map(
                (o) => `
              <tr>
                <td>${o.id}</td>
                <td>${esc(o.packageName)}</td>
                <td>${o.date}</td>
                <td>${HamTabUI.formatToman(o.price)}</td>
                <td>${orderStatusBadge(o.status)}</td>
                <td>${paymentLabel(o.payment)}</td>
                <td><button class="btn btn-ghost btn-sm" data-order-detail="${o.id}">جزئیات</button></td>
              </tr>`
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `;

    cardsWrap.innerHTML = orders
      .map(
        (o) => `
      <div class="table-card">
        <div class="flex-between" style="margin-bottom:8px;">
          <strong>${esc(o.packageName)}</strong>
          ${orderStatusBadge(o.status)}
        </div>
        <div class="table-card__row"><span>شماره سفارش</span><span>${o.id}</span></div>
        <div class="table-card__row"><span>تاریخ</span><span>${o.date}</span></div>
        <div class="table-card__row"><span>مبلغ</span><span>${HamTabUI.formatToman(o.price)}</span></div>
        <div class="table-card__row"><span>پرداخت</span><span>${paymentLabel(o.payment)}</span></div>
        <button class="btn btn-outline btn-sm btn-block" style="margin-top:8px;" data-order-detail="${o.id}">جزئیات</button>
      </div>`
      )
      .join("");

    document.querySelectorAll("[data-order-detail]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const order = orders.find((o) => o.id === btn.dataset.orderDetail);
        const modal = document.getElementById("orderDetailModal");
        modal.querySelector("[data-od-id]").textContent = order.id;
        modal.querySelector("[data-od-package]").textContent = order.packageName;
        modal.querySelector("[data-od-date]").textContent = order.date;
        modal.querySelector("[data-od-price]").textContent = HamTabUI.formatToman(order.price);
        modal.querySelector("[data-od-status]").innerHTML = orderStatusBadge(order.status);
        modal.querySelector("[data-od-payment]").textContent = paymentLabel(order.payment);
        HamTabUI.openModal(modal);
      });
    });
  }

  function bindProfileForm() {
    const form = document.getElementById("profileForm");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        await window.HamTabData.updateProfile({
          name: document.getElementById("profileName").value,
          phone: document.getElementById("profilePhone").value,
          address: document.getElementById("profileAddress").value,
          installLocation: document.getElementById("profileLocation").value,
        });
        HamTabUI.showToast({ title: "پروفایل به‌روزرسانی شد", type: "success" });
      } catch (err) {
        HamTabUI.showToast({ title: "به‌روزرسانی ناموفق بود", message: err.message, type: "error" });
      }
    });
  }

  function bindSettingsForm() {
    const form = document.getElementById("passwordForm");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const currentPassword = document.getElementById("currentPassword").value;
      const newPassword = document.getElementById("newPassword").value;
      try {
        await window.HamTabData.changePassword({ currentPassword, newPassword });
        HamTabUI.showToast({ title: "رمز عبور تغییر کرد", type: "success" });
        form.reset();
      } catch (err) {
        HamTabUI.showToast({ title: "تغییر رمز عبور ناموفق بود", message: err.message, type: "error" });
      }
    });
    const logoutBtn = document.getElementById("logoutEverywhereBtn");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", async () => {
        await window.HamTabData.logout();
        location.href = "login.html";
      });
    }
  }

  async function loadUser() {
    const user = await window.HamTabData.getCurrentUser();
    document.getElementById("profileName").value = user.name;
    document.getElementById("profileEmail").value = user.email;
    document.getElementById("profilePhone").value = user.phone;
    document.getElementById("profileAddress").value = user.address;
    document.getElementById("profileLocation").value = user.installLocation;
  }

  document.addEventListener("DOMContentLoaded", async () => {
    const user = await window.HamTabData.getCurrentUser();
    if (!user || !user.isAuthenticated) {
      location.href = "login.html?redirect=" + encodeURIComponent("pages/dashboard.html");
      return;
    }

    // Role label under name
    document.querySelectorAll(".dash-profile span").forEach((el) => {
      if (user.role === "ADMIN") el.textContent = "مدیر سیستم";
      else el.textContent = "حساب کاربری";
    });

    bindSectionNav();
    bindProfileForm();
    bindSettingsForm();
    await Promise.all([renderOverview(), renderOrders(), renderWarranty(), loadUser()]);

    // Open admin hub from #admin-hub (merged panel)
    if (location.hash.startsWith("#admin-") && user.role === "ADMIN") {
      const sec = location.hash.slice(1);
      switchSection(sec);
    }
  });
})();
