/* =========================================================
   هم‌تاب — Solar Calculator Page Logic
   Includes: sizing result + 12-month bill sim + report payload
   ========================================================= */

(function () {
  "use strict";

  const REPORT_KEY = "hamtab_report_payload";
  const state = { step: 1, totalSteps: 3, result: null, simulation: null, input: null };

  const stepEls = () => document.querySelectorAll(".calc-step");
  const indicatorItems = () => document.querySelectorAll(".step-indicator__item");

  function renderStep() {
    stepEls().forEach((el) => el.classList.toggle("is-active", Number(el.dataset.step) === state.step));
    indicatorItems().forEach((el) => {
      const n = Number(el.dataset.step);
      el.classList.toggle("is-active", n === state.step);
      el.classList.toggle("is-done", n < state.step);
    });

    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    if (prevBtn) prevBtn.style.visibility = state.step === 1 ? "hidden" : "visible";
    if (nextBtn) nextBtn.textContent = state.step === state.totalSteps ? "محاسبه کن" : "مرحله بعد";
  }

  function validateStep(stepNum) {
    const stepEl = document.querySelector(`.calc-step[data-step="${stepNum}"]`);
    if (!stepEl) return true;
    let valid = true;
    stepEl.querySelectorAll("[required]").forEach((input) => {
      const field = input.closest(".field");
      const isEmpty = !input.value || (input.type === "number" && Number(input.value) <= 0);
      if (field) field.classList.toggle("has-error", isEmpty);
      if (isEmpty) valid = false;
    });
    return valid;
  }

  function collectInput() {
    const form = document.getElementById("calcForm");
    const data = new FormData(form);
    return {
      monthlyBill: data.get("monthlyBill"),
      monthlyUsage: data.get("monthlyUsage"),
      location: data.get("location"),
      roofArea: data.get("roofArea"),
      independence: data.get("independence"),
      appliances: data.getAll("appliances"),
    };
  }

  function formatToman(n) {
    if (n == null || !Number.isFinite(Number(n))) return "—";
    const rounded = Math.round(Number(n) / 1000) * 1000;
    return rounded.toLocaleString("fa-IR") + " تومان";
  }

  function formatKwh(n) {
    if (n == null || !Number.isFinite(Number(n))) return "—";
    return Math.round(Number(n)).toLocaleString("fa-IR") + " kWh";
  }

  function persistReportPayload(input, result, simulation) {
    try {
      sessionStorage.setItem(
        REPORT_KEY,
        JSON.stringify({
          input: input,
          result: result,
          simulation: simulation || null,
          savedAt: Date.now(),
        })
      );
    } catch (e) {
      console.warn("report payload save failed", e);
    }
  }

  async function runCalculation() {
    document.getElementById("calcCard").style.display = "none";
    const loading = document.getElementById("calcLoading");
    loading.classList.add("is-active");

    const input = collectInput();
    try {
      const result = await window.HamTabData.calculateSolarSystem(input);
      state.result = result;
      state.input = input;

      loading.classList.remove("is-active");
      renderResults(result);

      // 12-month simulation (additive)
      let simulation = null;
      try {
        if (window.HamTabData.simulate12MonthBill) {
          simulation = await window.HamTabData.simulate12MonthBill(input);
          state.simulation = simulation;
          renderBillSimulation(simulation);
        }
      } catch (simErr) {
        console.warn("12-month simulation failed", simErr);
        if (window.HamTabUI) {
          HamTabUI.showToast({
            title: "شبیه‌ساز ۱۲ماهه در دسترس نیست",
            message: simErr.message || "",
            type: "warning",
          });
        }
      }

      persistReportPayload(input, result, simulation);
    } catch (err) {
      loading.classList.remove("is-active");
      document.getElementById("calcCard").style.display = "";
      if (window.HamTabUI) {
        HamTabUI.showToast({
          title: "خطا در محاسبه",
          message: err.message || "لطفاً دوباره تلاش کنید",
          type: "error",
        });
      }
    }
  }

  function renderResults(result) {
    const resultsEl = document.getElementById("calcResults");
    resultsEl.classList.add("is-active");

    const setCounter = (id, value, opts) => {
      const el = document.getElementById(id);
      if (el && window.HamTabUI && HamTabUI.animateCounter) HamTabUI.animateCounter(el, value, opts || {});
      else if (el) el.textContent = value;
    };

    setCounter("resDailyConsumption", result.dailyConsumptionKwh, { decimals: 1, suffix: " kWh" });
    setCounter("resMonthlyConsumption", result.monthlyConsumptionKwh, { decimals: 0, suffix: " kWh" });
    setCounter("resCapacity", result.recommendedCapacityKw, { decimals: 1, suffix: " kW" });
    setCounter("resPanels", result.estimatedPanels, { decimals: 0 });
    setCounter("resProduction", result.monthlyProductionKwh, { decimals: 0, suffix: " kWh" });
    setCounter("resBattery", result.batteryRecommendationKwh, { decimals: 0, suffix: " kWh" });

    const ringValueEl = document.getElementById("resCoverageValue");
    if (ringValueEl && window.HamTabUI && HamTabUI.animateCounter) {
      HamTabUI.animateCounter(ringValueEl, result.coveragePercent, { decimals: 0, suffix: "%" });
    }
    const ringCircle = document.getElementById("resCoverageRing");
    if (ringCircle && window.HamTabUI && HamTabUI.animateProgressRing) {
      HamTabUI.animateProgressRing(ringCircle, result.coveragePercent, 52);
    }

    const orderBtn = document.getElementById("orderPackageBtn");
    if (orderBtn) orderBtn.href = "projects.html?package=" + encodeURIComponent(result.suggestedPackageId || "");

    const shareEl = document.getElementById("calcShareSummary");
    if (shareEl) {
      shareEl.textContent =
        "ظرفیت پیشنهادی " +
        result.recommendedCapacityKw +
        " kW · حدود " +
        result.estimatedPanels +
        " پنل · پوشش " +
        result.coveragePercent +
        "%";
    }
  }

  function renderBillSimulation(sim) {
    const section = document.getElementById("billSimSection");
    if (!section || !sim) return;
    section.hidden = false;

    const annual = sim.annual || {};
    const summaryEl = document.getElementById("billSimSummary");
    if (summaryEl) {
      summaryEl.innerHTML =
        '<div class="bill-sim__card bill-sim__card--current">' +
        '<div class="bill-sim__card-label">قبض سالانه فعلی (تخمینی)</div>' +
        '<div class="bill-sim__card-value">' +
        formatToman(annual.billCurrentToman) +
        "</div></div>" +
        '<div class="bill-sim__card bill-sim__card--expected">' +
        '<div class="bill-sim__card-label">با خورشیدی — مورد انتظار</div>' +
        '<div class="bill-sim__card-value">' +
        formatToman(annual.billExpectedToman) +
        "</div>" +
        '<div class="bill-sim__card-delta">پس‌انداز تقریبی ' +
        formatToman(annual.savingsExpectedToman) +
        "</div></div>" +
        '<div class="bill-sim__card bill-sim__card--conservative">' +
        '<div class="bill-sim__card-label">سناریوی محافظه‌کارانه</div>' +
        '<div class="bill-sim__card-value">' +
        formatToman(annual.billConservativeToman) +
        "</div>" +
        '<div class="bill-sim__card-delta">پس‌انداز تقریبی ' +
        formatToman(annual.savingsConservativeToman) +
        "</div></div>";
    }

    const chartEl = document.getElementById("billSimChart");
    if (chartEl && Array.isArray(sim.months)) {
      const maxBill = Math.max(
        1,
        ...sim.months.map(function (m) {
          return Math.max(m.billCurrentToman, m.billExpectedToman, m.billConservativeToman);
        })
      );
      const barW = 18;
      const gap = 8;
      const groupW = barW * 3 + gap;
      const height = 140;
      const padTop = 12;
      const padBottom = 28;
      const svgH = height + padTop + padBottom;
      const svgW = sim.months.length * groupW + 20;
      let bars = "";
      sim.months.forEach(function (m, i) {
        const x0 = 10 + i * groupW;
        const hCur = Math.round((m.billCurrentToman / maxBill) * height);
        const hExp = Math.round((m.billExpectedToman / maxBill) * height);
        const hCon = Math.round((m.billConservativeToman / maxBill) * height);
        bars +=
          "<g>" +
          '<rect x="' +
          x0 +
          '" y="' +
          (padTop + height - hCur) +
          '" width="' +
          barW +
          '" height="' +
          hCur +
          '" fill="#94a3b8" rx="2"/>' +
          '<rect x="' +
          (x0 + barW) +
          '" y="' +
          (padTop + height - hExp) +
          '" width="' +
          barW +
          '" height="' +
          hExp +
          '" fill="#0d9488" rx="2"/>' +
          '<rect x="' +
          (x0 + barW * 2) +
          '" y="' +
          (padTop + height - hCon) +
          '" width="' +
          barW +
          '" height="' +
          hCon +
          '" fill="#f59e0b" rx="2"/>' +
          '<text x="' +
          (x0 + groupW / 2 - gap / 2) +
          '" y="' +
          (svgH - 8) +
          '" text-anchor="middle" font-size="10" fill="currentColor">' +
          String(m.label).slice(0, 3) +
          "</text></g>";
      });
      chartEl.innerHTML =
        '<svg viewBox="0 0 ' +
        svgW +
        " " +
        svgH +
        '" width="100%" height="' +
        svgH +
        '" preserveAspectRatio="xMidYMid meet" role="img">' +
        bars +
        "</svg>";
    }

    const tbody = document.querySelector("#billSimTable tbody");
    if (tbody && Array.isArray(sim.months)) {
      tbody.innerHTML = sim.months
        .map(function (m) {
          return (
            "<tr><td>" +
            m.label +
            "</td><td>" +
            formatKwh(m.consumptionKwh) +
            "</td><td>" +
            formatKwh(m.productionExpectedKwh) +
            "</td><td>" +
            formatToman(m.billCurrentToman) +
            "</td><td>" +
            formatToman(m.billExpectedToman) +
            '</td><td class="is-positive">' +
            formatToman(m.savingsExpectedToman) +
            "</td></tr>"
          );
        })
        .join("");
    }

    const assEl = document.getElementById("billSimAssumptions");
    if (assEl && sim.assumptions) {
      const a = sim.assumptions;
      assEl.innerHTML =
        "<ul>" +
        "<li>توان پنل فرضی: " +
        (a.panelWattage || "—") +
        " وات</li>" +
        "<li>ساعات اوج خورشید میانگین: " +
        (a.avgPeakSunHours || "—") +
        " ساعت/روز</li>" +
        "<li>تعرفه تقریبی: " +
        (a.tariffTomanPerKwh ? Number(a.tariffTomanPerKwh).toLocaleString("fa-IR") + " تومان/kWh" : "—") +
        "</li>" +
        "<li>ضریب سناریوی محافظه‌کارانه: " +
        (a.conservativeDerate != null ? Math.round((1 - a.conservativeDerate) * 100) + "% کاهش تولید" : "—") +
        "</li>" +
        "<li>" +
        (a.note || "") +
        "</li></ul>";
    }

    const shareEl = document.getElementById("calcShareSummary");
    if (shareEl && annual.savingsExpectedToman) {
      shareEl.textContent =
        (shareEl.textContent || "") + " · پس‌انداز سالانه تقریبی " + formatToman(annual.savingsExpectedToman);
    }
  }

  function bindNav() {
    document.querySelectorAll("[data-next-step]").forEach((btn) => {
      btn.addEventListener("click", () => {
        if (!validateStep(state.step)) {
          if (window.HamTabUI) HamTabUI.showToast({ title: "لطفاً فیلدهای ضروری را تکمیل کنید", type: "warning" });
          return;
        }
        if (state.step < state.totalSteps) {
          state.step += 1;
          renderStep();
        } else {
          runCalculation();
        }
      });
    });

    document.querySelectorAll("[data-prev-step]").forEach((btn) => {
      btn.addEventListener("click", () => {
        if (state.step > 1) {
          state.step -= 1;
          renderStep();
        }
      });
    });

    const saveBtn = document.getElementById("saveResultBtn");
    if (saveBtn) {
      saveBtn.addEventListener("click", () => {
        document.getElementById("orderPackageBtn")?.scrollIntoView({ behavior: "smooth", block: "center" });
        if (window.HamTabUI) {
          HamTabUI.showToast({
            title: "این محاسبه ثبت شد",
            message: "برای پیگیری، ابتدا وارد حساب کاربری خود شوید.",
            type: "info",
          });
        }
      });
    }
  }

  window.HamTabCalcShare = {
    setSummary: function (text) {
      const el = document.getElementById("calcShareSummary");
      if (el) el.textContent = text;
    },
  };

  document.addEventListener("DOMContentLoaded", () => {
    renderStep();
    bindNav();
  });

  document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("shareCalcBtn");
    if (!btn) return;
    btn.addEventListener("click", async () => {
      const summary = document.getElementById("calcShareSummary")?.textContent || "نتیجه محاسبه خورشیدی هم‌تاب";
      try {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(summary + "\n" + location.href);
          if (window.HamTabUI) HamTabUI.showToast({ title: "خلاصه کپی شد", type: "success" });
        }
      } catch (e) {
        if (window.HamTabUI) HamTabUI.showToast({ title: "کپی ممکن نشد", type: "error" });
      }
    });
  });
})();
