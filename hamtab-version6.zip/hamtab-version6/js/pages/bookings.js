// ==========================================================================
// HamTab — Site visit booking
// Slots are generated server-side (no external calendar dependency yet).
// Architecture is ready for a calendar adapter later.
// ==========================================================================
import { db } from "../db.js";
import { HttpError } from "../router.js";
import { getUserFromRequest, requireAuth, requireAdmin } from "../middleware/auth.js";
import { str } from "../validate.js";
import { newId } from "../crypto-utils.js";

const SLOT_CAPACITY = 3; // max concurrent bookings per date+slot
const HORIZON_DAYS = 14;

// Working slots (local wall-clock labels, Iran-friendly afternoon/evening visits)
const SLOT_DEFS = [
  { id: "09-10", label: "۰۹:۰۰ – ۱۰:۰۰" },
  { id: "10-11", label: "۱۰:۰۰ – ۱۱:۰۰" },
  { id: "11-12", label: "۱۱:۰۰ – ۱۲:۰۰" },
  { id: "16-17", label: "۱۶:۰۰ – ۱۷:۰۰" },
  { id: "17-18", label: "۱۷:۰۰ – ۱۸:۰۰" },
];

const countActiveOnSlot = db.prepare(`
  SELECT COUNT(*) AS c FROM bookings
  WHERE preferred_date = ? AND preferred_slot = ?
    AND status IN ('PENDING','CONFIRMED')
`);

const insertBooking = db.prepare(`
  INSERT INTO bookings (
    id, user_id, name, phone, email, city, address,
    preferred_date, preferred_slot, notes, status, source
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)
`);

const getBooking = db.prepare(`SELECT * FROM bookings WHERE id = ?`);
const listForUser = db.prepare(
  `SELECT * FROM bookings WHERE user_id = ? ORDER BY preferred_date ASC, preferred_slot ASC`
);
const listAll = db.prepare(
  `SELECT * FROM bookings ORDER BY created_at DESC LIMIT 500`
);
const updateStatus = db.prepare(
  `UPDATE bookings SET status = ?, updated_at = datetime('now') WHERE id = ?`
);
const insertNotification = db.prepare(
  `INSERT INTO notifications (id, user_id, title, body, type) VALUES (?, ?, ?, ?, ?)`
);

function pad(n) {
  return String(n).padStart(2, "0");
}

/** YYYY-MM-DD in local-ish UTC+3.5 approximation is overkill; use UTC date parts for stability. */
function formatDate(d) {
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
}

function addDays(d, n) {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}

/** Friday = 5 in JS getUTCDay(). Skip Fridays for site visits. */
function isWorkingDay(d) {
  return d.getUTCDay() !== 5;
}

function serializeBooking(b) {
  const slot = SLOT_DEFS.find((s) => s.id === b.preferred_slot);
  return {
    id: b.id,
    name: b.name,
    phone: b.phone,
    email: b.email,
    city: b.city,
    address: b.address,
    preferredDate: b.preferred_date,
    preferredSlot: b.preferred_slot,
    preferredSlotLabel: slot ? slot.label : b.preferred_slot,
    notes: b.notes,
    status: b.status,
    source: b.source,
    createdAt: b.created_at,
  };
}

function generateSlots(fromDateStr, days) {
  const start = fromDateStr ? new Date(fromDateStr + "T12:00:00Z") : new Date();
  // Normalize to today UTC noon to avoid DST edge cases
  const base = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate(), 12));
  const out = [];

  for (let i = 0; i < days; i++) {
    const day = addDays(base, i);
    if (!isWorkingDay(day)) continue;
    const dateStr = formatDate(day);
    const slots = SLOT_DEFS.map((s) => {
      const used = countActiveOnSlot.get(dateStr, s.id).c;
      const remaining = Math.max(0, SLOT_CAPACITY - used);
      return {
        id: s.id,
        label: s.label,
        remaining,
        available: remaining > 0,
      };
    });
    out.push({
      date: dateStr,
      slots,
      hasAvailability: slots.some((s) => s.available),
    });
  }
  return out;
}

export function registerBookingRoutes(router) {
  // Public: available slots
  router.get("/api/bookings/slots", async (req, res) => {
    const url = new URL(req.url, "http://localhost");
    const from = url.searchParams.get("from") || null;
    const days = Math.min(30, Math.max(1, Number(url.searchParams.get("days")) || HORIZON_DAYS));
    const daysList = generateSlots(from, days);
    res.json(200, {
      days: daysList,
      slotDefs: SLOT_DEFS,
      capacityPerSlot: SLOT_CAPACITY,
      note: "اسلات‌ها تخمینی و بر اساس ظرفیت داخلی هستند؛ وابستگی به تقویم خارجی هنوز فعال نیست.",
    });
  });

  // Create booking — guests allowed (name + phone required)
  router.post("/api/bookings", async (req, res) => {
    const body = req.body || {};
    const name = str(body, "name", { min: 2, max: 120 });
    const phone = str(body, "phone", { min: 8, max: 20 });
    const email = str(body, "email", { required: false, max: 254 }) || null;
    const city = str(body, "city", { required: false, max: 80 }) || null;
    const address = str(body, "address", { required: false, max: 400 }) || null;
    const preferredDate = str(body, "preferredDate", { min: 10, max: 10 });
    const preferredSlot = str(body, "preferredSlot", { min: 4, max: 10 });
    const notes = str(body, "notes", { required: false, max: 500 }) || null;
    const source = str(body, "source", { required: false, max: 40 }) || "web";

    if (!/^\d{4}-\d{2}-\d{2}$/.test(preferredDate)) {
      throw new HttpError(400, "preferredDate must be YYYY-MM-DD");
    }
    if (!SLOT_DEFS.some((s) => s.id === preferredSlot)) {
      throw new HttpError(400, "Invalid preferredSlot");
    }

    // Reject past dates (compare UTC date string)
    const today = formatDate(new Date());
    if (preferredDate < today) {
      throw new HttpError(400, "Cannot book a past date");
    }

    const used = countActiveOnSlot.get(preferredDate, preferredSlot).c;
    if (used >= SLOT_CAPACITY) {
      throw new HttpError(409, "این بازه زمانی پر است. لطفاً زمان دیگری انتخاب کنید.");
    }

    const user = getUserFromRequest(req);
    const id = newId("bk");
    insertBooking.run(
      id,
      user ? user.id : null,
      name,
      phone,
      email,
      city,
      address,
      preferredDate,
      preferredSlot,
      notes,
      source
    );

    if (user) {
      try {
        insertNotification.run(
          newId("nt"),
          user.id,
          "درخواست بازدید ثبت شد",
          `بازدید در تاریخ ${preferredDate} برای بازه ${preferredSlot} ثبت شد و در انتظار تأیید است.`,
          "success"
        );
      } catch {
        /* non-fatal */
      }
    }

    const booking = getBooking.get(id);
    res.json(201, { booking: serializeBooking(booking) });
  });

  // Current user's bookings
  router.get("/api/bookings/me", async (req, res) => {
    const user = requireAuth(req);
    res.json(200, { bookings: listForUser.all(user.id).map(serializeBooking) });
  });

  // Admin: list all
  router.get("/api/bookings", async (req, res) => {
    requireAdmin(req);
    res.json(200, { bookings: listAll.all().map(serializeBooking) });
  });

  // Admin: update status
  router.patch("/api/bookings/:id/status", async (req, res) => {
    requireAdmin(req);
    const status = str(req.body || {}, "status");
    const allowed = ["PENDING", "CONFIRMED", "CANCELLED", "COMPLETED", "NO_SHOW"];
    if (!allowed.includes(status)) throw new HttpError(400, "Invalid status");
    const existing = getBooking.get(req.params.id);
    if (!existing) throw new HttpError(404, "Booking not found");
    updateStatus.run(status, req.params.id);
    res.json(200, { booking: serializeBooking(getBooking.get(req.params.id)) });
  });
}
