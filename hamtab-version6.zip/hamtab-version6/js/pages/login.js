/* =========================================================
   HamTab — Login page
   ========================================================= */
(function () {
  "use strict";

  function paramRedirect() {
    const params = new URLSearchParams(location.search);
    return params.get("redirect") || "dashboard.html";
  }

  function safeRedirect(raw) {
    const fallback = "dashboard.html";
    if (!raw || typeof raw !== "string") return fallback;
    if (
      raw.startsWith("http:") ||
      raw.startsWith("https:") ||
      raw.startsWith("//") ||
      raw.includes("\\") ||
      raw.includes("..")
    ) {
      return fallback;
    }
    // Strip query string for path validation; preserve query on allowed relative targets.
    const qIndex = raw.indexOf("?");
    const pathPart = qIndex >= 0 ? raw.slice(0, qIndex) : raw;
    const queryPart = qIndex >= 0 ? raw.slice(qIndex) : "";
    let target = pathPart.startsWith("pages/") ? pathPart.slice(6) : pathPart;
    if (!/^[a-zA-Z0-9_./-]+$/.test(target) || !target.endsWith(".html")) return fallback;
    // Only allow simple query keys (package id etc.) on same-origin relative pages
    if (queryPart && !/^[?&a-zA-Z0-9_.=%-]+$/.test(queryPart)) return target;
    return target + queryPart;
  }

  document.addEventListener("DOMContentLoaded", async () => {
    const user = await window.HamTabData.getCurrentUser();
    if (user && user.isAuthenticated) {
      location.href = safeRedirect(paramRedirect());
      return;
    }

    const form = document.getElementById("loginForm");
    const errorBox = document.getElementById("authError");
    if (!form) return;

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      errorBox.classList.remove("is-visible");
      const btn = document.getElementById("loginSubmitBtn");
      btn.disabled = true;
      btn.textContent = "در حال ورود...";
      try {
        await window.HamTabData.login({
          email: document.getElementById("email").value.trim(),
          password: document.getElementById("password").value,
        });
        location.href = safeRedirect(paramRedirect());
      } catch (err) {
        errorBox.textContent = err.message || "ورود ناموفق بود.";
        errorBox.classList.add("is-visible");
        btn.disabled = false;
        btn.textContent = "ورود";
      }
    });
  });
})();
