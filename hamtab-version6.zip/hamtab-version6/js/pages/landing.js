/* Landing — packages, mini-calc, bill delta, live bar, booth mode */
(function () {
  "use strict";

  function fa(n) {
    try {
      if (window.HamTabUI && HamTabUI.toFa) return HamTabUI.toFa(n);
    } catch (_) {}
    return String(n ?? "");
  }
  function esc(v) {
    return window.HamTabUI && HamTabUI.escapeHtml ? HamTabUI.escapeHtml(v) : String(v ?? "");
  }
  function formatPrice(toman) {
    const m = Math.round(Number(toman) / 1e6);
    return fa(m) + " میلیون تومان";
  }

  function applyBoothMode() {
    const params = new URLSearchParams(location.search);
    if (params.get("mode") === "booth" || params.get("booth") === "1") {
      document.body.classList.add("booth-mode");
      document.documentElement.classList.add("booth-mode");
    }
  }

  function updateLiveBar(pkgCount) {
    const el = document.getElementById("liveSystemBar");
    if (!el) return;
    const now = new Date();
    const t = now.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
    el.innerHTML =
      '<span class="live-dot" aria-hidden="true"></span>' +
      "<span>سیستم زنده · " +
      fa(pkgCount) +
      " پکیج فعال · به‌روزرسانی " +
      esc(t) +
      "</span>";
  }

  function pkgCard(p, smart) {
    return (
      '<article class="card home-pkg-card' +
      (smart ? " home-pkg-card--smart" : "") +
      '">' +
      (smart ? '<span class="home-pkg-card__tag home-pkg-card__tag--smart">پیشنهاد هوشمند</span>' : p.popular ? '<span class="home-pkg-card__tag">محبوب</span>' : "") +
      '<h3 class="home-pkg-card__name">' +
      esc(p.name) +
      "</h3>" +
      '<p class="home-pkg-card__usage">' +
      esc(p.usage || "") +
      "</p>" +
      '<div class="home-pkg-card__price">' +
      formatPrice(p.price) +
      "</div>" +
      '<div class="home-pkg-card__specs">' +
      "<span>" +
      fa(p.capacityKw) +
      " kW</span>" +
      "<span>" +
      fa(p.panels) +
      " پنل</span>" +
      "<span>" +
      (p.batteryKwh ? fa(p.batteryKwh) + " kWh باتری" : "بدون باتری") +
      "</span></div>" +
      '<a class="btn btn-cta btn-block btn-sm" href="pages/projects.html?package=' +
      encodeURIComponent(p.id) +
      '">جزئیات و سفارش</a></article>'
    );
  }

  async function loadPackages() {
    const grid = document.getElementById("homePkgGrid");
    if (!grid) return;
    try {
      if (!window.HamTabData) throw new Error("no api");
      let list = await window.HamTabData.getPackages();
      if (!Array.isArray(list)) list = [];
      updateLiveBar(list.length);
      const sorted = list
        .slice()
        .sort((a, b) => (b.popular ? 1 : 0) - (a.popular ? 1 : 0) || a.price - b.price);
      const smart = sorted.find((p) => p.popular) || sorted[Math.min(1, sorted.length - 1)];
      const rest = sorted.filter((p) => p !== smart).slice(0, 2);
      const show = smart ? [smart, ...rest] : sorted.slice(0, 3);
      if (!show.length) {
        grid.innerHTML = '<p class="text-muted">پکیج فعالی نیست.</p>';
        return;
      }
      grid.innerHTML = show.map((p, i) => pkgCard(p, smart && p === smart)).join("");
    } catch (err) {
      updateLiveBar(0);
      grid.innerHTML =
        '<p class="text-muted">پکیج‌ها لود نشدند. <a href="pages/projects.html">پروژه‌ها</a></p>';
    }
  }

  function bindMiniCalc() {
    const form = document.getElementById("miniCalcForm");
    if (!form) return;
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const bill = Number(document.getElementById("mcBill").value) || 0;
      const area = Number(document.getElementById("mcArea").value) || 0;
      const climate = Number(document.getElementById("mcCity").value) || 1;
      let kw = (bill / 800000) * climate;
      const maxByRoof = area * 0.15;
      kw = Math.max(1.5, Math.min(kw, maxByRoof, 30));
      kw = Math.round(kw * 10) / 10;
      const priceMin = Math.round(kw * 28);
      const priceMax = Math.round(kw * 38);
      document.getElementById("mcKw").textContent = fa(kw) + " kW";
      document.getElementById("mcPrice").textContent = fa(priceMin) + "–" + fa(priceMax) + " میلیون";
      document.getElementById("miniCalcResult").hidden = false;
    });
  }

  function bindBillDelta() {
    const bill = document.getElementById("billBefore");
    const out = document.getElementById("billAfterOut");
    const save = document.getElementById("billSaveOut");
    if (!bill || !out) return;
    const run = () => {
      const v = Number(bill.value) || 0;
      const after = Math.round(v * 0.45);
      const saved = Math.max(0, v - after);
      out.textContent = fa(after.toLocaleString("en-US")) + " تومان";
      if (save) save.textContent = fa(saved.toLocaleString("en-US")) + " تومان / ماه";
    };
    bill.addEventListener("input", run);
    run();
  }

  document.addEventListener("DOMContentLoaded", () => {
    applyBoothMode();
    loadPackages();
    bindMiniCalc();
    bindBillDelta();
  });
})();
