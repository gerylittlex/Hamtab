import { db } from "../db.js";
import { requireAuth } from "../middleware/auth.js";
import { str } from "../validate.js";
import { hashPassword, verifyPassword, newId } from "../crypto-utils.js";
import { HttpError } from "../router.js";

const updateProfile = db.prepare(`
  UPDATE users SET name = ?, phone = ?, address = ?, install_location = ?, updated_at = datetime('now') WHERE id = ?
`);
const getFull = db.prepare("SELECT * FROM users WHERE id = ?");
const updatePassword = db.prepare(
  "UPDATE users SET password_hash = ?, password_salt = ?, token_version = token_version + 1, updated_at = datetime('now') WHERE id = ?"
);
const setReferralCode = db.prepare(
  "UPDATE users SET referral_code = ?, updated_at = datetime('now') WHERE id = ? AND (referral_code IS NULL OR referral_code = '')"
);
const sumSystemStats = db.prepare(`
  SELECT
    COUNT(*) AS systems,
    COALESCE(SUM(total_generated_kwh), 0) AS totalKwh,
    COALESCE(SUM(total_saved_toman), 0) AS totalSaved
  FROM solar_systems WHERE user_id = ?
`);

function safeQuery(fn, fallback) {
  try {
    return fn();
  } catch (e) {
    console.warn("[profile] optional table query failed:", e.message);
    return fallback;
  }
}

function levelForScore(score) {
  if (score >= 800) return { id: "platinum", label: "پلاتین", nextAt: null };
  if (score >= 400) return { id: "gold", label: "طلایی", nextAt: 800 };
  if (score >= 150) return { id: "silver", label: "نقره‌ای", nextAt: 400 };
  return { id: "bronze", label: "برنزی", nextAt: 150 };
}

function computeScore(userId) {
  const stats = sumSystemStats.get(userId) || { systems: 0, totalKwh: 0, totalSaved: 0 };
  const bonus = safeQuery(
    () => db.prepare("SELECT COALESCE(SUM(points), 0) AS pts FROM energy_score_events WHERE user_id = ?").get(userId)?.pts || 0,
    0
  );
  const refs = safeQuery(
    () =>
      db
        .prepare(
          "SELECT COUNT(*) AS c FROM referrals WHERE referrer_id = ? AND status IN ('QUALIFIED','REWARDED')"
        )
        .get(userId)?.c || 0,
    0
  );

  const fromSystems = Math.min(300, (stats.systems || 0) * 100);
  const fromEnergy = Math.min(500, Math.floor((stats.totalKwh || 0) / 10));
  const fromReferrals = Math.min(400, refs * 40);
  const total = fromSystems + fromEnergy + fromReferrals + bonus;

  return {
    score: total,
    level: levelForScore(total),
    breakdown: {
      systems: fromSystems,
      energy: fromEnergy,
      referrals: fromReferrals,
      bonus: bonus,
    },
    stats: {
      systems: stats.systems || 0,
      totalKwh: stats.totalKwh || 0,
      totalSavedToman: stats.totalSaved || 0,
      qualifiedReferrals: refs,
    },
  };
}

function ensureReferralCode(user) {
  if (!user) return null;
  if (user.referral_code) return user.referral_code;
  const code = ("HT" + (user.id || newId("u")).replace(/[^a-zA-Z0-9]/g, "").slice(-6)).toUpperCase();
  try {
    setReferralCode.run(code, user.id);
  } catch (e) {
    console.warn("[profile] referral_code column may be missing:", e.message);
    return null;
  }
  const again = getFull.get(user.id);
  return (again && again.referral_code) || code;
}

export function registerProfileRoutes(router) {
  router.put("/api/profile", async (req, res) => {
    const user = requireAuth(req);
    const name = str(req.body, "name", { min: 2, max: 120 });
    const phone = str(req.body, "phone", { required: false, max: 40 }) || null;
    const address = str(req.body, "address", { required: false, max: 400 }) || null;
    const installLocation = str(req.body, "installLocation", { required: false, max: 120 }) || null;

    updateProfile.run(name, phone, address, installLocation, user.id);
    const updated = getFull.get(user.id);
    res.json(200, {
      user: {
        id: updated.id,
        name: updated.name,
        email: updated.email,
        phone: updated.phone,
        address: updated.address,
        installLocation: updated.install_location,
        role: updated.role,
        referralCode: updated.referral_code || null,
      },
    });
  });

  router.put("/api/profile/password", async (req, res) => {
    const user = requireAuth(req);
    const currentPassword = str(req.body, "currentPassword", { min: 1 });
    const newPassword = str(req.body, "newPassword", { min: 8, max: 200 });

    const full = getFull.get(user.id);
    if (!verifyPassword(currentPassword, full.password_salt, full.password_hash)) {
      throw new HttpError(401, "Current password is incorrect");
    }
    const { hash, salt } = hashPassword(newPassword);
    updatePassword.run(hash, salt, user.id);
    res.json(200, { ok: true, message: "Password updated. Please log in again on other devices." });
  });

  router.get("/api/profile/energy-score", async (req, res) => {
    const user = requireAuth(req);
    const full = getFull.get(user.id);
    let code = null;
    try {
      code = ensureReferralCode(full);
    } catch (e) {
      console.warn(e);
    }
    const computed = computeScore(user.id);
    const recent = safeQuery(
      () =>
        db
          .prepare(
            "SELECT id, points, reason, created_at FROM energy_score_events WHERE user_id = ? ORDER BY created_at DESC LIMIT 20"
          )
          .all(user.id),
      []
    );
    res.json(200, {
      score: computed.score,
      level: computed.level,
      breakdown: computed.breakdown,
      stats: computed.stats,
      referralCode: code,
      recentEvents: recent,
      formula:
        "۱۰۰ امتیاز به ازای هر سیستم (سقف ۳۰۰) + ۱ امتیاز به ازای هر ۱۰ کیلووات‌ساعت تولید (سقف ۵۰۰) + ۴۰ امتیاز به ازای هر معرفی موفق (سقف ۴۰۰) + امتیاز رویدادهای ویژه",
    });
  });

  router.post("/api/profile/referral", async (req, res) => {
    const user = requireAuth(req);
    const code = str(req.body || {}, "code", { min: 4, max: 32 }).toUpperCase();

    const existing = safeQuery(
      () => db.prepare("SELECT id FROM referrals WHERE referee_id = ?").get(user.id),
      null
    );
    if (existing) throw new HttpError(409, "شما قبلاً با یک کد معرفی ثبت شده‌اید.");

    const referrer = safeQuery(
      () => db.prepare("SELECT id, name, referral_code FROM users WHERE referral_code = ?").get(code),
      null
    );
    if (!referrer) throw new HttpError(404, "کد معرفی معتبر نیست.");
    if (referrer.id === user.id) throw new HttpError(400, "نمی‌توانید خودتان را معرفی کنید.");

    try {
      db.prepare(
        "INSERT INTO referrals (id, referrer_id, referee_id, code, status) VALUES (?, ?, ?, ?, 'PENDING')"
      ).run(newId("ref"), referrer.id, user.id, code);
    } catch (e) {
      if (String(e.message).includes("no such table")) {
        throw new HttpError(503, "سیستم معرفی هنوز روی سرور فعال نشده است.");
      }
      throw e;
    }
    res.json(201, {
      ok: true,
      message: "کد معرفی ثبت شد. پس از نصب سیستم، امتیاز برای معرف فعال می‌شود.",
    });
  });
}
