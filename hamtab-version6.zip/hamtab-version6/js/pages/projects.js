/* =========================================================
   هم‌تاب — Projects & Packages Page Logic
   ========================================================= */

(function () {
  "use strict";

  function esc(v) { return (window.HamTabUI && HamTabUI.escapeHtml) ? HamTabUI.escapeHtml(v) : String(v ?? ""); }

  let allPackages = [];
  let compareIds = new Set();

  function fa(n) {
    try {
      if (window.HamTabUI && typeof HamTabUI.toFa === "function") return HamTabUI.toFa(n);
    } catch (_) {}
    return String(n ?? "");
  }

  function formatPrice(toman) {
    const m = Math.round(Number(toman) / 1000000) || 0;
    return fa(m) + " میلیون تومان";
  }

  function packageCardHTML(pkg) {
    return `
      <div class="card card-hover pkg-card ${pkg.popular ? "is-popular" : ""}" data-reveal>
        ${pkg.popular ? '<span class="pkg-card__popular-tag">محبوب‌ترین</span>' : ""}
        <div class="pkg-card__name">${esc(pkg.name)}</div>
        <div class="pkg-card__usage">${esc(pkg.usage || "")}</div>
        <div class="pkg-card__price">${formatPrice(pkg.price)} <span>/ نصب کامل</span></div>
        <div class="pkg-card__specs">
          <div class="pkg-card__spec"><strong>${fa(pkg.capacityKw)} kW</strong><span>ظرفیت</span></div>
          <div class="pkg-card__spec"><strong>${fa(pkg.panels)}</strong><span>تعداد پنل</span></div>
          <div class="pkg-card__spec"><strong>${pkg.batteryKwh ? fa(pkg.batteryKwh) + " kWh" : "—"}</strong><span>باتری</span></div>
          <div class="pkg-card__spec"><strong>${fa(pkg.dailyProductionKwh)} kWh</strong><span>تولید روزانه</span></div>
        </div>
        <div class="pkg-card__actions">
          <button class="btn btn-cta btn-block" data-order-package="${pkg.id}">سفارش این پکیج</button>
          <button class="btn btn-outline btn-block" data-view-detail="${pkg.id}">مشاهده جزئیات</button>
        </div>
        <label class="pkg-card__compare-check">
          <input type="checkbox" data-compare-check="${pkg.id}" ${compareIds.has(pkg.id) ? "checked" : ""}/>
          افزودن به مقایسه
        </label>
      </div>
    `;
  }

  function renderPackages(list) {
    const grid = document.getElementById("pkgGrid");
    if (!list.length) {
      grid.innerHTML = HamTabUI.stateBlockHTML({
        icon: "🔍",
        title: "پکیجی با این فیلترها پیدا نشد",
        desc: "فیلترها را تغییر دهید یا با پشتیبانی تماس بگیرید.",
      });
      return;
    }
    grid.innerHTML = list.map(packageCardHTML).join("");
    bindCardEvents();
    // Cards are injected after first scroll-reveal pass — make them visible
    if (window.HamTabAnimations && HamTabAnimations.revealNew) {
      HamTabAnimations.revealNew();
    } else {
      grid.querySelectorAll("[data-reveal]").forEach((el) => el.classList.add("is-visible"));
    }
  }

  function applyFilters() {
    const homeSize = document.getElementById("filterHomeSize")?.value || "";
    const battery = document.getElementById("filterBattery")?.value || "";
    const sort = document.getElementById("filterSort")?.value || "";
    const budgetEl = document.getElementById("filterBudget");
    const budgetMax = budgetEl ? Number(budgetEl.value) * 1e6 : Infinity;

    let list = allPackages.filter((p) => {
      if (homeSize && p.homeSize !== homeSize) return false;
      if (battery === "with" && !p.batteryKwh) return false;
      if (battery === "without" && p.batteryKwh) return false;
      if (Number(p.price) > budgetMax) return false;
      return true;
    });

    if (sort === "price-asc") list.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") list.sort((a, b) => b.price - a.price);
    if (sort === "capacity") list.sort((a, b) => b.capacityKw - a.capacityKw);

    renderPackages(list);
  }

  async function placeOrder(pkg) {
    const user = await window.HamTabData.getCurrentUser();
    if (!user || !user.isAuthenticated) {
      HamTabUI.showToast({ title: "ابتدا وارد حساب کاربری شوید", type: "warning" });
      location.href = "login.html?redirect=" + encodeURIComponent("pages/projects.html?package=" + pkg.id);
      return;
    }
    const confirmed = await HamTabUI.confirmAction({
      title: `سفارش ${esc(pkg.name)}`,
      message: `آیا از ثبت سفارش پکیج ${esc(pkg.name)} به مبلغ ${formatPrice(pkg.price)} اطمینان دارید؟`,
      confirmLabel: "ثبت سفارش",
    });
    if (!confirmed) return;

    try {
      const order = await window.HamTabData.createOrder(pkg.id);
      const payResult = await window.HamTabData.payOrder(order.id);
      HamTabUI.showToast({
        title: "سفارش و پرداخت با موفقیت انجام شد",
        message: `شماره سفارش: ${order.id} — وضعیت را از داشبورد پیگیری کنید.`,
        type: "success",
      });
    } catch (err) {
      HamTabUI.showToast({
        title: "ثبت سفارش انجام نشد",
        message: err.message || "لطفاً دوباره تلاش کنید.",
        type: "error",
      });
    }
  }

  function bindCardEvents() {
    document.querySelectorAll("[data-order-package]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const pkg = allPackages.find((p) => p.id === btn.dataset.orderPackage);
        placeOrder(pkg);
      });
    });

    document.querySelectorAll("[data-view-detail]").forEach((btn) => {
      btn.addEventListener("click", () => openDetail(btn.dataset.viewDetail));
    });

    document.querySelectorAll("[data-compare-check]").forEach((checkbox) => {
      checkbox.addEventListener("change", () => {
        const id = checkbox.dataset.compareCheck;
        if (checkbox.checked) {
          if (compareIds.size >= 3) {
            checkbox.checked = false;
            HamTabUI.showToast({ title: "حداکثر ۳ پکیج قابل مقایسه است", type: "warning" });
            return;
          }
          compareIds.add(id);
        } else {
          compareIds.delete(id);
        }
        updateCompareBar();
      });
    });
  }

  function updateCompareBar() {
    const bar = document.getElementById("compareBar");
    const n = compareIds.size;
    const countEl = document.getElementById("compareCount");
    if (countEl) countEl.textContent = fa(n);
    const count2 = document.getElementById("compareCount2");
    if (count2) count2.textContent = fa(n);

    const chips = document.getElementById("compareChips");
    if (chips) {
      const selected = allPackages.filter((p) => compareIds.has(p.id));
      chips.innerHTML = selected
        .map(
          (p) =>
            `<button type="button" class="compare-chip" data-remove-compare="${esc(p.id)}" title="حذف از مقایسه">
              ${esc(p.name)} <span aria-hidden="true">×</span>
            </button>`
        )
        .join("");
      chips.querySelectorAll("[data-remove-compare]").forEach((btn) => {
        btn.addEventListener("click", () => {
          compareIds.delete(btn.dataset.removeCompare);
          // uncheck card checkbox if present
          const cb = document.querySelector(`[data-compare-check="${btn.dataset.removeCompare}"]`);
          if (cb) cb.checked = false;
          updateCompareBar();
        });
      });
    }

    if (bar) bar.classList.toggle("is-visible", n >= 1);

    const openBtn = document.getElementById("compareOpenBtn");
    if (openBtn) {
      openBtn.disabled = false; // never block programmatic/user click; openCompare validates
      openBtn.classList.toggle("is-muted", n < 2);
      openBtn.title = n < 2 ? "حداقل ۲ پکیج انتخاب کنید" : "مشاهده جدول مقایسه";
    }
    const barOpenBtn = document.getElementById("compareBarOpenBtn");
    if (barOpenBtn) {
      barOpenBtn.disabled = false;
      barOpenBtn.classList.toggle("is-muted", n < 2);
    }
  }

  function openDetail(id) {
    const pkg = allPackages.find((p) => p.id === id);
    if (!pkg) return;
    const modal = document.getElementById("detailModal");
    modal.querySelector("[data-detail-name]").textContent = pkg.name;
    modal.querySelector("[data-detail-usage]").textContent = pkg.usage;
    modal.querySelector("[data-detail-price]").textContent = formatPrice(pkg.price);
    modal.querySelector("[data-detail-roi]").textContent = pkg.roi;
    modal.querySelector("[data-detail-warranty]").textContent = pkg.warranty;
    modal.querySelector("[data-detail-availability]").textContent = pkg.installAvailability;

    modal.querySelector("[data-detail-specs]").innerHTML = `
      <div class="stat-card"><div class="stat-card__label">ظرفیت</div><div class="stat-card__value">${fa(pkg.capacityKw)} kW</div></div>
      <div class="stat-card"><div class="stat-card__label">پنل</div><div class="stat-card__value">${fa(pkg.panels)}</div></div>
      <div class="stat-card"><div class="stat-card__label">تولید روزانه</div><div class="stat-card__value">${fa(pkg.dailyProductionKwh)} kWh</div></div>
    `;

    modal.querySelector("[data-detail-components]").innerHTML = pkg.components
      .map(
        (c) => `<li><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m20 6-11 11-5-5"/></svg> ${esc(c)}</li>`
      )
      .join("");

    modal.querySelector("[data-detail-order]").onclick = async () => {
      HamTabUI.closeModal(modal);
      await placeOrder(pkg);
    };

    HamTabUI.openModal(modal);
  }

  function openCompare() {
    const packages = allPackages.filter((p) => compareIds.has(p.id));
    if (packages.length < 2) {
      HamTabUI.showToast({
        title: "حداقل ۲ پکیج انتخاب کنید",
        message: "با تیک «افزودن به مقایسه» روی کارت پکیج‌ها، حداقل دو مورد را انتخاب کنید.",
        type: "warning",
      });
      return;
    }

    const modal = document.getElementById("compareModal");
    const rows = [
      ["مناسب برای", (p) => p.homeSize || "—"],
      ["ظرفیت", (p) => fa(p.capacityKw) + " kW"],
      ["تعداد پنل", (p) => fa(p.panels)],
      ["باتری", (p) => (p.batteryKwh ? fa(p.batteryKwh) + " kWh" : "بدون باتری")],
      ["تولید روزانه", (p) => fa(p.dailyProductionKwh) + " kWh"],
      ["قیمت نصب کامل", (p) => formatPrice(p.price)],
      ["بازگشت سرمایه", (p) => p.roi || "—"],
      ["گارانتی", (p) => p.warranty || "—"],
      ["زمان تقریبی نصب", (p) => p.installAvailability || "—"],
      ["توضیح", (p) => p.usage || "—"],
    ];

    // Highlight best capacity / lowest price for quick scan
    const maxCap = Math.max(...packages.map((p) => Number(p.capacityKw) || 0));
    const minPrice = Math.min(...packages.map((p) => Number(p.price) || Infinity));

    let html = '<div class="table-wrap compare-table-wrap"><table class="data-table compare-table"><thead><tr><th class="compare-feature">ویژگی</th>';
    packages.forEach((p) => {
      html += `<th>
        <div class="compare-pkg-name">${esc(p.name)}</div>
        <div class="compare-pkg-price">${formatPrice(p.price)}</div>
        <button type="button" class="btn btn-cta btn-sm" data-compare-order="${esc(p.id)}" style="margin-top:8px;">سفارش</button>
      </th>`;
    });
    html += "</tr></thead><tbody>";
    rows.forEach(([label, fn]) => {
      html += `<tr><th class="compare-feature">${esc(label)}</th>`;
      packages.forEach((p) => {
        let cell = fn(p);
        let cls = "";
        if (label === "ظرفیت" && Number(p.capacityKw) === maxCap) cls = " is-best";
        if (label === "قیمت نصب کامل" && Number(p.price) === minPrice) cls = " is-best";
        html += `<td class="${cls.trim()}">${typeof cell === "string" ? esc(cell) : cell}</td>`;
      });
      html += "</tr>";
    });
    html += "</tbody></table></div>";

    if (!modal) {
      HamTabUI.showToast({ title: "مودال مقایسه پیدا نشد", type: "error" });
      return;
    }
    const body = modal.querySelector("[data-compare-table]") || modal.querySelector(".modal__body");
    if (!body) {
      HamTabUI.showToast({ title: "بدنه مودال مقایسه پیدا نشد", type: "error" });
      return;
    }
    body.innerHTML = html;
    body.querySelectorAll("[data-compare-order]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const pkg = allPackages.find((p) => p.id === btn.dataset.compareOrder);
        if (!pkg) return;
        HamTabUI.closeModal(modal);
        await placeOrder(pkg);
      });
    });
    if (window.HamTabUI && typeof HamTabUI.openModal === "function") {
      HamTabUI.openModal(modal);
    } else {
      modal.classList.add("is-open");
      document.body.classList.add("no-scroll");
    }
  }

  function clearCompare() {
    compareIds.clear();
    document.querySelectorAll("[data-compare-check]").forEach((cb) => {
      cb.checked = false;
    });
    updateCompareBar();
    HamTabUI.showToast({ title: "انتخاب مقایسه پاک شد", type: "success" });
  }

  async function loadAndRender() {
    const grid = document.getElementById("pkgGrid");
    const countEl = document.getElementById("pkgCountLabel");
    try {
      if (!window.HamTabData) throw new Error("API client load failed — از http://localhost:4000 باز کنید");
      allPackages = await window.HamTabData.getPackages();
      if (!Array.isArray(allPackages)) allPackages = [];
      if (countEl) countEl.textContent = allPackages.length ? `${allPackages.length} پکیج فعال` : "بدون پکیج فعال";
      // reset filters so new packages are never hidden by a stale filter
      const fh = document.getElementById("filterHomeSize");
      const fb = document.getElementById("filterBattery");
      const fs = document.getElementById("filterSort");
      if (fh) fh.value = "";
      if (fb) fb.value = "";
      if (fs) fs.value = "";
      renderPackages(allPackages);
      updateCompareBar();
      if (!allPackages.length && grid) {
        grid.innerHTML = HamTabUI.emptyBlockHTML({
          icon: "📦",
          title: "هنوز پکیج فعالی ثبت نشده",
          desc: "از پنل مدیریت یک پکیج با وضعیت «فعال» اضافه کنید، بعد این صفحه را رفرش کنید.",
        });
      }
      return allPackages;
    } catch (err) {
      console.error(err);
      if (countEl) countEl.textContent = "خطا در بارگذاری";
      if (grid) {
        grid.innerHTML = HamTabUI.emptyBlockHTML({
          icon: "⚠️",
          title: "بارگذاری پکیج‌ها ناموفق بود",
          desc: "حتماً سرور را با npm run dev اجرا کنید و سایت را از آدرس http://localhost:4000 باز کنید (نه Live Server جدا). " + (err.message || ""),
        });
      }
      HamTabUI.showToast({ title: "خطا در دریافت پکیج‌ها", message: err.message, type: "error" });
      return [];
    }
  }

  async function init() {
    await loadAndRender();

    const filterHome = document.getElementById("filterHomeSize");
    const filterBattery = document.getElementById("filterBattery");
    const filterSort = document.getElementById("filterSort");
    const compareBtn = document.getElementById("compareOpenBtn");
    if (filterHome) filterHome.addEventListener("change", applyFilters);
    if (filterBattery) filterBattery.addEventListener("change", applyFilters);
    if (filterSort) filterSort.addEventListener("change", applyFilters);
    const budget = document.getElementById("filterBudget");
    const budgetLabel = document.getElementById("filterBudgetLabel");
    if (budget) {
      const syncBudget = () => {
        const v = Number(budget.value);
        if (budgetLabel) budgetLabel.textContent = v >= 500 ? "۵۰۰M+" : fa(v) + "M";
        applyFilters();
      };
      budget.addEventListener("input", syncBudget);
    }
    if (compareBtn) compareBtn.addEventListener("click", openCompare);
    const clearBtn = document.getElementById("compareClearBtn");
    if (clearBtn) clearBtn.addEventListener("click", clearCompare);
    const barOpenBtn = document.getElementById("compareBarOpenBtn");
    if (barOpenBtn) barOpenBtn.addEventListener("click", openCompare);
    const clearBar = document.getElementById("compareClearBtnBar");
    if (clearBar) clearBar.addEventListener("click", clearCompare);
    const refreshBtn = document.getElementById("pkgRefreshBtn");
    if (refreshBtn) refreshBtn.addEventListener("click", () => loadAndRender());

    const params = new URLSearchParams(location.search);
    const preselect = params.get("package");
    if (preselect && allPackages.length) openDetail(preselect);
  }

  document.addEventListener("DOMContentLoaded", init);

  // Fallback for older HTML / inline handlers
  window.HamTabCompare = { open: openCompare, clear: clearCompare };

})();
