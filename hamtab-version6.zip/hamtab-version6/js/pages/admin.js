// ==========================================================================
// HamTab — Admin API (requireAdmin on every route)
// ==========================================================================
import { db } from "../db.js";
import { HttpError } from "../router.js";
import { requireAdmin } from "../middleware/auth.js";
import { str, num } from "../validate.js";
import { newId } from "../crypto-utils.js";
import { provisionSystemForOrder } from "./orders.js";
import { serializePackage } from "./packages.js";

const listUsers = db.prepare(
  `SELECT id, name, email, phone, role, created_at FROM users ORDER BY created_at DESC LIMIT 500`
);
const getUser = db.prepare(`SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?`);
const setUserRole = db.prepare(`UPDATE users SET role = ?, updated_at = datetime('now') WHERE id = ?`);

const listAllPackages = db.prepare(`SELECT * FROM packages ORDER BY price ASC`);
const getPackage = db.prepare(`SELECT * FROM packages WHERE id = ?`);
const insertPackage = db.prepare(`
  INSERT INTO packages (
    id, name, tier, capacity_kw, panels, battery_kwh, daily_production_kwh, price,
    usage_desc, home_size, install_availability, warranty, roi, components_json, popular, status
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const updatePackage = db.prepare(`
  UPDATE packages SET
    name = ?, tier = ?, capacity_kw = ?, panels = ?, battery_kwh = ?, daily_production_kwh = ?,
    price = ?, usage_desc = ?, home_size = ?, install_availability = ?, warranty = ?, roi = ?,
    components_json = ?, popular = ?, status = ?
  WHERE id = ?
`);

const listAllOrders = db.prepare(`
  SELECT o.*, u.name AS user_name, u.email AS user_email
  FROM orders o
  JOIN users u ON u.id = o.user_id
  ORDER BY o.created_at DESC
  LIMIT 500
`);
const getOrder = db.prepare(`SELECT * FROM orders WHERE id = ?`);
const updateOrderStatus = db.prepare(
  `UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?`
);

const listNeighborhoods = db.prepare(`SELECT * FROM neighborhoods ORDER BY created_at DESC`);
const getNeighborhood = db.prepare(`SELECT * FROM neighborhoods WHERE id = ?`);
const countParticipants = db.prepare(
  `SELECT COUNT(*) AS c FROM neighborhood_participants WHERE neighborhood_id = ?`
);
const insertNeighborhood = db.prepare(`
  INSERT INTO neighborhoods (id, name, city, required, estimated_panels, estimated_kw, status)
  VALUES (?, ?, ?, ?, ?, ?, ?)
`);
const updateNeighborhood = db.prepare(`
  UPDATE neighborhoods SET name = ?, city = ?, required = ?, estimated_panels = ?, estimated_kw = ?, status = ?
  WHERE id = ?
`);

const statsStmt = db.prepare(`
  SELECT
    (SELECT COUNT(*) FROM users) AS users,
    (SELECT COUNT(*) FROM orders) AS orders,
    (SELECT COUNT(*) FROM orders WHERE payment_status = 'PAID') AS paid_orders,
    (SELECT COALESCE(SUM(price), 0) FROM orders WHERE payment_status = 'PAID') AS revenue,
    (SELECT COUNT(*) FROM packages WHERE status = 'ACTIVE') AS active_packages,
    (SELECT COUNT(*) FROM solar_systems) AS systems,
    (SELECT COUNT(*) FROM neighborhoods) AS neighborhoods
`);

const ALLOWED_ORDER_STATUS = new Set([
  "PENDING", "PAID", "CONFIRMED", "SCHEDULED", "INSTALLING", "INSTALLED", "ACTIVE", "CANCELLED",
]);
const ALLOWED_PKG_STATUS = new Set(["ACTIVE", "DISCONTINUED"]);
const ALLOWED_ROLES = new Set(["USER", "ADMIN"]);
const ALLOWED_NB_STATUS = new Set(["COLLECTING", "JUST_STARTED", "NEARLY_COMPLETE", "FUNDED", "INSTALLING", "COMPLETED"]);

function serializeOrderAdmin(o) {
  return {
    id: o.id,
    userId: o.user_id,
    userName: o.user_name || null,
    userEmail: o.user_email || null,
    packageId: o.package_id,
    packageName: o.package_name,
    price: o.price,
    address: o.address,
    status: o.status,
    payment: o.payment_status,
    date: o.created_at,
  };
}

function serializeAdminPackage(row) {
  return { ...serializePackage(row), status: row.status };
}

function parseComponents(body) {
  if (Array.isArray(body.components)) {
    return body.components.map((c) => String(c).slice(0, 200)).filter(Boolean).slice(0, 30);
  }
  if (typeof body.components === "string" && body.components.trim()) {
    return body.components
      .split(/\n|,/)
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 30);
  }
  return [];
}

function packageFields(body, { partial = false } = {}) {
  const req = !partial;
  const name = str(body, "name", { required: req, min: 2, max: 120 });
  const tier = str(body, "tier", { required: req, min: 2, max: 40 });
  const capacityKw = num(body, "capacityKw", { required: req, min: 0.1, max: 1000 });
  const panels = num(body, "panels", { required: req, min: 1, max: 10000 });
  const batteryKwh = num(body, "batteryKwh", { required: false, min: 0, max: 10000 }) ?? 0;
  const dailyProductionKwh = num(body, "dailyProductionKwh", { required: req, min: 0, max: 100000 });
  const price = num(body, "price", { required: req, min: 0, max: 1e12 });
  const usage = str(body, "usage", { required: false, max: 400 }) || null;
  const homeSize = str(body, "homeSize", { required: false, max: 80 }) || null;
  const installAvailability = str(body, "installAvailability", { required: false, max: 120 }) || null;
  const warranty = str(body, "warranty", { required: false, max: 400 }) || null;
  const roi = str(body, "roi", { required: false, max: 120 }) || null;
  const popular = body.popular === true || body.popular === 1 || body.popular === "1" ? 1 : 0;
  let status = body.status != null && String(body.status).trim() !== ""
    ? String(body.status).toUpperCase()
    : "ACTIVE";
  if (!ALLOWED_PKG_STATUS.has(status)) throw new HttpError(400, "Invalid package status");
  const components = parseComponents(body);
  return {
    name, tier, capacityKw, panels, batteryKwh, dailyProductionKwh, price,
    usage, homeSize, installAvailability, warranty, roi, popular, status, components,
  };
}

export function registerAdminRoutes(router) {
  router.get("/api/admin/stats", async (req, res) => {
    requireAdmin(req);
    const s = statsStmt.get();
    res.json(200, {
      stats: {
        users: s.users,
        orders: s.orders,
        paidOrders: s.paid_orders,
        revenue: s.revenue,
        activePackages: s.active_packages,
        systems: s.systems,
        neighborhoods: s.neighborhoods,
      },
    });
  });

  // ---------- users ----------
  router.get("/api/admin/users", async (req, res) => {
    requireAdmin(req);
    res.json(200, {
      users: listUsers.all().map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        phone: u.phone,
        role: u.role,
        createdAt: u.created_at,
      })),
    });
  });

  router.patch("/api/admin/users/:id/role", async (req, res) => {
    const admin = requireAdmin(req);
    const role = String(req.body.role || "").toUpperCase();
    if (!ALLOWED_ROLES.has(role)) throw new HttpError(400, "Role must be USER or ADMIN");
    const target = getUser.get(req.params.id);
    if (!target) throw new HttpError(404, "User not found");
    if (target.id === admin.id && role !== "ADMIN") {
      throw new HttpError(400, "Cannot remove your own admin role");
    }
    setUserRole.run(role, target.id);
    res.json(200, { user: { ...target, role } });
  });

  // ---------- packages ----------
  router.get("/api/admin/packages", async (req, res) => {
    requireAdmin(req);
    res.json(200, { packages: listAllPackages.all().map(serializeAdminPackage) });
  });

  router.post("/api/admin/packages", async (req, res) => {
    requireAdmin(req);
    const f = packageFields(req.body);
    const id = str(req.body, "id", { required: false, min: 3, max: 64 }) || newId("pkg");
    if (getPackage.get(id)) throw new HttpError(409, "Package id already exists");
    insertPackage.run(
      id, f.name, f.tier, f.capacityKw, f.panels, f.batteryKwh, f.dailyProductionKwh, f.price,
      f.usage, f.homeSize, f.installAvailability, f.warranty, f.roi,
      JSON.stringify(f.components), f.popular, f.status
    );
    res.json(201, { package: serializeAdminPackage(getPackage.get(id)) });
  });

  router.put("/api/admin/packages/:id", async (req, res) => {
    requireAdmin(req);
    const existing = getPackage.get(req.params.id);
    if (!existing) throw new HttpError(404, "Package not found");
    // Merge: allow partial by filling from existing
    const body = {
      name: req.body.name ?? existing.name,
      tier: req.body.tier ?? existing.tier,
      capacityKw: req.body.capacityKw ?? existing.capacity_kw,
      panels: req.body.panels ?? existing.panels,
      batteryKwh: req.body.batteryKwh ?? existing.battery_kwh,
      dailyProductionKwh: req.body.dailyProductionKwh ?? existing.daily_production_kwh,
      price: req.body.price ?? existing.price,
      usage: req.body.usage ?? existing.usage_desc,
      homeSize: req.body.homeSize ?? existing.home_size,
      installAvailability: req.body.installAvailability ?? existing.install_availability,
      warranty: req.body.warranty ?? existing.warranty,
      roi: req.body.roi ?? existing.roi,
      popular: req.body.popular !== undefined ? req.body.popular : existing.popular,
      status: req.body.status ?? existing.status,
      components:
        req.body.components !== undefined
          ? req.body.components
          : JSON.parse(existing.components_json || "[]"),
    };
    const f = packageFields(body);
    updatePackage.run(
      f.name, f.tier, f.capacityKw, f.panels, f.batteryKwh, f.dailyProductionKwh, f.price,
      f.usage, f.homeSize, f.installAvailability, f.warranty, f.roi,
      JSON.stringify(f.components), f.popular, f.status, req.params.id
    );
    res.json(200, { package: serializeAdminPackage(getPackage.get(req.params.id)) });
  });

  // Soft-delete = DISCONTINUED (keep FK integrity for past orders)
  router.delete("/api/admin/packages/:id", async (req, res) => {
    requireAdmin(req);
    const existing = getPackage.get(req.params.id);
    if (!existing) throw new HttpError(404, "Package not found");
    updatePackage.run(
      existing.name, existing.tier, existing.capacity_kw, existing.panels, existing.battery_kwh,
      existing.daily_production_kwh, existing.price, existing.usage_desc, existing.home_size,
      existing.install_availability, existing.warranty, existing.roi, existing.components_json,
      existing.popular, "DISCONTINUED", req.params.id
    );
    res.json(200, { package: serializeAdminPackage(getPackage.get(req.params.id)) });
  });

  // ---------- orders ----------
  router.get("/api/admin/orders", async (req, res) => {
    requireAdmin(req);
    res.json(200, { orders: listAllOrders.all().map(serializeOrderAdmin) });
  });

  router.patch("/api/admin/orders/:id/status", async (req, res) => {
    requireAdmin(req);
    const status = String(req.body.status || "").toUpperCase();
    if (!ALLOWED_ORDER_STATUS.has(status)) throw new HttpError(400, "Invalid order status");
    const order = getOrder.get(req.params.id);
    if (!order) throw new HttpError(404, "Order not found");
    updateOrderStatus.run(status, order.id);
    const provisionStatuses = new Set(["PAID", "CONFIRMED", "SCHEDULED", "INSTALLING", "INSTALLED", "ACTIVE"]);
    if (provisionStatuses.has(status)) {
      try {
        const full = getOrder.get(order.id) || order;
        if (full.payment_status !== "PAID") {
          try {
            db.prepare("UPDATE orders SET payment_status = 'PAID', updated_at = datetime('now') WHERE id = ?").run(order.id);
          } catch (_) {}
        }
        provisionSystemForOrder(getOrder.get(order.id) || full);
      } catch (e) {
        console.error("provision on admin status failed", e);
      }
    }
    const updated = listAllOrders.all().find((o) => o.id === order.id) || { ...order, status };
    res.json(200, { order: serializeOrderAdmin({ ...updated, status }) });
  });

  // ---------- neighborhoods ----------
  router.get("/api/admin/neighborhoods", async (req, res) => {
    requireAdmin(req);
    const rows = listNeighborhoods.all().map((n) => ({
      id: n.id,
      name: n.name,
      city: n.city,
      required: n.required,
      estimatedPanels: n.estimated_panels,
      estimatedKw: n.estimated_kw,
      status: n.status,
      participants: countParticipants.get(n.id).c,
      createdAt: n.created_at,
    }));
    res.json(200, { neighborhoods: rows });
  });

  router.post("/api/admin/neighborhoods", async (req, res) => {
    requireAdmin(req);
    const name = str(req.body, "name", { min: 2, max: 120 });
    const city = str(req.body, "city", { required: false, max: 80 }) || null;
    const required = Math.floor(num(req.body, "required", { min: 1, max: 100000 }));
    const estimatedPanels = Math.floor(num(req.body, "estimatedPanels", { required: false, min: 0, max: 1e6 }) || 0);
    const estimatedKw = num(req.body, "estimatedKw", { required: false, min: 0, max: 1e6 }) || 0;
    const status = String(req.body.status || "COLLECTING").toUpperCase();
    if (!ALLOWED_NB_STATUS.has(status)) throw new HttpError(400, "Invalid neighborhood status");
    const id = newId("nb");
    insertNeighborhood.run(id, name, city, required, estimatedPanels, estimatedKw, status);
    const n = getNeighborhood.get(id);
    res.json(201, {
      neighborhood: {
        id: n.id, name: n.name, city: n.city, required: n.required,
        estimatedPanels: n.estimated_panels, estimatedKw: n.estimated_kw,
        status: n.status, participants: 0, createdAt: n.created_at,
      },
    });
  });

  router.put("/api/admin/neighborhoods/:id", async (req, res) => {
    requireAdmin(req);
    const existing = getNeighborhood.get(req.params.id);
    if (!existing) throw new HttpError(404, "Neighborhood not found");
    const name = str(req.body, "name", { min: 2, max: 120 });
    const city = str(req.body, "city", { required: false, max: 80 }) || null;
    const required = Math.floor(num(req.body, "required", { min: 1, max: 100000 }));
    const estimatedPanels = Math.floor(
      num(req.body, "estimatedPanels", { required: false, min: 0, max: 1e6 }) ?? existing.estimated_panels ?? 0
    );
    const estimatedKw = num(req.body, "estimatedKw", { required: false, min: 0, max: 1e6 }) ?? existing.estimated_kw ?? 0;
    const status = String(req.body.status || existing.status).toUpperCase();
    if (!ALLOWED_NB_STATUS.has(status)) throw new HttpError(400, "Invalid neighborhood status");
    updateNeighborhood.run(name, city, required, estimatedPanels, estimatedKw, status, existing.id);
    const n = getNeighborhood.get(existing.id);
    res.json(200, {
      neighborhood: {
        id: n.id, name: n.name, city: n.city, required: n.required,
        estimatedPanels: n.estimated_panels, estimatedKw: n.estimated_kw,
        status: n.status, participants: countParticipants.get(n.id).c, createdAt: n.created_at,
      },
    });
  });
}
