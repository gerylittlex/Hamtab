/* =========================================================
   HamTab — Offline / cache store
   ---------------------------------------------------------
   Lightweight localStorage helper for controller & dashboard.
   Designed to stay framework-free so a future mobile app can
   reuse the same API contract (HamTabData) without depending
   on this module.
   ========================================================= */
(function (global) {
  "use strict";

  var PREFIX = "hamtab_cache_v1_";

  function key(name) {
    return PREFIX + name;
  }

  function save(name, data) {
    try {
      var payload = {
        savedAt: Date.now(),
        data: data,
      };
      localStorage.setItem(key(name), JSON.stringify(payload));
      return true;
    } catch (e) {
      return false;
    }
  }

  function load(name) {
    try {
      var raw = localStorage.getItem(key(name));
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      return parsed;
    } catch (e) {
      return null;
    }
  }

  function clear(name) {
    try {
      localStorage.removeItem(key(name));
    } catch (e) {
      /* ignore */
    }
  }

  function ageMs(entry) {
    if (!entry || !entry.savedAt) return Infinity;
    return Date.now() - entry.savedAt;
  }

  function formatLastUpdated(ts) {
    if (!ts) return "—";
    try {
      return new Intl.DateTimeFormat("fa-IR", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        day: "numeric",
        month: "short",
      }).format(new Date(ts));
    } catch (e) {
      return new Date(ts).toLocaleString("fa-IR");
    }
  }

  /** True when browser reports offline (best-effort). */
  function isBrowserOffline() {
    return typeof navigator !== "undefined" && navigator.onLine === false;
  }

  global.HamTabOffline = {
    save: save,
    load: load,
    clear: clear,
    ageMs: ageMs,
    formatLastUpdated: formatLastUpdated,
    isBrowserOffline: isBrowserOffline,
    CACHE_KEYS: {
      CONTROLLER: "controller_state",
      DASHBOARD: "dashboard_summary",
    },
  };
})(window);
