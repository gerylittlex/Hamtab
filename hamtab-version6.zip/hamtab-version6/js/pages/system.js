(function () {
  "use strict";

  function faStatus(s) {
    return (
      {
        ACTIVE: "فعال",
        PENDING_INSTALL: "در انتظار نصب",
        OFFLINE: "آفلاین",
        INSTALLED: "نصب‌شده",
      }[s] || s || "—"
    );
  }

  function faConn(c) {
    return c === "online" ? "آنلاین" : c === "offline" ? "آفلاین" : "—";
  }

  async function init() {
    const loading = document.getElementById("systemLoading");
    const errEl = document.getElementById("systemError");
    const card = document.getElementById("systemCard");
    const params = new URLSearchParams(location.search);
    const token = params.get("t") || params.get("token") || "";

    if (!token) {
      loading.hidden = true;
      errEl.hidden = false;
      errEl.textContent = "کد QR یا توکن سیستم در آدرس صفحه نیست.";
      return;
    }

    try {
      if (!window.HamTabData || !window.HamTabData.getPublicSystem) {
        throw new Error("API در دسترس نیست");
      }
      const system = await window.HamTabData.getPublicSystem(token);
      loading.hidden = true;
      card.hidden = false;
      document.getElementById("sysTitle").textContent = system.packageName || "سیستم خورشیدی هم‌تاب";
      document.getElementById("sysSub").textContent = "شناسه عمومی سیستم — بدون اطلاعات شخصی مالک";
      document.getElementById("sysCap").textContent = (system.capacityKw != null ? system.capacityKw + " kW" : "—");
      document.getElementById("sysStatus").textContent = faStatus(system.status);
      document.getElementById("sysGen").textContent =
        system.totalGeneratedKwh != null ? Number(system.totalGeneratedKwh).toLocaleString("fa-IR") + " kWh" : "—";
      document.getElementById("sysConn").textContent = faConn(system.connection);
      document.getElementById("sysSerial").textContent = system.serialNumber || "—";
      document.getElementById("sysInstalled").textContent = system.installedOn || "—";
      document.getElementById("sysPrivacy").textContent =
        system.privacyNote || "اطلاعات هویتی مالک در این صفحه نمایش داده نمی‌شود.";
    } catch (e) {
      loading.hidden = true;
      errEl.hidden = false;
      errEl.textContent = e.message || "سیستم پیدا نشد یا توکن نامعتبر است.";
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
