/* =========================================================
   هم‌تاب — Smart Solar Controller Page Logic
   Offline-aware: caches last good state, shows LIVE / STALE /
   DISCONNECTED / OFFLINE / CACHED with last-updated time.
   ========================================================= */
(function () {
  "use strict";

  var liveState = null;
  var pollTimer = null;
  var lastGoodAt = null;
  var usingCache = false;
  var CACHE_KEY = (window.HamTabOffline && window.HamTabOffline.CACHE_KEYS.CONTROLLER) || "controller_state";

  var CONNECTION_LABELS = {
    LIVE: "اتصال زنده",
    STALE: "داده قدیمی — چند لحظه صبر کنید",
    DISCONNECTED: "قطع ارتباط با کنترلر",
    OFFLINE: "آفلاین — نمایش آخرین داده ذخیره‌شده",
    CACHED: "داده ذخیره‌شده (بدون ارتباط)",
    UNKNOWN: "هنوز داده‌ای دریافت نشده",
  };

  function saveCache(state) {
    if (!window.HamTabOffline || !state) return;
    window.HamTabOffline.save(CACHE_KEY, state);
    lastGoodAt = Date.now();
  }

  function loadCache() {
    if (!window.HamTabOffline) return null;
    return window.HamTabOffline.load(CACHE_KEY);
  }

  function renderLastUpdated(ts, fromCache) {
    var el = document.getElementById("lastUpdatedLine");
    if (!el) return;
    if (!ts) {
      el.hidden = true;
      return;
    }
    var formatted = window.HamTabOffline
      ? window.HamTabOffline.formatLastUpdated(ts)
      : new Date(ts).toLocaleString("fa-IR");
    el.hidden = false;
    el.innerHTML =
      '<span class="last-updated__label">آخرین به‌روزرسانی:</span> ' +
      '<time datetime="' +
      new Date(ts).toISOString() +
      '">' +
      formatted +
      "</time>" +
      (fromCache ? ' <span class="last-updated__badge">کش محلی</span>' : "");
  }

  function renderOfflineBanner(show, message) {
    var banner = document.getElementById("offlineBanner");
    if (!banner) return;
    if (!show) {
      banner.hidden = true;
      banner.innerHTML = "";
      return;
    }
    banner.hidden = false;
    banner.innerHTML =
      '<div class="offline-banner__inner">' +
      '<span class="offline-banner__icon" aria-hidden="true">📡</span>' +
      "<div><strong>اتصال برقرار نیست</strong>" +
      "<p>" +
      (message || "آخرین دادهٔ ذخیره‌شده نمایش داده می‌شود. با بازگشت اینترنت، به‌صورت خودکار همگام می‌شود.") +
      "</p></div>" +
      '<button type="button" class="btn btn-outline btn-sm" id="btnRetryConnection">تلاش مجدد</button>' +
      "</div>";
    var btn = document.getElementById("btnRetryConnection");
    if (btn) {
      btn.addEventListener("click", function () {
        poll(true);
      });
    }
  }

  function renderConnection(connection) {
    var pill = document.getElementById("connectionPill");
    var label = document.getElementById("connectionLabel");
    if (!pill || !label) return;
    label.textContent = CONNECTION_LABELS[connection] || connection;
    pill.classList.remove("is-live", "is-stale", "is-disconnected", "is-offline", "is-cached");
    if (connection === "LIVE") pill.classList.add("is-live");
    else if (connection === "STALE") pill.classList.add("is-stale");
    else if (connection === "OFFLINE" || connection === "CACHED") pill.classList.add("is-offline");
    else pill.classList.add("is-disconnected");
  }

  function healthLabel(status) {
    return { healthy: "سالم", warning: "نیاز به بررسی", attention: "نیاز به توجه فوری" }[status] || status;
  }

  function renderMetrics(s) {
    if (!s) return;
    HamTabUI.animateCounter(document.getElementById("mSolar"), s.solarProductionKw || 0, { decimals: 1, suffix: " kW" });
    HamTabUI.animateCounter(document.getElementById("mConsumption"), s.homeConsumptionKw || 0, { decimals: 1, suffix: " kW" });
    HamTabUI.animateCounter(document.getElementById("mBattery"), s.batteryPercent || 0, { decimals: 0, suffix: "%" });
    HamTabUI.animateCounter(document.getElementById("mGrid"), s.gridUsageKw || 0, { decimals: 1, suffix: " kW" });
    var savedEl = document.getElementById("mSaved");
    if (savedEl) savedEl.textContent = HamTabUI.formatToman(s.energySavedTodayToman || 0);
    var dailyEl = document.getElementById("mDaily");
    if (dailyEl) dailyEl.textContent = HamTabUI.toFa(s.dailyProductionKwh || 0) + " kWh";
    var monthlyEl = document.getElementById("mMonthly");
    if (monthlyEl) monthlyEl.textContent = HamTabUI.toFa(s.monthlyProductionKwh || 0) + " kWh";

    var flowSolar = document.getElementById("flowSolar");
    var flowHome = document.getElementById("flowHome");
    var flowBattery = document.getElementById("flowBattery");
    var flowGrid = document.getElementById("flowGrid");
    if (flowSolar) flowSolar.textContent = (s.solarProductionKw || 0).toFixed(1) + " kW";
    if (flowHome) flowHome.textContent = (s.homeConsumptionKw || 0).toFixed(1) + " kW";
    if (flowBattery) flowBattery.textContent = (s.batteryPercent || 0) + "%";
    if (flowGrid) flowGrid.textContent = (s.gridUsageKw || 0).toFixed(1) + " kW";
  }

  function renderBattery(s) {
    if (!s) return;
    var fill = document.getElementById("batteryFill");
    if (fill) fill.style.height = (s.batteryPercent || 0) + "%";
    var pct = document.getElementById("batteryPercentText");
    if (pct) pct.textContent = HamTabUI.toFa(s.batteryPercent || 0) + "٪";
    var st = document.getElementById("batteryStatus");
    if (st) st.textContent = s.batteryCharging ? "در حال شارژ" : "در حال تخلیه";
    var tm = document.getElementById("batteryTime");
    if (tm) tm.textContent = s.batteryTimeRemaining || "—";
  }

  function renderHealth(items) {
    var wrap = document.getElementById("healthGrid");
    if (!wrap || !items) return;
    wrap.innerHTML = items
      .map(function (item) {
        return (
          '<div class="card health-item">' +
          '<span class="health-dot ' +
          item.status +
          '"></span>' +
          "<div><strong>" +
          item.name +
          "</strong><span>" +
          healthLabel(item.status) +
          "</span></div></div>"
        );
      })
      .join("");
  }

  function renderChart(hourly) {
    var svg = document.getElementById("productionChart");
    if (!svg || !hourly || !hourly.length) return;
    var w = 600,
      h = 220,
      pad = 24;
    var max = Math.max.apply(null, hourly.concat([1]));
    var stepX = (w - pad * 2) / Math.max(hourly.length - 1, 1);
    var points = hourly.map(function (v, i) {
      var x = pad + i * stepX;
      var y = h - pad - (v / max) * (h - pad * 2);
      return [x, y];
    });
    var linePath = points
      .map(function (p, i) {
        return (i === 0 ? "M" : "L") + p[0] + "," + p[1];
      })
      .join(" ");
    var areaPath =
      linePath +
      " L" +
      points[points.length - 1][0] +
      "," +
      (h - pad) +
      " L" +
      points[0][0] +
      "," +
      (h - pad) +
      " Z";
    svg.setAttribute("viewBox", "0 0 " + w + " " + h);
    svg.innerHTML =
      "<defs><linearGradient id=\"chartGrad\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\">" +
      '<stop offset="0%" stop-color="var(--color-accent)" stop-opacity="0.35" />' +
      '<stop offset="100%" stop-color="var(--color-accent)" stop-opacity="0" />' +
      "</linearGradient></defs>" +
      '<line x1="' +
      pad +
      '" y1="' +
      (h - pad) +
      '" x2="' +
      (w - pad) +
      '" y2="' +
      (h - pad) +
      '" stroke="var(--border-color)" stroke-width="1" />' +
      '<path d="' +
      areaPath +
      '" fill="url(#chartGrad)" />' +
      '<path d="' +
      linePath +
      '" fill="none" stroke="var(--color-accent)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />';
  }

  function bindControls(s) {
    if (!s || !s.modes) return;
    var toggles = {
      energySavingToggle: "energySaving",
      gridPriorityToggle: "gridPriority",
      solarPriorityToggle: "solarPriority",
    };
    Object.keys(toggles).forEach(function (elId) {
      var key = toggles[elId];
      var el = document.getElementById(elId);
      if (!el) return;
      el.checked = !!s.modes[key];
      el.addEventListener("change", function () {
        window.HamTabData
          .updateSystemModes(s.systemId, { [key]: el.checked })
          .then(function () {
            HamTabUI.showToast({ title: el.checked ? "حالت فعال شد" : "حالت غیرفعال شد", type: "success" });
          })
          .catch(function (err) {
            el.checked = !el.checked;
            HamTabUI.showToast({ title: "ذخیره تنظیم انجام نشد", message: err.message, type: "error" });
          });
      });
    });

    var reserveSlider = document.getElementById("reserveSlider");
    var reserveValue = document.getElementById("reserveValue");
    if (reserveSlider) {
      reserveSlider.value = s.modes.batteryReserve;
      if (reserveValue) reserveValue.textContent = HamTabUI.toFa(s.modes.batteryReserve) + "٪";
      reserveSlider.addEventListener("input", function () {
        if (reserveValue) reserveValue.textContent = HamTabUI.toFa(reserveSlider.value) + "٪";
      });
      reserveSlider.addEventListener("change", function () {
        window.HamTabData
          .updateSystemModes(s.systemId, { batteryReserve: Number(reserveSlider.value) })
          .catch(function (err) {
            HamTabUI.showToast({ title: "ذخیره تنظیم انجام نشد", message: err.message, type: "error" });
          });
      });
    }
  }

  function applyState(state, opts) {
    opts = opts || {};
    liveState = state;
    usingCache = !!opts.fromCache;
    renderMetrics(state);
    renderBattery(state);
    if (state.componentHealth) renderHealth(state.componentHealth);
    if (state.hourlyProduction) renderChart(state.hourlyProduction);
    if (!opts.skipControls) bindControls(state);

    var conn = opts.forceConnection || state.connection || "UNKNOWN";
    renderConnection(conn);
    renderLastUpdated(opts.savedAt || lastGoodAt || Date.now(), usingCache);
    renderOfflineBanner(!!opts.showOfflineBanner, opts.offlineMessage);
  }

  async function poll(manual) {
    if (window.HamTabOffline && window.HamTabOffline.isBrowserOffline()) {
      var cachedOff = loadCache();
      if (cachedOff && cachedOff.data) {
        applyState(cachedOff.data, {
          fromCache: true,
          savedAt: cachedOff.savedAt,
          forceConnection: "OFFLINE",
          showOfflineBanner: true,
          skipControls: true,
        });
      } else {
        renderConnection("OFFLINE");
        renderOfflineBanner(true, "ارتباط اینترنت برقرار نیست و دادهٔ ذخیره‌شده‌ای هم موجود نیست.");
      }
      return;
    }

    try {
      var state = await window.HamTabData.getControllerState();
      if (!state) return;
      saveCache(state);
      applyState(state, {
        fromCache: false,
        savedAt: Date.now(),
        forceConnection: state.connection || "LIVE",
        showOfflineBanner: false,
        skipControls: !manual && !!liveState,
      });
    } catch (err) {
      var cached = loadCache();
      if (cached && cached.data) {
        applyState(cached.data, {
          fromCache: true,
          savedAt: cached.savedAt,
          forceConnection: "CACHED",
          showOfflineBanner: true,
          offlineMessage: "ارتباط با سرور برقرار نشد. آخرین دادهٔ ذخیره‌شده نمایش داده می‌شود.",
          skipControls: true,
        });
      } else {
        renderConnection("UNKNOWN");
        renderOfflineBanner(true, "ارتباط با سرور برقرار نشد و دادهٔ قبلی هم در دسترس نیست.");
      }
    }
  }

  function wxIcon(condition) {
    var map = { clear: "☀️", partly_cloudy: "🌤", cloudy: "☁️", dusty: "🌪", rainy: "🌧", storm: "⛈" };
    return map[condition] || "🌤";
  }
  function wxBarWidth(impact) {
    return Math.max(40, 100 + (impact || 0));
  }
  async function loadWeatherOutlook() {
    var host = document.getElementById("weatherAlertBanner");
    if (!host || !window.HamTabData.getWeatherOutlook) return;
    try {
      var outlook = await window.HamTabData.getWeatherOutlook({ days: 3 });
      if (!outlook) return;
      var days = outlook.days || [];
      var alerts = outlook.alerts || [];
      var summary = outlook.summary || {};
      var worstImpact = summary.worstImpactPercent || 0;
      var dayCards = days
        .map(function (d) {
          var cls = d.severity === "danger" ? "is-danger" : d.severity === "warning" ? "is-warning" : "is-ok";
          var bar = wxBarWidth(d.productionImpactPercent);
          var impactText =
            d.productionImpactPercent === 0
              ? "تولید در سطح عادی"
              : Math.abs(d.productionImpactPercent) + "٪ کمتر از روز صاف";
          return (
            '<div class="wx-day ' +
            cls +
            '"><div class="wx-day__icon" aria-hidden="true">' +
            wxIcon(d.condition) +
            '</div><p class="wx-day__cond">' +
            d.conditionFa +
            '</p><div class="wx-day__date">' +
            d.date +
            '</div><div class="wx-day__bar"><i style="width:' +
            bar +
            '%"></i></div><div class="wx-day__impact">' +
            impactText +
            "</div></div>"
          );
        })
        .join("");
      var alertBlock = "";
      if (alerts.length) {
        var sev = alerts.some(function (a) {
          return a.severity === "danger";
        })
          ? "is-danger"
          : "";
        alertBlock =
          '<div class="wx-panel__alerts ' +
          sev +
          '">' +
          alerts
            .slice(0, 2)
            .map(function (a) {
              return "<p><strong>" + a.title + "</strong> — " + a.body + "</p>";
            })
            .join("") +
          "</div>";
      }
      var impactHero = worstImpact === 0 ? "۰٪" : worstImpact + "٪";
      host.hidden = false;
      host.innerHTML =
        '<div class="wx-panel__hero"><div class="wx-panel__hero-main"><span class="wx-panel__eyebrow">هوش انرژی · آب‌وهوا</span><h2 class="wx-panel__title">چشم‌انداز تولید سه‌روزه</h2><span class="wx-panel__city">' +
        (outlook.city || "ایران") +
        ' · مدل تخمینی</span></div><div class="wx-panel__impact"><span class="wx-panel__impact-value">' +
        impactHero +
        '</span><span class="wx-panel__impact-label">بدترین افت مورد انتظار در بازه</span></div></div><div class="wx-panel__days">' +
        dayCards +
        "</div>" +
        alertBlock +
        '<p class="wx-panel__foot">' +
        (outlook.disclaimer || "") +
        "</p>";
    } catch (e) {
      console.warn("weather outlook failed", e);
    }
  }

  async function init() {
    loadWeatherOutlook();

    // Try network first; on failure fall back to cache
    try {
      if (window.HamTabOffline && window.HamTabOffline.isBrowserOffline()) {
        throw new Error("browser offline");
      }
      liveState = await window.HamTabData.getControllerState();
      if (liveState) {
        saveCache(liveState);
        applyState(liveState, {
          fromCache: false,
          savedAt: Date.now(),
          forceConnection: liveState.connection || "LIVE",
          showOfflineBanner: false,
        });
        pollTimer = setInterval(function () {
          poll(false);
        }, 5000);
        return;
      }
    } catch (e) {
      var cached = loadCache();
      if (cached && cached.data) {
        applyState(cached.data, {
          fromCache: true,
          savedAt: cached.savedAt,
          forceConnection: "OFFLINE",
          showOfflineBanner: true,
        });
        pollTimer = setInterval(function () {
          poll(false);
        }, 8000);
        return;
      }
    }

    // No system and no cache
    var header = document.querySelector(".ctrl-header");
    if (header) {
      header.insertAdjacentHTML(
        "beforeend",
        HamTabUI.stateBlockHTML({
          icon: "🔌",
          title: "هنوز سیستمی برای شما ثبت نشده است",
          desc: "پس از خرید و پرداخت یک پکیج، کنترلر آن اینجا نمایش داده می‌شود.",
        })
      );
    }
  }

  document.addEventListener("DOMContentLoaded", init);
  window.addEventListener("beforeunload", function () {
    if (pollTimer) clearInterval(pollTimer);
  });
  window.addEventListener("online", function () {
    poll(true);
  });
  window.addEventListener("offline", function () {
    poll(false);
  });
})();
