/* =========================================================
   هم‌تاب (HamTab) — Navigation Behavior
   ========================================================= */

(function () {
  "use strict";

  function initHeaderScroll() {
    const header = document.querySelector(".site-header");
    if (!header) return;
    const onScroll = () => header.classList.toggle("is-scrolled", window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  function initMobileNav() {
    const toggle = document.querySelector(".nav-toggle");
    const drawer = document.querySelector(".mobile-nav");
    if (!toggle || !drawer) return;

    function close() {
      drawer.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      document.body.classList.remove("no-scroll");
    }

    function open() {
      drawer.classList.add("is-open");
      toggle.setAttribute("aria-expanded", "true");
      document.body.classList.add("no-scroll");
    }

    toggle.addEventListener("click", () => {
      const isOpen = drawer.classList.contains("is-open");
      isOpen ? close() : open();
    });

    drawer.querySelectorAll("a").forEach((a) => a.addEventListener("click", close));

    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") close();
    });
  }

  function markCurrentPage() {
    const path = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll("a[data-nav-link]").forEach((link) => {
      const linkPath = link.getAttribute("href").split("/").pop();
      if (linkPath === path) link.setAttribute("aria-current", "page");
    });
  }

  function initials(name) {
    if (!name) return "؟";
    const parts = name.trim().split(/\s+/);
    return parts.slice(0, 2).map((p) => p[0]).join("");
  }

  function inPagesDir() {
    return location.pathname.includes("/pages/");
  }

  function pageHref(file) {
    return inPagesDir() ? file : "pages/" + file;
  }

  function ensureUserMenu() {
    let menu = document.getElementById("headerUserMenu");
    if (menu) return menu;
    const actions = document.querySelector(".header-actions");
    if (!actions) return null;

    // Remove plain logout / empty avatar links if present (we replace with menu)
    actions.querySelectorAll("#headerLogoutBtn, a.btn-icon[data-auth-only]").forEach((el) => el.remove());

    menu = document.createElement("div");
    menu.id = "headerUserMenu";
    menu.className = "user-menu";
    menu.setAttribute("data-auth-only", "");
    menu.innerHTML = `
      <button type="button" class="user-menu__trigger" id="userMenuBtn" aria-expanded="false" aria-haspopup="true">
        <span class="user-menu__avatar" data-user-initials></span>
        <span class="user-menu__meta">
          <span class="user-menu__name" data-user-name></span>
          <span class="user-menu__hint">حساب کاربری</span>
        </span>
        <svg class="user-menu__caret" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
      </button>
      <div class="user-menu__dropdown" id="userMenuDropdown" hidden>
        <a class="user-menu__item" data-user-link="dashboard" href="#">
          <span class="user-menu__icon">📊</span> داشبورد من
        </a>
        <a class="user-menu__item" data-user-link="admin" href="#" data-admin-only>
          <span class="user-menu__icon">⚙️</span> مدیریت سایت
        </a>
        <button type="button" class="user-menu__item user-menu__item--danger" id="headerLogoutBtn">
          <span class="user-menu__icon">🚪</span> خروج
        </button>
      </div>
    `;
    const toggle = actions.querySelector(".nav-toggle");
    if (toggle) actions.insertBefore(menu, toggle);
    else actions.appendChild(menu);
    return menu;
  }

  function initUserMenu() {
    const menu = ensureUserMenu();
    if (!menu) return;
    const btn = menu.querySelector("#userMenuBtn");
    const drop = menu.querySelector("#userMenuDropdown");
    if (!btn || !drop || btn.dataset.bound) return;
    btn.dataset.bound = "1";

    const close = () => {
      drop.hidden = true;
      btn.setAttribute("aria-expanded", "false");
      menu.classList.remove("is-open");
    };
    const open = () => {
      drop.hidden = false;
      btn.setAttribute("aria-expanded", "true");
      menu.classList.add("is-open");
    };

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (drop.hidden) open();
      else close();
    });
    document.addEventListener("click", (e) => {
      if (!menu.contains(e.target)) close();
    });
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") close();
    });

    menu.querySelectorAll("[data-user-link]").forEach((a) => {
      const key = a.getAttribute("data-user-link");
      if (key === "dashboard") a.href = pageHref("dashboard.html");
      if (key === "admin") a.href = pageHref("dashboard.html") + "#admin-hub";
    });
  }

  async function applyAuthState() {
    let user = { isAuthenticated: false, name: "", role: "" };
    try {
      if (window.HamTabData) user = await window.HamTabData.getCurrentUser();
    } catch (_) {
      user = { isAuthenticated: false, name: "", role: "" };
    }

    initUserMenu();

    document.body.classList.toggle("is-logged-in", !!user.isAuthenticated);
    document.body.classList.toggle("is-admin", !!(user.isAuthenticated && user.role === "ADMIN"));
    document.body.classList.add("auth-ready");

    document.querySelectorAll("[data-user-name]").forEach((el) => {
      el.textContent = user.isAuthenticated ? (user.name || "") : "";
    });
    document.querySelectorAll("[data-user-initials]").forEach((el) => {
      el.textContent = user.isAuthenticated ? initials(user.name) : "";
    });

    // Hide legacy standalone dashboard nav links in main nav (keep in user menu)
    document.querySelectorAll('.main-nav__list [data-auth-only], .mobile-nav [data-auth-only]').forEach((el) => {
      if (el.querySelector && el.querySelector('a[href*="dashboard"]')) {
        el.style.display = "none";
      }
      if (el.matches && el.matches('a[href*="dashboard"]')) el.style.display = "none";
    });
    document.querySelectorAll('a[href*="dashboard.html"][data-nav-link]').forEach((a) => {
      const li = a.closest("li");
      if (li) li.style.display = "none";
      else a.style.display = "none";
    });
    document.querySelectorAll('a[href*="admin.html"][data-nav-link]').forEach((a) => {
      const li = a.closest("li");
      if (li) li.style.display = "none";
      else a.style.display = "none";
    });

    const logoutBtn = document.getElementById("headerLogoutBtn");
    if (logoutBtn && !logoutBtn.dataset.bound) {
      logoutBtn.dataset.bound = "1";
      logoutBtn.addEventListener("click", async () => {
        await window.HamTabData.logout();
        location.href = pageHref("login.html");
      });
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.body.classList.remove("is-logged-in", "is-admin");
    initHeaderScroll();
    initMobileNav();
    markCurrentPage();
    applyAuthState();
  });
})();
