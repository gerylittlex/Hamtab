/* =========================================================
   هم‌تاب (HamTab) — Animation Orchestration
   ========================================================= */

(function (global) {
  "use strict";

  let observer = null;

  function ensureObserver() {
    if (observer) return observer;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion) return null;
    observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -20px 0px" }
    );
    return observer;
  }

  /** Reveal any [data-reveal] not yet visible (for dynamically injected cards). */
  function revealNew() {
    const items = document.querySelectorAll("[data-reveal]:not(.is-visible)");
    if (!items.length) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion) {
      items.forEach((el) => el.classList.add("is-visible"));
      return;
    }
    const obs = ensureObserver();
    items.forEach((el, i) => {
      el.style.setProperty("--delay", `${Math.min(i % 6, 5) * 80}ms`);
      // If already in viewport (or observer missing), show immediately
      if (!obs) {
        el.classList.add("is-visible");
        return;
      }
      const rect = el.getBoundingClientRect();
      const inView = rect.top < window.innerHeight && rect.bottom > 0;
      if (inView) {
        el.classList.add("is-visible");
      } else {
        obs.observe(el);
      }
    });
  }

  function initScrollReveal() {
    revealNew();
  }

  document.addEventListener("DOMContentLoaded", initScrollReveal);

  global.HamTabAnimations = { revealNew };
})(window);
