/* =========================================================
   هم‌تاب (HamTab) — Reusable UI Component Behaviors
   ========================================================= */

(function (global) {
  "use strict";

  function escapeHtml(value) {
    if (value === null || value === undefined) return "";
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }


  /* ---------------------------------------------------------
     Toasts
  --------------------------------------------------------- */
  function ensureToastStack() {
    let stack = document.querySelector(".toast-stack");
    if (!stack) {
      stack = document.createElement("div");
      stack.className = "toast-stack";
      stack.setAttribute("role", "status");
      stack.setAttribute("aria-live", "polite");
      document.body.appendChild(stack);
    }
    return stack;
  }

  function showToast({ title, message = "", type = "default", duration = 4200 }) {
    const stack = ensureToastStack();
    const toast = document.createElement("div");
    const typeClass = { success: "toast-success", warning: "toast-warning", danger: "toast-danger", error: "toast-danger" }[type] || "";
    toast.className = `toast ${typeClass}`.trim();
    toast.innerHTML = `
      <div>
        <strong>${escapeHtml(title)}</strong>
        ${message ? `<p>${escapeHtml(message)}</p>` : ""}
      </div>
    `;
    stack.appendChild(toast);

    const remove = () => {
      toast.classList.add("is-leaving");
      setTimeout(() => toast.remove(), 260);
    };
    setTimeout(remove, duration);
    toast.addEventListener("click", remove);
  }

  /* ---------------------------------------------------------
     Modal
  --------------------------------------------------------- */
  let lastFocusedEl = null;

  function openModal(overlayEl) {
    if (!overlayEl) return;
    lastFocusedEl = document.activeElement;
    overlayEl.classList.add("is-open");
    document.body.classList.add("no-scroll");
    const focusable = overlayEl.querySelector("[data-autofocus], button, input, select, textarea, a[href]");
    if (focusable) focusable.focus();

    function onKeydown(e) {
      if (e.key === "Escape") closeModal(overlayEl);
    }
    overlayEl._onKeydown = onKeydown;
    document.addEventListener("keydown", onKeydown);
  }

  function closeModal(overlayEl) {
    if (!overlayEl) return;
    overlayEl.classList.remove("is-open");
    document.body.classList.remove("no-scroll");
    if (overlayEl._onKeydown) document.removeEventListener("keydown", overlayEl._onKeydown);
    if (lastFocusedEl) lastFocusedEl.focus();
  }

  function initModalTriggers(root = document) {
    root.querySelectorAll("[data-open-modal]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const target = document.getElementById(btn.dataset.openModal);
        openModal(target);
      });
    });
    root.querySelectorAll("[data-close-modal]").forEach((btn) => {
      btn.addEventListener("click", () => {
        closeModal(btn.closest(".modal-overlay"));
      });
    });
    root.querySelectorAll(".modal-overlay").forEach((overlay) => {
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) closeModal(overlay);
      });
    });
  }

  /* ---------------------------------------------------------
     Tabs
  --------------------------------------------------------- */
  function initTabs(root = document) {
    root.querySelectorAll("[data-tabs]").forEach((tabGroup) => {
      const tabs = Array.from(tabGroup.querySelectorAll(".tabs__tab"));
      const panels = tabs.map((t) => document.getElementById(t.getAttribute("aria-controls")));

      tabs.forEach((tab, i) => {
        tab.addEventListener("click", () => {
          tabs.forEach((t) => t.setAttribute("aria-selected", "false"));
          panels.forEach((p) => p && p.setAttribute("hidden", ""));
          tab.setAttribute("aria-selected", "true");
          if (panels[i]) panels[i].removeAttribute("hidden");
        });
      });
    });
  }

  /* ---------------------------------------------------------
     Dropdown
  --------------------------------------------------------- */
  function initDropdowns(root = document) {
    root.querySelectorAll(".dropdown").forEach((dropdown) => {
      const trigger = dropdown.querySelector("[data-dropdown-trigger]");
      const menu = dropdown.querySelector(".dropdown__menu");
      if (!trigger || !menu) return;

      trigger.addEventListener("click", (e) => {
        e.stopPropagation();
        const isOpen = menu.classList.contains("is-open");
        document.querySelectorAll(".dropdown__menu.is-open").forEach((m) => m.classList.remove("is-open"));
        menu.classList.toggle("is-open", !isOpen);
        trigger.setAttribute("aria-expanded", String(!isOpen));
      });
    });

    document.addEventListener("click", () => {
      document.querySelectorAll(".dropdown__menu.is-open").forEach((m) => m.classList.remove("is-open"));
    });
  }

  /* ---------------------------------------------------------
     Animated number counters
  --------------------------------------------------------- */
  function animateCounter(el, targetValue, { duration = 1200, decimals = 0, prefix = "", suffix = "" } = {}) {
    const start = 0;
    const startTime = performance.now();
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (reduceMotion) {
      el.textContent = prefix + targetValue.toFixed(decimals) + suffix;
      return;
    }

    function tick(now) {
      const progress = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = start + (targetValue - start) * eased;
      el.textContent = prefix + value.toFixed(decimals) + suffix;
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = prefix + targetValue.toFixed(decimals) + suffix;
    }
    requestAnimationFrame(tick);
  }

  function animateProgressBar(el, percent) {
    requestAnimationFrame(() => {
      el.style.width = Math.max(0, Math.min(100, percent)) + "%";
    });
  }

  function animateProgressRing(circleEl, percent, radius) {
    const circumference = 2 * Math.PI * radius;
    circleEl.style.strokeDasharray = `${circumference} ${circumference}`;
    requestAnimationFrame(() => {
      const offset = circumference - (Math.max(0, Math.min(100, percent)) / 100) * circumference;
      circleEl.style.strokeDashoffset = offset;
    });
  }

  /* ---------------------------------------------------------
     Confirmation dialog helper
  --------------------------------------------------------- */
  function confirmAction({ title, message, confirmLabel = "تأیید", cancelLabel = "انصراف", danger = false }) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.className = "modal-overlay confirm-dialog";
      overlay.innerHTML = `
        <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title">
          <div class="confirm-dialog__icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v4m0 4h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/></svg>
          </div>
          <div class="modal__body">
            <h3 id="confirm-title" style="margin-bottom:8px;">${title}</h3>
            <p class="text-secondary">${message}</p>
          </div>
          <div class="confirm-dialog__actions">
            <button class="btn btn-outline" data-action="cancel">${cancelLabel}</button>
            <button class="btn ${danger ? "btn-cta" : "btn-primary"}" data-action="confirm">${confirmLabel}</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      requestAnimationFrame(() => openModal(overlay));

      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) {
          closeModal(overlay);
          setTimeout(() => overlay.remove(), 260);
          resolve(false);
        }
      });

      overlay.querySelector('[data-action="cancel"]').addEventListener("click", () => {
        closeModal(overlay);
        setTimeout(() => overlay.remove(), 260);
        resolve(false);
      });

      overlay.querySelector('[data-action="confirm"]').addEventListener("click", () => {
        closeModal(overlay);
        setTimeout(() => overlay.remove(), 260);
        resolve(true);
      });
    });
  }

  /* ---------------------------------------------------------
     State-block markup helper (loading / empty / error)
  --------------------------------------------------------- */
  function stateBlockHTML({ icon = "info", title, desc = "", variant = "" }) {
    return `
      <div class="state-block ${variant}">
        <div class="state-block__icon">${icon}</div>
        <div class="state-block__title">${title}</div>
        ${desc ? `<p>${desc}</p>` : ""}
      </div>
    `;
  }

  /* ---------------------------------------------------------
     Persian digit / number formatting helper
  --------------------------------------------------------- */
  const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
  function toFa(value) {
    return String(value).replace(/[0-9]/g, (d) => FA_DIGITS[d]);
  }
  function formatToman(value) {
    return toFa(Math.round(value).toLocaleString("en-US")) + " تومان";
  }

  global.HamTabUI = {
    escapeHtml,
    showToast,
    toFa,
    formatToman,
    openModal,
    closeModal,
    initModalTriggers,
    initTabs,
    initDropdowns,
    animateCounter,
    animateProgressBar,
    animateProgressRing,
    confirmAction,
    stateBlockHTML,
  };
})(window);
