import test from "node:test";
import assert from "node:assert/strict";
import { startTestServer } from "./helpers.js";

test("register -> login -> me", async () => {
  const server = await startTestServer();
  try {
    const reg = await server.call("POST", "/api/auth/register", {
      body: { name: "Sara", email: "sara@example.com", password: "password123" },
    });
    assert.equal(reg.status, 201);
    assert.ok(reg.json.token);
    assert.equal(reg.json.user.email, "sara@example.com");

    const dupe = await server.call("POST", "/api/auth/register", {
      body: { name: "Sara2", email: "sara@example.com", password: "password123" },
    });
    assert.equal(dupe.status, 409, "duplicate email must be rejected");

    const badLogin = await server.call("POST", "/api/auth/login", {
      body: { email: "sara@example.com", password: "wrong-password" },
    });
    assert.equal(badLogin.status, 401);

    const login = await server.call("POST", "/api/auth/login", {
      body: { email: "sara@example.com", password: "password123" },
    });
    assert.equal(login.status, 200);

    const me = await server.call("GET", "/api/auth/me", { token: login.json.token });
    assert.equal(me.json.user.email, "sara@example.com");

    const meNoToken = await server.call("GET", "/api/auth/me", {});
    assert.equal(meNoToken.json.user, null);
  } finally {
    await server.close();
  }
});

test("weak password / bad email rejected", async () => {
  const server = await startTestServer();
  try {
    const shortPw = await server.call("POST", "/api/auth/register", {
      body: { name: "X", email: "x@example.com", password: "short" },
    });
    assert.equal(shortPw.status, 400);

    const badEmail = await server.call("POST", "/api/auth/register", {
      body: { name: "X", email: "not-an-email", password: "password123" },
    });
    assert.equal(badEmail.status, 400);
  } finally {
    await server.close();
  }
});
