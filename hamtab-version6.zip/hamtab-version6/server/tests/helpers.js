process.env.NODE_ENV = "test";
process.env.SESSION_SECRET = "test-secret";

import http from "node:http";
import { createRouter, dispatch } from "../src/router.js";
import { registerAuthRoutes } from "../src/routes/auth.js";
import { registerPackageRoutes } from "../src/routes/packages.js";
import { registerSolarRoutes } from "../src/routes/solar.js";
import { registerOrderRoutes } from "../src/routes/orders.js";
import { registerSystemRoutes } from "../src/routes/systems.js";
import { registerNotificationRoutes } from "../src/routes/notifications.js";
import { registerNeighborhoodRoutes } from "../src/routes/neighborhoods.js";
import { registerProfileRoutes } from "../src/routes/profile.js";

export async function startTestServer() {
  const router = createRouter();
  registerAuthRoutes(router);
  registerPackageRoutes(router);
  registerSolarRoutes(router);
  registerOrderRoutes(router);
  registerSystemRoutes(router);
  registerNotificationRoutes(router);
  registerNeighborhoodRoutes(router);
  registerProfileRoutes(router);
  const handle = dispatch(router);

  const server = http.createServer(async (req, res) => {
    const matched = await handle(req, res);
    if (!matched) res.json(404, { error: "Not found" });
  });

  await new Promise((resolve) => server.listen(0, resolve));
  const { port } = server.address();
  const base = `http://localhost:${port}`;

  return {
    base,
    close: () => new Promise((resolve) => server.close(resolve)),
    async call(method, path, { body, token } = {}) {
      const res = await fetch(base + path, {
        method,
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      let json = null;
      try {
        json = await res.json();
      } catch {
        /* no body */
      }
      return { status: res.status, json };
    },
  };
}

export async function seedPackage() {
  const { db } = await import("../src/db.js");
  db.prepare(
    `INSERT OR IGNORE INTO packages (id, name, tier, capacity_kw, panels, battery_kwh, daily_production_kwh, price, components_json)
     VALUES ('pkg-home','هوم','home',5.4,12,5,24,152000000,'[]')`
  ).run();
}
