import test from "node:test";
import assert from "node:assert/strict";
import { startTestServer, seedPackage } from "./helpers.js";

async function registerUser(server, email) {
  const r = await server.call("POST", "/api/auth/register", {
    body: { name: "User", email, password: "password123" },
  });
  return r.json.token;
}

test("order creation ignores client-supplied price (server authoritative)", async () => {
  const server = await startTestServer();
  try {
    await seedPackage();
    const token = await registerUser(server, "buyer@example.com");

    const order = await server.call("POST", "/api/orders", {
      token,
      body: { packageId: "pkg-home", price: 1, address: "Tehran" },
    });
    assert.equal(order.status, 201);
    assert.equal(order.json.order.price, 152000000, "price must come from the packages table, not the request");
  } finally {
    await server.close();
  }
});

test("unauthenticated order creation is rejected", async () => {
  const server = await startTestServer();
  try {
    await seedPackage();
    const res = await server.call("POST", "/api/orders", { body: { packageId: "pkg-home" } });
    assert.equal(res.status, 401);
  } finally {
    await server.close();
  }
});

test("a user cannot read another user's order (IDOR)", async () => {
  const server = await startTestServer();
  try {
    await seedPackage();
    const tokenA = await registerUser(server, "a@example.com");
    const tokenB = await registerUser(server, "b@example.com");

    const order = await server.call("POST", "/api/orders", { token: tokenA, body: { packageId: "pkg-home" } });
    const orderId = order.json.order.id;

    const asOwner = await server.call("GET", `/api/orders/${orderId}`, { token: tokenA });
    assert.equal(asOwner.status, 200);

    const asOther = await server.call("GET", `/api/orders/${orderId}`, { token: tokenB });
    assert.equal(asOther.status, 403);
  } finally {
    await server.close();
  }
});

test("idempotency key prevents duplicate orders from a retried request", async () => {
  const server = await startTestServer();
  try {
    await seedPackage();
    const token = await registerUser(server, "retry@example.com");
    const key = "idem-key-123";

    const first = await fetch(server.base + "/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, "Idempotency-Key": key },
      body: JSON.stringify({ packageId: "pkg-home" }),
    }).then((r) => r.json());

    const second = await fetch(server.base + "/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, "Idempotency-Key": key },
      body: JSON.stringify({ packageId: "pkg-home" }),
    }).then((r) => r.json());

    assert.equal(first.order.id, second.order.id, "retried request with same idempotency key must not create a second order");

    const list = await server.call("GET", "/api/orders", { token });
    assert.equal(list.json.orders.length, 1);
  } finally {
    await server.close();
  }
});

test("paying an order provisions a solar system and a notification", async () => {
  const server = await startTestServer();
  try {
    await seedPackage();
    const token = await registerUser(server, "pay@example.com");
    const order = await server.call("POST", "/api/orders", { token, body: { packageId: "pkg-home" } });
    const orderId = order.json.order.id;

    const pay = await server.call("POST", `/api/orders/${orderId}/pay`, { token });
    assert.equal(pay.status, 200);
    assert.equal(pay.json.order.payment, "PAID");

    const doublePay = await server.call("POST", `/api/orders/${orderId}/pay`, { token });
    assert.equal(doublePay.status, 409, "an already-paid order must not be charged again");

    const systems = await server.call("GET", "/api/systems", { token });
    assert.equal(systems.json.systems.length, 1);

    const notifications = await server.call("GET", "/api/notifications", { token });
    assert.ok(notifications.json.notifications.length >= 1);
  } finally {
    await server.close();
  }
});

test("a forced-decline test payment leaves the order unpaid", async () => {
  const server = await startTestServer();
  try {
    const { db } = await import("../src/db.js");
    // amount % 1000 === 13 is the dev-simulator's deterministic decline hook
    db.prepare(
      `INSERT INTO packages (id, name, tier, capacity_kw, panels, battery_kwh, daily_production_kwh, price, components_json)
       VALUES ('pkg-decline-test','Decline Test','test',1,1,0,1,1013,'[]')`
    ).run();
    const token = await registerUser(server, "declinetest@example.com");
    const order = await server.call("POST", "/api/orders", { token, body: { packageId: "pkg-decline-test" } });
    const pay = await server.call("POST", `/api/orders/${order.json.order.id}/pay`, { token });
    assert.equal(pay.status, 402);

    const fetched = await server.call("GET", `/api/orders/${order.json.order.id}`, { token });
    assert.equal(fetched.json.order.payment, "FAILED");
    assert.notEqual(fetched.json.order.status, "CONFIRMED", "a declined payment must not confirm the order");
  } finally {
    await server.close();
  }
});
