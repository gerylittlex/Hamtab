import test from "node:test";
import assert from "node:assert/strict";
import { startTestServer } from "./helpers.js";

async function registerUser(server, email) {
  const r = await server.call("POST", "/api/auth/register", {
    body: { name: "User", email, password: "password123" },
  });
  return r.json.token;
}

test("joining a neighborhood twice is rejected", async () => {
  const server = await startTestServer();
  try {
    const token = await registerUser(server, "member@example.com");
    const created = await server.call("POST", "/api/neighborhoods", {
      token,
      body: { name: "Test Neighborhood", location: "Tehran", homes: 20, interestedHomes: 2 },
    });
    assert.equal(created.status, 201);
    const nbId = created.json.neighborhood.id;
    assert.equal(created.json.neighborhood.participants, 1, "creator auto-joins once, not twice");

    const otherToken = await registerUser(server, "member2@example.com");
    const join1 = await server.call("POST", `/api/neighborhoods/${nbId}/join`, { token: otherToken });
    assert.equal(join1.status, 200);
    assert.equal(join1.json.neighborhood.participants, 2);

    const join2 = await server.call("POST", `/api/neighborhoods/${nbId}/join`, { token: otherToken });
    assert.equal(join2.status, 409, "the same user must not be able to join twice");
  } finally {
    await server.close();
  }
});

test("solar calculator returns deterministic, non-random results", async () => {
  const server = await startTestServer();
  try {
    const input = { monthlyBill: 3500000, roofArea: 40, independence: 80 };
    const a = await server.call("POST", "/api/solar/calculate", { body: input });
    const b = await server.call("POST", "/api/solar/calculate", { body: input });
    assert.deepEqual(a.json.result, b.json.result, "same input must always produce the same output");
    assert.ok(a.json.result.recommendedCapacityKw > 0);
    assert.ok(a.json.result.assumptions, "assumptions must be disclosed, not hidden");
  } finally {
    await server.close();
  }
});

test("calculator rejects negative input", async () => {
  const server = await startTestServer();
  try {
    const res = await server.call("POST", "/api/solar/calculate", { body: { monthlyBill: -1 } });
    assert.equal(res.status, 400);
  } finally {
    await server.close();
  }
});
