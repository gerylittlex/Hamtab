import { db } from "./src/db.js";
import { hashPassword, newId } from "./src/crypto-utils.js";

const PACKAGES = [
  { id: "pkg-starter", name: "استارتر", tier: "starter", capacityKw: 2.2, panels: 5, batteryKwh: 0, dailyProductionKwh: 9, price: 68000000, usage: "مناسب آپارتمان‌های کوچک", homeSize: "کوچک", installAvailability: "۲ تا ۳ هفته", warranty: "۵ سال گارانتی اینورتر، ۱۲ سال پنل", roi: "حدود ۴٫۵ سال", components: ["۵ پنل خورشیدی ۴۴۰ وات", "اینورتر تک‌فاز ۲ کیلووات", "کیت نصب و کابل‌کشی"], popular: 0 },
  { id: "pkg-home", name: "هوم", tier: "home", capacityKw: 5.4, panels: 12, batteryKwh: 5, dailyProductionKwh: 24, price: 152000000, usage: "مناسب خانه‌های متوسط با مصرف روزانه", homeSize: "متوسط", installAvailability: "۳ تا ۴ هفته", warranty: "۱۰ سال گارانتی اینورتر و باتری، ۲۵ سال پنل", roi: "حدود ۳٫۸ سال", components: ["۱۲ پنل خورشیدی ۴۵۰ وات", "اینورتر هیبریدی ۵ کیلووات", "باتری لیتیومی ۵ کیلووات‌ساعت"], popular: 1 },
  { id: "pkg-plus", name: "پلاس", tier: "plus", capacityKw: 8.1, panels: 18, batteryKwh: 10, dailyProductionKwh: 36, price: 238000000, usage: "مناسب خانه‌های بزرگ یا مصرف بالا", homeSize: "بزرگ", installAvailability: "۴ تا ۶ هفته", warranty: "۱۰ سال گارانتی اینورتر و باتری، ۲۵ سال پنل", roi: "حدود ۳٫۴ سال", components: ["۱۸ پنل خورشیدی ۴۵۰ وات", "اینورتر هیبریدی ۸ کیلووات", "باتری لیتیومی ۱۰ کیلووات‌ساعت", "مانیتورینگ هوشمند"], popular: 0 },
  { id: "pkg-advanced", name: "ادونسد", tier: "advanced", capacityKw: 12, panels: 27, batteryKwh: 15, dailyProductionKwh: 54, price: 349000000, usage: "استقلال کامل از شبکه برق", homeSize: "ویلایی", installAvailability: "۵ تا ۷ هفته", warranty: "۱۲ سال گارانتی اینورتر و باتری، ۲۵ سال پنل", roi: "حدود ۳٫۱ سال", components: ["۲۷ پنل خورشیدی ۴۵۰ وات", "اینورتر هیبریدی ۱۲ کیلووات", "باتری لیتیومی ۱۵ کیلووات‌ساعت", "کنترلر هوشمند خانگی"], popular: 0 },
  { id: "pkg-commercial", name: "کامرشیال", tier: "commercial", capacityKw: 30, panels: 66, batteryKwh: 40, dailyProductionKwh: 135, price: 890000000, usage: "مناسب کسب‌وکار، کارگاه و مجتمع تجاری", homeSize: "تجاری", installAvailability: "۶ تا ۱۰ هفته", warranty: "۱۵ سال گارانتی اینورتر و باتری، ۲۵ سال پنل", roi: "حدود ۲٫۹ سال", components: ["۶۶ پنل خورشیدی ۴۵۰ وات", "اینورتر سه‌فاز ۳۰ کیلووات", "باتری لیتیومی ۴۰ کیلووات‌ساعت", "پایش از راه دور و گزارش‌گیری"], popular: 0 },
];

const NEIGHBORHOODS = [
  { id: "nb-1", name: "محله نارمک", city: "تهران", required: 100, estimatedPanels: 120, estimatedKw: 54, status: "COLLECTING" },
  { id: "nb-2", name: "مجتمع باغ ملت", city: "اصفهان", required: 60, estimatedPanels: 80, estimatedKw: 36, status: "COLLECTING" },
  { id: "nb-3", name: "شهرک اکباتان، فاز ۲", city: "تهران", required: 150, estimatedPanels: 210, estimatedKw: 94, status: "NEARLY_COMPLETE" },
  { id: "nb-4", name: "روستای لاویج", city: "مازندران", required: 40, estimatedPanels: 50, estimatedKw: 22, status: "COLLECTING" },
  { id: "nb-5", name: "محله ولنجک", city: "تهران", required: 80, estimatedPanels: 96, estimatedKw: 43, status: "COLLECTING" },
  { id: "nb-6", name: "شهرک صنعتی البرز", city: "البرز", required: 30, estimatedPanels: 45, estimatedKw: 20, status: "JUST_STARTED" },
];

const upsertPkg = db.prepare(`
  INSERT INTO packages (id, name, tier, capacity_kw, panels, battery_kwh, daily_production_kwh, price, usage_desc, home_size, install_availability, warranty, roi, components_json, popular)
  VALUES (@id, @name, @tier, @capacityKw, @panels, @batteryKwh, @dailyProductionKwh, @price, @usage, @homeSize, @installAvailability, @warranty, @roi, @components_json, @popular)
  ON CONFLICT(id) DO UPDATE SET name=excluded.name, price=excluded.price, capacity_kw=excluded.capacity_kw
`);

const upsertNb = db.prepare(`
  INSERT INTO neighborhoods (id, name, city, required, estimated_panels, estimated_kw, status)
  VALUES (@id, @name, @city, @required, @estimatedPanels, @estimatedKw, @status)
  ON CONFLICT(id) DO NOTHING
`);

for (const p of PACKAGES) {
  const { components, ...rest } = p;
  upsertPkg.run({ ...rest, components_json: JSON.stringify(components) });
}
for (const n of NEIGHBORHOODS) {
  upsertNb.run(n);
}

console.log(`Seeded ${PACKAGES.length} packages and ${NEIGHBORHOODS.length} neighborhoods.`);


// Default admin account for local management (password: Admin123!).
// Change immediately in any shared environment.

const adminEmail = "admin@hamtab.local";
const existingAdmin = db.prepare("SELECT id FROM users WHERE email = ?").get(adminEmail);
if (!existingAdmin) {
  const { hash, salt } = hashPassword("Admin123!");
  const id = newId("usr");
  db.prepare(`
    INSERT INTO users (id, name, email, phone, password_hash, password_salt, role)
    VALUES (?, ?, ?, ?, ?, ?, 'ADMIN')
  `).run(id, "مدیر سیستم", adminEmail, null, hash, salt);
  console.log(`Seeded admin user: ${adminEmail} / Admin123!`);
} else {
  db.prepare("UPDATE users SET role = 'ADMIN' WHERE email = ?").run(adminEmail);
  console.log(`Admin role ensured for ${adminEmail}`);
}


// Exhibition demo customer with an active system (password: Demo1234!)
// Used for booth controller / dashboard walkthrough. Not a real customer.
const demoEmail = "demo@hamtab.local";
const existingDemo = db.prepare("SELECT id FROM users WHERE email = ?").get(demoEmail);
let demoUserId = existingDemo && existingDemo.id;
if (!demoUserId) {
  const { hash, salt } = hashPassword("Demo1234!");
  demoUserId = newId("usr");
  db.prepare(`
    INSERT INTO users (id, name, email, phone, password_hash, password_salt, role, address, install_location)
    VALUES (?, ?, ?, ?, ?, ?, 'USER', ?, ?)
  `).run(
    demoUserId,
    "کاربر نمایشگاهی",
    demoEmail,
    "09120000000",
    hash,
    salt,
    "تهران — نمونه نمایشگاهی",
    "تهران"
  );
  console.log(`Seeded demo user: ${demoEmail} / Demo1234!`);
} else {
  console.log(`Demo user already exists: ${demoEmail}`);
}

const existingSys = db.prepare("SELECT id FROM solar_systems WHERE user_id = ? LIMIT 1").get(demoUserId);
if (!existingSys) {
  const sysId = newId("sys");
  const orderId = newId("ord");
  // Minimal order row so FK-friendly if needed later
  try {
    db.prepare(`
      INSERT INTO orders (id, user_id, package_id, package_name, price, status, address, created_at)
      VALUES (?, ?, 'pkg-home', 'هوم', 152000000, 'ACTIVE', 'تهران — نمونه نمایشگاهی', datetime('now'))
    `).run(orderId, demoUserId);
  } catch (e) {
    console.warn("demo order seed skipped:", e.message);
  }
  db.prepare(`
    INSERT INTO solar_systems (
      id, user_id, order_id, package_id, package_name, capacity_kw, status,
      installed_on, total_generated_kwh, total_saved_toman, battery_percent
    ) VALUES (?, ?, ?, 'pkg-home', 'هوم', 5.4, 'ACTIVE', date('now', '-40 days'), 1280, 18500000, 72)
  `).run(sysId, demoUserId, orderId);
  // seed a few telemetry rows so controller is not empty
  const insTel = db.prepare(`
    INSERT INTO telemetry (system_id, solar_production_kw, home_consumption_kw, battery_percent, grid_usage_kw, source, created_at)
    VALUES (?, ?, ?, ?, ?, 'dev-simulator', datetime('now', ?))
  `);
  for (let i = 0; i < 12; i++) {
    insTel.run(sysId, 1.2 + (i % 5) * 0.4, 0.8 + (i % 3) * 0.3, 60 + (i % 7), 0.2, `-${i * 5} minutes`);
  }
  console.log(`Seeded demo solar system ${sysId} for exhibition`);
} else {
  console.log("Demo solar system already present");
}

