import { HttpError } from "./router.js";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function str(body, field, { required = true, min = 1, max = 500 } = {}) {
  const v = body[field];
  if (v === undefined || v === null || v === "") {
    if (required) throw new HttpError(400, `Field '${field}' is required`);
    return undefined;
  }
  if (typeof v !== "string") throw new HttpError(400, `Field '${field}' must be a string`);
  if (v.length < min || v.length > max)
    throw new HttpError(400, `Field '${field}' must be between ${min} and ${max} characters`);
  return v;
}

export function email(body, field = "email") {
  const v = str(body, field, { max: 254 });
  if (!EMAIL_RE.test(v)) throw new HttpError(400, "Invalid email address");
  return v.toLowerCase().trim();
}

export function num(body, field, { required = true, min = -Infinity, max = Infinity } = {}) {
  const raw = body[field];
  if (raw === undefined || raw === null || raw === "") {
    if (required) throw new HttpError(400, `Field '${field}' is required`);
    return undefined;
  }
  const v = Number(raw);
  if (!Number.isFinite(v)) throw new HttpError(400, `Field '${field}' must be a number`);
  if (v < min || v > max) throw new HttpError(400, `Field '${field}' must be between ${min} and ${max}`);
  return v;
}

export function password(body, field = "password") {
  const v = str(body, field, { min: 8, max: 200 });
  return v;
}
