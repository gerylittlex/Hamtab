import { db } from "../db.js";
import { HttpError } from "../router.js";
import { requireAuth } from "../middleware/auth.js";

const listForUser = db.prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100");
const getOne = db.prepare("SELECT * FROM notifications WHERE id = ?");
const markRead = db.prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");

function serialize(n) {
  return { id: n.id, title: n.title, body: n.body, type: n.type, time: n.created_at, isRead: !!n.is_read };
}

export function registerNotificationRoutes(router) {
  router.get("/api/notifications", async (req, res) => {
    const user = requireAuth(req);
    res.json(200, { notifications: listForUser.all(user.id).map(serialize) });
  });

  router.post("/api/notifications/:id/read", async (req, res) => {
    const user = requireAuth(req);
    const n = getOne.get(req.params.id);
    if (!n) throw new HttpError(404, "Notification not found");
    if (n.user_id !== user.id) throw new HttpError(403, "Not authorized");
    markRead.run(n.id);
    res.json(200, { ok: true });
  });
}
