import { db } from "../db.js";
import { requireAuth } from "../middleware/auth.js";
import { str } from "../validate.js";
import { hashPassword, verifyPassword } from "../crypto-utils.js";
import { HttpError } from "../router.js";

const updateProfile = db.prepare(`
  UPDATE users SET name = ?, phone = ?, address = ?, install_location = ?, updated_at = datetime('now') WHERE id = ?
`);
const getFull = db.prepare("SELECT * FROM users WHERE id = ?");
const updatePassword = db.prepare(
  "UPDATE users SET password_hash = ?, password_salt = ?, token_version = token_version + 1, updated_at = datetime('now') WHERE id = ?"
);

export function registerProfileRoutes(router) {
  router.put("/api/profile", async (req, res) => {
    const user = requireAuth(req);
    const name = str(req.body, "name", { min: 2, max: 120 });
    const phone = str(req.body, "phone", { required: false, max: 40 }) || null;
    const address = str(req.body, "address", { required: false, max: 400 }) || null;
    const installLocation = str(req.body, "installLocation", { required: false, max: 120 }) || null;

    updateProfile.run(name, phone, address, installLocation, user.id);
    const updated = getFull.get(user.id);
    res.json(200, {
      user: {
        id: updated.id,
        name: updated.name,
        email: updated.email,
        phone: updated.phone,
        address: updated.address,
        installLocation: updated.install_location,
        role: updated.role,
      },
    });
  });

  router.put("/api/profile/password", async (req, res) => {
    const user = requireAuth(req);
    const currentPassword = str(req.body, "currentPassword", { min: 1 });
    const newPassword = str(req.body, "newPassword", { min: 8, max: 200 });

    const full = getFull.get(user.id);
    if (!verifyPassword(currentPassword, full.password_salt, full.password_hash)) {
      throw new HttpError(401, "Current password is incorrect");
    }
    const { hash, salt } = hashPassword(newPassword);
    updatePassword.run(hash, salt, user.id);
    res.json(200, { ok: true, message: "Password updated. Please log in again on other devices." });
  });
}
