import { getWeatherOutlook } from "../services/weather.js";
import { getUserFromRequest } from "../middleware/auth.js";
import { db } from "../db.js";

const getUser = db.prepare("SELECT id, name, address, install_location FROM users WHERE id = ?");

export function registerWeatherRoutes(router) {
  // Public outlook — used by controller / dashboard banners
  router.get("/api/weather/outlook", async (req, res) => {
    const url = new URL(req.url, "http://localhost");
    let city = url.searchParams.get("city") || "";
    const days = url.searchParams.get("days");

    if (!city) {
      const user = getUserFromRequest(req);
      if (user) {
        const row = getUser.get(user.id);
        city = (row && (row.install_location || row.address)) || "";
        // try extract city-like token
        if (city && city.length > 40) city = city.split(/[،,]/)[0].trim();
      }
    }
    if (!city) city = "تهران";

    const outlook = getWeatherOutlook({ city, days: days ? Number(days) : 3 });
    res.json(200, { outlook });
  });
}
