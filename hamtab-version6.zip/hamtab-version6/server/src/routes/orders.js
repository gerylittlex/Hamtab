import { db } from "../db.js";
import { HttpError } from "../router.js";
import { requireAuth } from "../middleware/auth.js";
import { str } from "../validate.js";
import { newId } from "../crypto-utils.js";
import { getPaymentAdapter } from "../services/payment-adapter.js";
import { issueWarrantyForSystem } from "../services/warranty.js";

const getPackage = db.prepare("SELECT * FROM packages WHERE id = ? AND status = 'ACTIVE'");
const findByIdempotency = db.prepare("SELECT * FROM orders WHERE idempotency_key = ?");
const insertOrder = db.prepare(`
  INSERT INTO orders (id, user_id, package_id, package_name, price, address, idempotency_key)
  VALUES (?, ?, ?, ?, ?, ?, ?)
`);
const listOrdersForUser = db.prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
const getOrder = db.prepare("SELECT * FROM orders WHERE id = ?");
const updateOrderPaid = db.prepare(
  "UPDATE orders SET status = 'CONFIRMED', payment_status = 'PAID', updated_at = datetime('now') WHERE id = ?"
);
const updateOrderFailed = db.prepare(
  "UPDATE orders SET payment_status = 'FAILED', updated_at = datetime('now') WHERE id = ?"
);
const insertPayment = db.prepare(`
  INSERT INTO payments (id, order_id, provider, status, amount, raw_response)
  VALUES (?, ?, ?, ?, ?, ?)
`);
const findSystemByOrder = db.prepare("SELECT * FROM solar_systems WHERE order_id = ?");
const insertSystem = db.prepare(`
  INSERT INTO solar_systems (id, user_id, order_id, package_id, package_name, capacity_kw, status, installed_on, battery_percent)
  VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', date('now'), 60)
`);
const insertNotification = db.prepare(`
  INSERT INTO notifications (id, user_id, title, body, type) VALUES (?, ?, ?, ?, ?)
`);

function serializeOrder(o) {
  return {
    id: o.id,
    packageId: o.package_id,
    packageName: o.package_name,
    price: o.price,
    address: o.address,
    status: o.status,
    payment: o.payment_status,
    date: o.created_at,
  };
}


function provisionSystemForOrder(order) {
  if (!order) return null;
  const existing = findSystemByOrder.get(order.id);
  if (existing) { try { issueWarrantyForSystem(existing.id); } catch (_) {} return existing.id; }
  const systemId = newId("sys");
  insertSystem.run(systemId, order.user_id, order.id, order.package_id, order.package_name, pkgCapacity(order.package_id));
  try { issueWarrantyForSystem(systemId); } catch (_) {}
  return systemId;
}
export function registerOrderRoutes(router) {
  router.get("/api/orders", async (req, res) => {
    const user = requireAuth(req);
    res.json(200, { orders: listOrdersForUser.all(user.id).map(serializeOrder) });
  });

  router.get("/api/orders/:id", async (req, res) => {
    const user = requireAuth(req);
    const order = getOrder.get(req.params.id);
    if (!order) throw new HttpError(404, "Order not found");
    // Anti-IDOR: owner-only, even for a well-formed existing order id.
    if (order.user_id !== user.id && user.role !== "ADMIN") throw new HttpError(403, "Not authorized to view this order");
    res.json(200, { order: serializeOrder(order) });
  });

  router.post("/api/orders", async (req, res) => {
    const user = requireAuth(req);
    const packageId = str(req.body, "packageId");
    const address = str(req.body, "address", { required: false, max: 400 }) || user.address;
    const idempotencyKey = req.headers["idempotency-key"] || null;

    if (idempotencyKey) {
      const existing = findByIdempotency.get(idempotencyKey);
      if (existing) {
        if (existing.user_id !== user.id) throw new HttpError(409, "Idempotency key already used by another request");
        return res.json(200, { order: serializeOrder(existing), idempotent: true });
      }
    }

    const pkg = getPackage.get(packageId);
    if (!pkg) throw new HttpError(404, "Package not found");

    // Backend is authoritative: price comes from the packages table, never
    // from the request body — the client cannot influence the charged amount.
    const id = newId("ord");
    insertOrder.run(id, user.id, pkg.id, pkg.name, pkg.price, address, idempotencyKey);
    const order = getOrder.get(id);
    res.json(201, { order: serializeOrder(order) });
  });

  // Development/test payment flow. See services/payment-adapter.js — this
  // never fabricates a success independent of the adapter's result, and a
  // real provider would verify its callback signature the same way.
  router.post("/api/orders/:id/pay", async (req, res) => {
    const user = requireAuth(req);
    const order = getOrder.get(req.params.id);
    if (!order) throw new HttpError(404, "Order not found");
    if (order.user_id !== user.id) throw new HttpError(403, "Not authorized to pay for this order");
    if (order.payment_status === "PAID") throw new HttpError(409, "Order is already paid");

    const { name: providerName, adapter } = getPaymentAdapter();
    const result = await adapter.charge({ amount: order.price, orderId: order.id });

    if (result.status !== "SUCCEEDED") {
      const paymentId = newId("pay");
      insertPayment.run(paymentId, order.id, providerName, result.status, order.price, JSON.stringify(result));
      updateOrderFailed.run(order.id);
      throw new HttpError(402, "Payment failed", { reason: result.reason || "declined" });
    }

    // Transaction: payment record + mark order paid + provision system atomically.
    // Prevents a SUCCEEDED payment row existing while the order remains unpaid
    // if system provisioning fails mid-way.
    const paymentId = newId("pay");
    const tx = db.prepare("BEGIN");
    tx.run();
    try {
      insertPayment.run(paymentId, order.id, providerName, result.status, order.price, JSON.stringify(result));
      updateOrderPaid.run(order.id);
      const systemId = provisionSystemForOrder({ ...order, user_id: user.id });
      insertNotification.run(
        newId("ntf"),
        user.id,
        "پرداخت با موفقیت انجام شد",
        `سفارش ${order.id} برای «${order.package_name}» تأیید شد.`,
        "success"
      );
      db.prepare("COMMIT").run();
    } catch (err) {
      db.prepare("ROLLBACK").run();
      throw err;
    }

    res.json(200, { order: serializeOrder(getOrder.get(order.id)), payment: result });
  });
}

function pkgCapacity(packageId) {
  const row = db.prepare("SELECT capacity_kw FROM packages WHERE id = ?").get(packageId);
  return row ? row.capacity_kw : 0;
}

export { provisionSystemForOrder };
