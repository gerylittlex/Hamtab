import { db } from "../db.js";
import { hashPassword, verifyPassword, issueToken, newId } from "../crypto-utils.js";
import { HttpError } from "../router.js";
import { str, email, password } from "../validate.js";
import { requireAuth, getUserFromRequest } from "../middleware/auth.js";
import { rateLimit } from "../middleware/rate-limit.js";

const authLimiter = rateLimit({ windowMs: 60_000, max: 10, keyPrefix: "auth:" });

const findByEmail = db.prepare("SELECT * FROM users WHERE email = ?");
const insertUser = db.prepare(`
  INSERT INTO users (id, name, email, phone, password_hash, password_salt, address, install_location)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`);
const getById = db.prepare(
  "SELECT id, name, email, phone, address, install_location, role, created_at FROM users WHERE id = ?"
);
const bumpTokenVersion = db.prepare("UPDATE users SET token_version = token_version + 1 WHERE id = ?");

function publicUser(u) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    phone: u.phone,
    address: u.address,
    installLocation: u.install_location,
    role: u.role,
    isAuthenticated: true,
  };
}

export function registerAuthRoutes(router) {
  router.post("/api/auth/register", async (req, res) => {
    authLimiter(req);
    const name = str(req.body, "name", { min: 2, max: 120 });
    const userEmail = email(req.body);
    const pass = password(req.body);
    const phone = str(req.body, "phone", { required: false, max: 40 }) || null;

    if (findByEmail.get(userEmail)) {
      throw new HttpError(409, "An account with this email already exists");
    }

    const { hash, salt } = hashPassword(pass);
    const id = newId("usr");
    insertUser.run(id, name, userEmail, phone, hash, salt, null, null);
    const user = getById.get(id);
    const token = issueToken(id, 0);
    res.json(201, { token, user: publicUser(user) });
  });

  router.post("/api/auth/login", async (req, res) => {
    authLimiter(req);
    const userEmail = email(req.body);
    const pass = str(req.body, "password", { min: 1, max: 200 });

    const row = findByEmail.get(userEmail);
    // Deliberately identical error for "no such user" and "wrong password"
    // so the endpoint doesn't leak which emails are registered.
    if (!row || !verifyPassword(pass, row.password_salt, row.password_hash)) {
      throw new HttpError(401, "Invalid email or password");
    }
    const token = issueToken(row.id, row.token_version);
    res.json(200, { token, user: publicUser(row) });
  });

  router.post("/api/auth/logout-everywhere", async (req, res) => {
    const user = requireAuth(req);
    bumpTokenVersion.run(user.id);
    res.json(200, { ok: true });
  });

  router.get("/api/auth/me", async (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.json(200, { user: null });
    res.json(200, { user: publicUser(user) });
  });
}
