import { db } from "../db.js";
import { calculateSolarSystem, simulate12MonthBill } from "../services/calculator.js";
import { getUserFromRequest } from "../middleware/auth.js";
import { newId } from "../crypto-utils.js";

const insertCalc = db.prepare(`
  INSERT INTO solar_calculations (id, user_id, input_json, result_json, suggested_package_id)
  VALUES (?, ?, ?, ?, ?)
`);

export function registerSolarRoutes(router) {
  router.post("/api/solar/calculate", async (req, res) => {
    const result = calculateSolarSystem(req.body);
    const user = getUserFromRequest(req);
    insertCalc.run(
      newId("calc"),
      user ? user.id : null,
      JSON.stringify(req.body),
      JSON.stringify(result),
      result.suggestedPackageId
    );
    res.json(200, { result });
  });

  router.post("/api/solar/simulate-bill", async (req, res) => {
    const simulation = simulate12MonthBill(req.body || {});
    const user = getUserFromRequest(req);
    insertCalc.run(
      newId("sim"),
      user ? user.id : null,
      JSON.stringify(req.body || {}),
      JSON.stringify({ type: "12month-bill", ...simulation }),
      simulation.sizing?.suggestedPackageId || null
    );
    res.json(200, { simulation });
  });
}
