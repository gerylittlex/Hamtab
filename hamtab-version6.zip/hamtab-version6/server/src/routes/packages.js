import { db } from "../db.js";
import { HttpError } from "../router.js";

const listStmt = db.prepare(
  "SELECT * FROM packages WHERE IFNULL(status, 'ACTIVE') = 'ACTIVE' ORDER BY price ASC"
);
const getStmt = db.prepare("SELECT * FROM packages WHERE id = ?");

function serialize(row) {
  let components = [];
  try {
    components = JSON.parse(row.components_json || "[]");
    if (!Array.isArray(components)) components = [];
  } catch {
    components = [];
  }
  return {
    id: row.id,
    name: row.name,
    tier: row.tier,
    capacityKw: row.capacity_kw,
    panels: row.panels,
    batteryKwh: row.battery_kwh,
    dailyProductionKwh: row.daily_production_kwh,
    price: row.price,
    usage: row.usage_desc,
    homeSize: row.home_size,
    installAvailability: row.install_availability,
    warranty: row.warranty,
    roi: row.roi,
    components,
    popular: !!row.popular,
    status: row.status || "ACTIVE",
  };
}

export function registerPackageRoutes(router) {
  router.get("/api/packages", async (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    const packages = listStmt.all().map(serialize);
    res.json(200, { packages, count: packages.length });
  });

  router.get("/api/packages/:id", async (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    const row = getStmt.get(req.params.id);
    if (!row) throw new HttpError(404, "Package not found");
    if ((row.status || "ACTIVE") !== "ACTIVE") throw new HttpError(404, "Package not found");
    res.json(200, { package: serialize(row) });
  });
}

export { serialize as serializePackage, getStmt as getPackageStmt };
