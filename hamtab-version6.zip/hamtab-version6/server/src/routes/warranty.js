import { db } from "../db.js";
import { newId } from "../crypto-utils.js";

const getSystem = db.prepare("SELECT * FROM solar_systems WHERE id = ?");
const getPackage = db.prepare("SELECT * FROM packages WHERE id = ?");
const getUser = db.prepare("SELECT id, name, email, phone FROM users WHERE id = ?");
const updateWarranty = db.prepare(`
  UPDATE solar_systems SET
    warranty_code = ?,
    serial_number = ?,
    warranty_years = ?,
    warranty_starts_on = ?,
    warranty_ends_on = ?,
    warranty_coverage_json = ?
  WHERE id = ?
`);

const DEFAULT_COVERAGE = {
  panels: "۱۰ سال",
  inverter: "۵ سال",
  battery: "۵ سال",
  workmanship: "۲ سال",
  monitoring: "۱ سال",
};

function addYears(isoDate, years) {
  const d = new Date(isoDate + "T12:00:00Z");
  d.setUTCFullYear(d.getUTCFullYear() + years);
  return d.toISOString().slice(0, 10);
}

function shortCode() {
  const id = newId("w").replace(/[^a-z0-9]/gi, "").toUpperCase();
  const a = id.slice(0, 4).padEnd(4, "X");
  const b = id.slice(4, 8).padEnd(4, "0");
  return `HT-${a}-${b}`;
}

function serialFromSystem(systemId) {
  const clean = String(systemId).replace(/[^a-z0-9]/gi, "").toUpperCase().slice(-8);
  return `SN-${clean || "00000000"}`;
}

export function ensureWarranty(systemRow) {
  if (!systemRow) return null;
  let row = systemRow;
  if (!row.warranty_code) {
    const years = 10;
    const starts = row.installed_on || new Date().toISOString().slice(0, 10);
    const ends = addYears(starts, years);
    const code = shortCode();
    const serial = serialFromSystem(row.id);
    const coverage = JSON.stringify(DEFAULT_COVERAGE);
    updateWarranty.run(code, serial, years, starts, ends, coverage, row.id);
    row = getSystem.get(row.id);
  }
  return buildWarrantyPayload(row);
}

export function buildWarrantyPayload(row) {
  if (!row) return null;
  let coverage = DEFAULT_COVERAGE;
  try {
    coverage = JSON.parse(row.warranty_coverage_json || "{}") || DEFAULT_COVERAGE;
  } catch {
    coverage = DEFAULT_COVERAGE;
  }
  const ends = row.warranty_ends_on;
  let status = "ACTIVE";
  if (ends) {
    const today = new Date().toISOString().slice(0, 10);
    if (today > ends) status = "EXPIRED";
  }
  const pkg = getPackage.get(row.package_id);
  const user = getUser.get(row.user_id);
  return {
    systemId: row.id,
    warrantyCode: row.warranty_code,
    serialNumber: row.serial_number,
    years: row.warranty_years || 10,
    startsOn: row.warranty_starts_on,
    endsOn: row.warranty_ends_on,
    status,
    coverage,
    packageName: row.package_name,
    capacityKw: row.capacity_kw,
    installedOn: row.installed_on,
    ownerName: user ? user.name : null,
    packageWarrantyNote: pkg && pkg.warranty ? pkg.warranty : null,
    disclaimer:
      "این کارت گارانتی دیجیتال بر اساس شرایط نصب و پکیج صادر شده است. جزئیات دقیق پوشش ممکن است در قرارداد کتبی متفاوت باشد.",
  };
}

export function issueWarrantyForSystem(systemId) {
  const row = getSystem.get(systemId);
  return ensureWarranty(row);
}
