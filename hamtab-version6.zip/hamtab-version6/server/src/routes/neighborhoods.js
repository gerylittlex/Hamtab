import { db } from "../db.js";
import { HttpError } from "../router.js";
import { requireAuth, getUserFromRequest } from "../middleware/auth.js";
import { str, num } from "../validate.js";
import { newId } from "../crypto-utils.js";

const listStmt = db.prepare(`
  SELECT n.*, (SELECT COUNT(*) FROM neighborhood_participants p WHERE p.neighborhood_id = n.id) AS participants
  FROM neighborhoods n ORDER BY n.created_at DESC
`);
const getStmt = db.prepare("SELECT * FROM neighborhoods WHERE id = ?");
const insertNeighborhood = db.prepare(`
  INSERT INTO neighborhoods (id, name, city, required, estimated_panels, estimated_kw, status)
  VALUES (?, ?, ?, ?, ?, ?, 'COLLECTING')
`);
const insertParticipant = db.prepare(
  "INSERT INTO neighborhood_participants (id, neighborhood_id, user_id) VALUES (?, ?, ?)"
);
const hasJoined = db.prepare(
  "SELECT 1 FROM neighborhood_participants WHERE neighborhood_id = ? AND user_id = ?"
);
const countParticipants = db.prepare(
  "SELECT COUNT(*) AS c FROM neighborhood_participants WHERE neighborhood_id = ?"
);
const insertActivity = db.prepare(
  "INSERT INTO neighborhood_activity (neighborhood_id, text) VALUES (?, ?)"
);
const recentActivity = db.prepare(`
  SELECT a.*, n.name AS neighborhood_name FROM neighborhood_activity a
  JOIN neighborhoods n ON n.id = a.neighborhood_id ORDER BY a.created_at DESC LIMIT 20
`);

function serialize(n) {
  return {
    id: n.id,
    name: n.name,
    city: n.city,
    participants: n.participants,
    required: n.required,
    estimatedPanels: n.estimated_panels,
    estimatedKw: n.estimated_kw,
    status: n.status,
  };
}

export function registerNeighborhoodRoutes(router) {
  router.get("/api/neighborhoods", async (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    const user = getUserFromRequest(req);
    const rows = listStmt.all().map(serialize);
    if (user) {
      for (const r of rows) r.joined = !!hasJoined.get(r.id, user.id);
    }
    res.json(200, { neighborhoods: rows });
  });

  router.get("/api/neighborhoods/activity", async (req, res) => {
    res.json(200, {
      activity: recentActivity.all().map((a) => ({ id: a.id, text: `${a.text}`, time: a.created_at, neighborhood: a.neighborhood_name })),
    });
  });

  router.post("/api/neighborhoods", async (req, res) => {
    const user = requireAuth(req);
    const name = str(req.body, "name", { min: 2, max: 150 });
    const city = str(req.body, "location", { required: false, max: 100 }) || "";
    const homes = num(req.body, "homes", { required: false, min: 0, max: 100000 }) || 20;
    const interestedHomes = num(req.body, "interestedHomes", { required: false, min: 1, max: 100000 }) || 30;

    const id = newId("nb");
    insertNeighborhood.run(id, name, city, Math.round(interestedHomes), Math.round(homes * 1.6), +(homes * 0.72).toFixed(1));
    insertParticipant.run(newId("nbp"), id, user.id);
    insertActivity.run(id, `«${name}» به‌تازگی ثبت شد.`);
    res.json(201, { neighborhood: serialize({ ...getStmt.get(id), participants: 1 }) });
  });

  router.post("/api/neighborhoods/:id/join", async (req, res) => {
    const user = requireAuth(req);
    const nb = getStmt.get(req.params.id);
    if (!nb) throw new HttpError(404, "Neighborhood not found");

    if (hasJoined.get(nb.id, user.id)) {
      throw new HttpError(409, "You have already joined this neighborhood");
    }
    const current = countParticipants.get(nb.id).c;
    if (current >= nb.required) throw new HttpError(409, "This neighborhood has already reached its goal");

    // The UNIQUE(neighborhood_id, user_id) constraint is the real guard
    // against duplicate participation even under concurrent requests; the
    // hasJoined check above is just a friendlier error message path.
    try {
      insertParticipant.run(newId("nbp"), nb.id, user.id);
    } catch (err) {
      if (String(err.message).includes("UNIQUE")) throw new HttpError(409, "You have already joined this neighborhood");
      throw err;
    }
    const newCount = countParticipants.get(nb.id).c;
    if (newCount >= nb.required) {
      db.prepare("UPDATE neighborhoods SET status = 'NEARLY_COMPLETE' WHERE id = ?").run(nb.id);
    }
    insertActivity.run(nb.id, `یک عضو جدید به «${nb.name}» پیوست.`);
    res.json(200, { neighborhood: serialize({ ...getStmt.get(nb.id), participants: newCount }) });
  });

  /**
   * Privacy-safe production comparison:
   * - Never exposes another household's data
   * - Requires a minimum sample; otherwise returns estimated regional baseline
   */
  router.get("/api/neighborhoods/comparison", async (req, res) => {
    const user = requireAuth(req);
    const full = db.prepare(
      "SELECT id, install_location, address FROM users WHERE id = ?"
    ).get(user.id);

    const mine = db.prepare(`
      SELECT
        COALESCE(SUM(total_generated_kwh), 0) AS totalKwh,
        COALESCE(SUM(capacity_kw), 0) AS capacityKw,
        COUNT(*) AS systems
      FROM solar_systems
      WHERE user_id = ? AND status IN ('ACTIVE','INSTALLED','OFFLINE')
    `).get(user.id);

    const myKwh = mine?.totalKwh || 0;
    const myCapacity = mine?.capacityKw || 0;
    const myPerKw = myCapacity > 0 ? myKwh / myCapacity : null;

    // Prefer same-city aggregate when install_location is set
    const cityHint = (full?.install_location || full?.address || "").trim();
    let scope = "network";
    let sampleSize = 0;
    let avgKwh = null;
    let avgPerKw = null;

    if (cityHint) {
      const cityRows = db.prepare(`
        SELECT
          AVG(s.total_generated_kwh) AS avgKwh,
          AVG(CASE WHEN s.capacity_kw > 0 THEN s.total_generated_kwh / s.capacity_kw END) AS avgPerKw,
          COUNT(*) AS n
        FROM solar_systems s
        JOIN users u ON u.id = s.user_id
        WHERE s.status IN ('ACTIVE','INSTALLED')
          AND s.user_id != ?
          AND (
            u.install_location LIKE ? OR u.address LIKE ?
          )
      `).get(user.id, `%${cityHint}%`, `%${cityHint}%`);
      if (cityRows && cityRows.n >= 3) {
        scope = "city";
        sampleSize = cityRows.n;
        avgKwh = cityRows.avgKwh;
        avgPerKw = cityRows.avgPerKw;
      }
    }

    if (avgKwh == null) {
      const net = db.prepare(`
        SELECT
          AVG(total_generated_kwh) AS avgKwh,
          AVG(CASE WHEN capacity_kw > 0 THEN total_generated_kwh / capacity_kw END) AS avgPerKw,
          COUNT(*) AS n
        FROM solar_systems
        WHERE status IN ('ACTIVE','INSTALLED') AND user_id != ?
      `).get(user.id);
      if (net && net.n >= 3) {
        scope = "network";
        sampleSize = net.n;
        avgKwh = net.avgKwh;
        avgPerKw = net.avgPerKw;
      }
    }

    // Fallback estimated baseline (clearly labeled — not live neighbor data)
    let dataQuality = "live";
    if (avgKwh == null) {
      dataQuality = "estimated";
      scope = "estimated";
      sampleSize = 0;
      // Rough residential baseline for demo when network is empty
      avgPerKw = 220; // kWh lifetime-ish per kW — illustrative only
      avgKwh = myCapacity > 0 ? avgPerKw * myCapacity : 1100;
    }

    const deltaPct =
      avgKwh && avgKwh > 0 && myKwh > 0
        ? Math.round(((myKwh - avgKwh) / avgKwh) * 100)
        : null;

    res.json(200, {
      comparison: {
        dataQuality, // live | estimated
        scope, // city | network | estimated
        sampleSize,
        cityHint: cityHint || null,
        you: {
          totalKwh: Math.round(myKwh * 10) / 10,
          capacityKw: myCapacity,
          kwhPerKw: myPerKw != null ? Math.round(myPerKw * 10) / 10 : null,
          systems: mine?.systems || 0,
        },
        peer: {
          avgTotalKwh: Math.round((avgKwh || 0) * 10) / 10,
          avgKwhPerKw: avgPerKw != null ? Math.round(avgPerKw * 10) / 10 : null,
        },
        deltaPercent: deltaPct,
        privacyNote:
          "هیچ دادهٔ فردی همسایه نمایش داده نمی‌شود. فقط میانگین ناشناس با حداقل نمونه آماری استفاده می‌شود.",
        estimatedNote:
          dataQuality === "estimated"
            ? "هنوز نمونه آماری کافی در شبکه نیست؛ عدد هم‌ترازی تخمینی و برای نمایش است، نه مقایسه زنده."
            : null,
      },
    });
  });
}
