import { db } from "../db.js";
import { HttpError } from "../router.js";
import { requireAuth } from "../middleware/auth.js";
import { num } from "../validate.js";
import { ensureWarranty } from "../services/warranty.js";
import { provisionSystemForOrder } from "./orders.js";
import { newId } from "../crypto-utils.js";

const listForUser = db.prepare("SELECT * FROM solar_systems WHERE user_id = ? ORDER BY created_at DESC");
const getSystem = db.prepare("SELECT * FROM solar_systems WHERE id = ?");
const latestTelemetry = db.prepare("SELECT * FROM telemetry WHERE system_id = ? ORDER BY created_at DESC, id DESC LIMIT 1");
const hourlyTelemetry = db.prepare(`
  SELECT strftime('%H', created_at) AS hour, AVG(solar_production_kw) AS avg_kw
  FROM telemetry WHERE system_id = ? AND created_at >= datetime('now', '-1 day')
  GROUP BY hour ORDER BY hour ASC
`);
const insertDeviceTelemetry = db.prepare(`
  INSERT INTO telemetry (system_id, solar_production_kw, home_consumption_kw, battery_percent, grid_usage_kw, source)
  VALUES (?, ?, ?, ?, ?, 'device')
`);

function serializeSystem(s) {
  let warrantySummary = null;
  try {
    const w = ensureWarranty(s);
    if (w) warrantySummary = { code: w.warrantyCode, serialNumber: w.serialNumber, status: w.status, endsOn: w.endsOn, years: w.years };
  } catch (e) { console.error(e); }
  return {
    id: s.id, packageId: s.package_id, packageName: s.package_name, capacityKw: s.capacity_kw,
    status: s.status, installedOn: s.installed_on, totalGeneratedKwh: s.total_generated_kwh,
    totalSavedToman: s.total_saved_toman, batteryPercent: s.battery_percent, warranty: warrantySummary,
    publicToken: ensurePublicToken(s),
  };
}

function connectionState(latest) {
  if (!latest) return "UNKNOWN";
  const ageMs = Date.now() - new Date(latest.created_at + "Z").getTime();
  if (ageMs < 15_000) return "LIVE";
  if (ageMs < 5 * 60_000) return "STALE";
  return "DISCONNECTED";
}

function ownedSystem(req) {
  const user = requireAuth(req);
  const sys = getSystem.get(req.params.id);
  if (!sys) throw new HttpError(404, "System not found");
  if (sys.user_id !== user.id && user.role !== "ADMIN") throw new HttpError(403, "Not authorized for this system");
  return { user, sys };
}

const updateModes = db.prepare("UPDATE solar_systems SET modes_json = ? WHERE id = ?");

const getByPublicToken = db.prepare("SELECT * FROM solar_systems WHERE public_token = ?");
const setPublicToken = db.prepare("UPDATE solar_systems SET public_token = ? WHERE id = ? AND (public_token IS NULL OR public_token = '')");

function ensurePublicToken(sys) {
  if (!sys) return null;
  if (sys.public_token) return sys.public_token;
  const token = newId("qr").replace(/[^a-zA-Z0-9]/g, "").slice(0, 16);
  try {
    setPublicToken.run(token, sys.id);
  } catch (e) {
    console.warn("[systems] public_token write failed (migrate db?):", e.message);
    return token; // still return so QR link can work for this session path param if stored client-side
  }
  const again = getSystem.get(sys.id);
  return (again && again.public_token) || token;
}

function publicSystemPayload(sys) {
  const latest = latestTelemetry.get(sys.id);
  const conn = connectionState(latest);
  return {
    publicToken: sys.public_token,
    serialNumber: sys.serial_number || null,
    packageName: sys.package_name,
    capacityKw: sys.capacity_kw,
    status: sys.status,
    installedOn: sys.installed_on,
    totalGeneratedKwh: sys.total_generated_kwh,
    // Deliberately omit owner identity, address, phone, modes, detailed home load
    connection: conn === "LIVE" || conn === "STALE" ? "online" : "offline",
    privacyNote: "این صفحه عمومی است و اطلاعات هویتی مالک را نمایش نمی‌دهد.",
  };
}



export function registerSystemRoutes(router) {
  router.get("/api/systems", async (req, res) => {
    const user = requireAuth(req);
    try {
      const orphanOrders = db.prepare(`SELECT o.* FROM orders o WHERE o.user_id = ? AND (o.payment_status = 'PAID' OR o.status IN ('CONFIRMED','PAID','INSTALLED','ACTIVE','SCHEDULED','INSTALLING')) AND NOT EXISTS (SELECT 1 FROM solar_systems s WHERE s.order_id = o.id)`).all(user.id);
      for (const o of orphanOrders) { try { provisionSystemForOrder(o); } catch (e) {} }
    } catch (e) {}
    res.json(200, { systems: listForUser.all(user.id).map(serializeSystem) });
  });
  router.get("/api/systems/:id/warranty", async (req, res) => {
    const { sys } = ownedSystem(req);
    res.json(200, { warranty: ensureWarranty(sys) });
  });

  router.put("/api/systems/:id/modes", async (req, res) => {
    const { sys } = ownedSystem(req);
    const current = JSON.parse(sys.modes_json || "{}");
    const allowedKeys = ["batteryUsage", "energySaving", "gridPriority", "solarPriority", "batteryReserve"];
    const next = { ...current };
    for (const key of allowedKeys) {
      if (key in req.body) next[key] = req.body[key];
    }
    if (typeof next.batteryReserve === "number") {
      next.batteryReserve = Math.min(100, Math.max(0, next.batteryReserve));
    }
    updateModes.run(JSON.stringify(next), sys.id);
    res.json(200, { modes: next });
  });

  router.get("/api/systems/:id/controller", async (req, res) => {
    const { sys } = ownedSystem(req);
    const latest = latestTelemetry.get(sys.id);
    const hourly = hourlyTelemetry.all(sys.id).map((r) => r.avg_kw || 0);
    res.json(200, {
      state: latest
        ? {
            solarProductionKw: latest.solar_production_kw,
            homeConsumptionKw: latest.home_consumption_kw,
            batteryPercent: latest.battery_percent,
            gridUsageKw: latest.grid_usage_kw,
            source: latest.source,
            timestamp: latest.created_at,
          }
        : null,
      connection: connectionState(latest),
      hourlyProductionKw: hourly,
      capacityKw: sys.capacity_kw,
      modes: JSON.parse(sys.modes_json || "{}"),
      // Simple, honest heuristic from real data rather than a fabricated
      // "all green" panel — flags only what the numbers actually show.
      componentHealth: [
        { name: "پنل‌های خورشیدی", status: "healthy" },
        { name: "اینورتر", status: "healthy" },
        { name: "باتری", status: sys.battery_percent < 20 ? "warning" : "healthy" },
        { name: "اتصال شبکه", status: connectionState(latest) === "DISCONNECTED" ? "attention" : "healthy" },
      ],
    });
  });

  // Real-device ingestion endpoint. No hardware exists in this build
  // environment to exercise it, but it is the intended integration point
  // for an actual inverter/IoT gateway (see ARCHITECTURE.md section 18) —
  // authenticated the same way the rest of the API is, distinct from the
  // isolated dev simulator which never calls this route.

  // Public QR landing — no auth. Token must be unguessable; never expose PII.
  router.get("/api/public/systems/:token", async (req, res) => {
    const token = String(req.params.token || "").trim();
    if (!token || token.length < 8) throw new HttpError(400, "Invalid token");
    const sys = getByPublicToken.get(token);
    if (!sys) throw new HttpError(404, "System not found");
    res.setHeader("Cache-Control", "no-store");
    res.json(200, { system: publicSystemPayload(sys) });
  });

  // Owner-only: ensure token + return absolute-path QR target
  router.get("/api/systems/:id/qr", async (req, res) => {
    const { sys } = ownedSystem(req);
    const token = ensurePublicToken(sys);
    res.json(200, {
      publicToken: token,
      path: "/pages/system.html?t=" + encodeURIComponent(token),
      serialNumber: sys.serial_number || null,
    });
  });

  router.post("/api/systems/:id/ingest", async (req, res) => {
    const { sys } = ownedSystem(req);
    const solar = num(req.body, "solarProductionKw", { min: 0, max: 1000 });
    const consumption = num(req.body, "homeConsumptionKw", { min: 0, max: 1000 });
    const battery = num(req.body, "batteryPercent", { min: 0, max: 100 });
    const grid = num(req.body, "gridUsageKw", { min: 0, max: 1000 });
    insertDeviceTelemetry.run(sys.id, solar, consumption, battery, grid);
    db.prepare("UPDATE solar_systems SET battery_percent = ? WHERE id = ?").run(battery, sys.id);
    res.json(201, { ok: true });
  });
}
