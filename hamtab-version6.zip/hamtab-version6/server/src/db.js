// ==========================================================================
// HamTab — Database layer
// Uses Node's built-in `node:sqlite` (experimental, ships with Node 22+).
// No ORM, no external dependency: every query below is a parameterized
// prepared statement, which is what actually prevents SQL injection
// (never string-concatenated SQL anywhere in this codebase).
// ==========================================================================
import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import { fileURLToPath } from "node:url";
import fs from "node:fs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "..", "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH =
  process.env.NODE_ENV === "test"
    ? ":memory:"
    : (process.env.DB_PATH || path.join(DATA_DIR, process.env.DB_FILE || "hamtab.db"));

export const db = new DatabaseSync(DB_PATH);

// Pragmas: enforce FK constraints (off by default in sqlite) + reasonable durability.
db.exec("PRAGMA foreign_keys = ON;");
db.exec("PRAGMA journal_mode = WAL;");

export function migrate() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    phone           TEXT,
    password_hash   TEXT NOT NULL,
    password_salt   TEXT NOT NULL,
    address         TEXT,
    install_location TEXT,
    role            TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','ADMIN')),
    token_version   INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS packages (
    id                    TEXT PRIMARY KEY,
    name                  TEXT NOT NULL,
    tier                  TEXT NOT NULL,
    capacity_kw           REAL NOT NULL,
    panels                INTEGER NOT NULL,
    battery_kwh           REAL NOT NULL DEFAULT 0,
    daily_production_kwh  REAL NOT NULL,
    price                 INTEGER NOT NULL CHECK(price >= 0),
    usage_desc            TEXT,
    home_size             TEXT,
    install_availability  TEXT,
    warranty              TEXT,
    roi                   TEXT,
    components_json       TEXT NOT NULL DEFAULT '[]',
    popular               INTEGER NOT NULL DEFAULT 0,
    status                TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','DISCONTINUED')),
    created_at            TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS solar_calculations (
    id                    TEXT PRIMARY KEY,
    user_id               TEXT REFERENCES users(id) ON DELETE SET NULL,
    input_json            TEXT NOT NULL,
    result_json           TEXT NOT NULL,
    suggested_package_id  TEXT,
    created_at            TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id                TEXT PRIMARY KEY,
    user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    package_id        TEXT NOT NULL REFERENCES packages(id),
    package_name      TEXT NOT NULL,
    price             INTEGER NOT NULL CHECK(price >= 0),
    address           TEXT,
    status            TEXT NOT NULL DEFAULT 'PENDING'
                        CHECK(status IN ('PENDING','PAID','CONFIRMED','SCHEDULED','INSTALLING','INSTALLED','ACTIVE','CANCELLED')),
    payment_status    TEXT NOT NULL DEFAULT 'UNPAID' CHECK(payment_status IN ('UNPAID','PAID','FAILED','REFUNDED')),
    idempotency_key   TEXT UNIQUE,
    created_at        TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS payments (
    id            TEXT PRIMARY KEY,
    order_id      TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    provider      TEXT NOT NULL,
    status        TEXT NOT NULL CHECK(status IN ('PENDING','SUCCEEDED','FAILED')),
    amount        INTEGER NOT NULL,
    raw_response  TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS solar_systems (
    id                    TEXT PRIMARY KEY,
    user_id               TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    order_id              TEXT REFERENCES orders(id),
    package_id            TEXT NOT NULL REFERENCES packages(id),
    package_name          TEXT NOT NULL,
    capacity_kw           REAL NOT NULL,
    status                TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('PENDING_INSTALL','ACTIVE','OFFLINE')),
    installed_on          TEXT,
    total_generated_kwh   REAL NOT NULL DEFAULT 0,
    total_saved_toman     INTEGER NOT NULL DEFAULT 0,
    battery_percent       REAL NOT NULL DEFAULT 50,
    modes_json            TEXT NOT NULL DEFAULT '{"batteryUsage":"auto","energySaving":false,"gridPriority":false,"solarPriority":true,"batteryReserve":20}',
    created_at            TEXT NOT NULL DEFAULT (datetime('now'))
  );

  -- Time-series-ish telemetry log. source is either 'dev-simulator' (isolated
  -- development adapter, see services/telemetry-simulator.js) or 'device'
  -- (a real controller posting to POST /api/controller/:systemId/ingest).
  CREATE TABLE IF NOT EXISTS telemetry (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    system_id            TEXT NOT NULL REFERENCES solar_systems(id) ON DELETE CASCADE,
    solar_production_kw  REAL NOT NULL,
    home_consumption_kw  REAL NOT NULL,
    battery_percent      REAL NOT NULL,
    grid_usage_kw        REAL NOT NULL,
    source               TEXT NOT NULL DEFAULT 'dev-simulator',
    created_at           TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_telemetry_system_time ON telemetry(system_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS notifications (
    id          TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    body        TEXT,
    type        TEXT NOT NULL DEFAULT 'info' CHECK(type IN ('info','success','warning','error')),
    is_read     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS neighborhoods (
    id                TEXT PRIMARY KEY,
    name              TEXT NOT NULL,
    city              TEXT,
    required          INTEGER NOT NULL,
    estimated_panels  INTEGER,
    estimated_kw      REAL,
    status            TEXT NOT NULL DEFAULT 'COLLECTING',
    created_at        TEXT NOT NULL DEFAULT (datetime('now'))
  );

  -- The join table IS the participant count; we COUNT(*) it rather than
  -- trusting a mutable counter, and the UNIQUE constraint is what actually
  -- prevents a user from joining (and inflating) the same neighborhood twice.
  CREATE TABLE IF NOT EXISTS neighborhood_participants (
    id              TEXT PRIMARY KEY,
    neighborhood_id TEXT NOT NULL REFERENCES neighborhoods(id) ON DELETE CASCADE,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    joined_at       TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(neighborhood_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS neighborhood_activity (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    neighborhood_id TEXT REFERENCES neighborhoods(id) ON DELETE CASCADE,
    text            TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id              TEXT PRIMARY KEY,
    user_id         TEXT REFERENCES users(id) ON DELETE SET NULL,
    name            TEXT NOT NULL,
    phone           TEXT NOT NULL,
    email           TEXT,
    city            TEXT,
    address         TEXT,
    preferred_date  TEXT NOT NULL,
    preferred_slot  TEXT NOT NULL,
    notes           TEXT,
    status          TEXT NOT NULL DEFAULT 'PENDING'
                      CHECK(status IN ('PENDING','CONFIRMED','CANCELLED','COMPLETED','NO_SHOW')),
    source          TEXT NOT NULL DEFAULT 'web',
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_bookings_date_slot ON bookings(preferred_date, preferred_slot);
  CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id);
  CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);

  CREATE TABLE IF NOT EXISTS energy_score_events (
    id          TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    points      INTEGER NOT NULL,
    reason      TEXT NOT NULL,
    meta_json   TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_energy_score_user ON energy_score_events(user_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS referrals (
    id              TEXT PRIMARY KEY,
    referrer_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referee_id      TEXT REFERENCES users(id) ON DELETE SET NULL,
    code            TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'PENDING'
                      CHECK(status IN ('PENDING','QUALIFIED','REWARDED','REJECTED')),
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(referee_id)
  );
  CREATE INDEX IF NOT EXISTS idx_referrals_code ON referrals(code);
  `);
}

migrate();

// Lightweight additive migration for columns added after initial release —
// CREATE TABLE IF NOT EXISTS won't retrofit an existing table, so guard each
// column add. In a larger project this would be a numbered migration file
// per change instead (documented as a known simplification in DATABASE.md).
function ensureColumn(table, column, ddl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  }
}
ensureColumn(
  "solar_systems",
  "modes_json",
  `modes_json TEXT NOT NULL DEFAULT '{"batteryUsage":"auto","energySaving":false,"gridPriority":false,"solarPriority":true,"batteryReserve":20}'`
);

ensureColumn("solar_systems", "warranty_code", "warranty_code TEXT");
ensureColumn("solar_systems", "serial_number", "serial_number TEXT");
ensureColumn("solar_systems", "warranty_years", "warranty_years INTEGER NOT NULL DEFAULT 10");
ensureColumn("solar_systems", "warranty_starts_on", "warranty_starts_on TEXT");
ensureColumn("solar_systems", "warranty_ends_on", "warranty_ends_on TEXT");
ensureColumn("solar_systems", "warranty_coverage_json", `warranty_coverage_json TEXT NOT NULL DEFAULT '{"panels":"10 سال","inverter":"5 سال","battery":"5 سال","workmanship":"2 سال","monitoring":"1 سال"}'`);

ensureColumn("users", "referral_code", "referral_code TEXT");

try {
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code) WHERE referral_code IS NOT NULL");
} catch (_) { /* ignore */ }

ensureColumn("solar_systems", "public_token", "public_token TEXT");
try {
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_systems_public_token ON solar_systems(public_token) WHERE public_token IS NOT NULL");
} catch (_) {}
