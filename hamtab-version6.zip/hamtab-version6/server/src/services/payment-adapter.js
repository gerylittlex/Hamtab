// ==========================================================================
// HamTab — Payment provider abstraction
// ==========================================================================
// No real payment provider was specified for this project and no gateway
// credentials/API access are available in this build environment. Per the
// project's own rules (never fake a successful production payment), this
// module:
//   1. Defines a stable interface any real gateway (Zarinpal, IDPay,
//      Stripe, etc.) would implement.
//   2. Ships a ProductionAdapter that FAILS LOUDLY if selected without
//      credentials — it will never silently pretend to succeed.
//   3. Ships a DevelopmentSimulator, clearly named and only ever selected
//      when PAYMENT_PROVIDER=dev-simulator (the default outside of a real
//      deployment), which behaves like a gateway's sandbox mode.
// A webhook-verification hook is included so that when a real provider is
// wired in, the callback is verified server-side rather than trusted from
// the browser (see SECURITY.md).
// ==========================================================================

class ProductionAdapter {
  async charge() {
    throw new Error(
      "No real payment provider is configured. Set PAYMENT_PROVIDER and the " +
        "corresponding provider credentials before accepting real payments. " +
        "Refusing to fabricate a payment result."
    );
  }
  verifyWebhookSignature() {
    throw new Error("No real payment provider is configured.");
  }
}

class DevelopmentSimulator {
  // Simulates a redirect-based gateway's synchronous sandbox mode: any
  // order amount ending in specific test digits can be forced to fail, so
  // the failure path is exercisable, just like a real sandbox.
  async charge({ amount, orderId }) {
    if (amount <= 0) return { status: "FAILED", reason: "Invalid amount" };
    const forceFail = amount % 1000 === 13; // deterministic test-failure hook
    if (forceFail) return { status: "FAILED", reason: "Simulated decline (test amount)" };
    return {
      status: "SUCCEEDED",
      reference: `DEV-${orderId}-${Date.now()}`,
      raw: { simulator: true, amount, orderId },
    };
  }
  verifyWebhookSignature() {
    // The dev simulator's "callback" is the direct return value of charge();
    // there is no async webhook to verify.
    return true;
  }
}

export function getPaymentAdapter() {
  const provider = process.env.PAYMENT_PROVIDER || "dev-simulator";
  if (provider === "dev-simulator") return { name: "dev-simulator", adapter: new DevelopmentSimulator() };
  return { name: provider, adapter: new ProductionAdapter() };
}
