// ==========================================================================
// HamTab — Solar sizing calculator
// ==========================================================================
// This is a rough, transparent estimation tool — NOT an engineering-grade
// design (that would require irradiance data per city/season, roof
// orientation/shading, inverter derating curves, etc., none of which this
// app collects). Assumptions are documented inline. This mirrors the
// original frontend-only formula (audited in AUDIT_REPORT.md) but now runs
// server-side so the recommendation/pricing pipeline has one source of
// truth instead of being duplicated or spoofable from the browser.
// ==========================================================================
import { HttpError } from "../router.js";

const PANEL_WATTAGE = 450; // W, typical residential panel used across the catalog
const AVG_PEAK_SUN_HOURS = 4.2; // rough Iran-average full-sun-equivalent hours/day
const PANEL_AREA_M2 = 2.1; // approx area per panel, used for roof-area constraint
const PRICE_PER_TOMAN_KWH_ESTIMATE = 4200; // fallback tariff used only if monthlyUsage is omitted

export function calculateSolarSystem(input) {
  const monthlyBillToman = Number(input.monthlyBill) || 0;
  const roofArea = Number(input.roofArea) || 0;
  const independence = Number(input.independence) || 80;

  if (monthlyBillToman < 0) throw new HttpError(400, "monthlyBill cannot be negative");
  if (roofArea < 0) throw new HttpError(400, "roofArea cannot be negative");

  const monthlyUsageKwh =
    Number(input.monthlyUsage) > 0
      ? Number(input.monthlyUsage)
      : Math.round(monthlyBillToman / PRICE_PER_TOMAN_KWH_ESTIMATE);

  const effectiveRoofArea = roofArea > 0 ? roofArea : 40; // documented default when unknown
  const targetCoverage = Math.min(Math.max(independence, 1), 100) / 100;

  const dailyConsumptionKwh = +(monthlyUsageKwh / 30).toFixed(1);
  const recommendedCapacityKw = +((dailyConsumptionKwh * targetCoverage) / AVG_PEAK_SUN_HOURS).toFixed(1);

  const estimatedPanelsByDemand = Math.max(3, Math.round((recommendedCapacityKw * 1000) / PANEL_WATTAGE));
  const maxPanelsByRoof = Math.max(3, Math.floor(effectiveRoofArea / PANEL_AREA_M2));
  const finalPanels = Math.min(estimatedPanelsByDemand, maxPanelsByRoof);
  const roofConstrained = estimatedPanelsByDemand > maxPanelsByRoof;

  const finalCapacityKw = +((finalPanels * PANEL_WATTAGE) / 1000).toFixed(1);
  const monthlyProductionKwh = Math.round(finalCapacityKw * AVG_PEAK_SUN_HOURS * 30);
  const coveragePercent = Math.min(100, Math.round((monthlyProductionKwh / (monthlyUsageKwh || 1)) * 100));

  const batteryRecommendationKwh =
    finalCapacityKw <= 3 ? 0 : finalCapacityKw <= 6 ? 5 : finalCapacityKw <= 10 ? 10 : 15;

  const suggestedPackageId =
    finalCapacityKw <= 3
      ? "pkg-starter"
      : finalCapacityKw <= 6
      ? "pkg-home"
      : finalCapacityKw <= 9
      ? "pkg-plus"
      : finalCapacityKw <= 14
      ? "pkg-advanced"
      : "pkg-commercial";

  return {
    dailyConsumptionKwh,
    monthlyConsumptionKwh: monthlyUsageKwh,
    recommendedCapacityKw: finalCapacityKw,
    estimatedPanels: finalPanels,
    monthlyProductionKwh,
    coveragePercent,
    batteryRecommendationKwh,
    suggestedPackageId,
    roofConstrained,
    assumptions: {
      panelWattage: PANEL_WATTAGE,
      avgPeakSunHours: AVG_PEAK_SUN_HOURS,
      panelAreaM2: PANEL_AREA_M2,
      tariffTomanPerKwh: PRICE_PER_TOMAN_KWH_ESTIMATE,
    },
  };
}

// ---------------------------------------------------------------------------
// 12-month bill simulator
// Transparent seasonal model — NOT an engineering guarantee.
// Seasonal factors approximate Iran's solar seasonality (higher in summer).
// ---------------------------------------------------------------------------
const MONTH_LABELS_FA = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

const SEASONAL_SOLAR = [1.05, 1.15, 1.25, 1.30, 1.28, 1.15, 1.00, 0.85, 0.70, 0.65, 0.72, 0.90];
const SEASONAL_CONSUMPTION = [0.95, 1.00, 1.10, 1.20, 1.25, 1.15, 1.00, 0.95, 0.90, 0.95, 1.00, 0.95];

export function simulate12MonthBill(input) {
  const sizing = calculateSolarSystem(input);
  const monthlyUsageBase = sizing.monthlyConsumptionKwh;
  const capacityKw = sizing.recommendedCapacityKw;
  const tariff = PRICE_PER_TOMAN_KWH_ESTIMATE;
  const basePeakSun = AVG_PEAK_SUN_HOURS;
  const CONSERVATIVE_FACTOR = 0.82;

  const months = MONTH_LABELS_FA.map((label, i) => {
    const consumptionKwh = Math.round(monthlyUsageBase * SEASONAL_CONSUMPTION[i]);
    const productionExpected = Math.round(capacityKw * basePeakSun * 30 * SEASONAL_SOLAR[i]);
    const productionConservative = Math.round(productionExpected * CONSERVATIVE_FACTOR);

    const gridExpected = Math.max(0, consumptionKwh - productionExpected);
    const gridConservative = Math.max(0, consumptionKwh - productionConservative);

    const billCurrent = Math.round(consumptionKwh * tariff);
    const billExpected = Math.round(gridExpected * tariff);
    const billConservative = Math.round(gridConservative * tariff);

    const savingsExpected = billCurrent - billExpected;
    const savingsConservative = billCurrent - billConservative;

    const coverageExpected = Math.min(100, Math.round((productionExpected / (consumptionKwh || 1)) * 100));
    const coverageConservative = Math.min(100, Math.round((productionConservative / (consumptionKwh || 1)) * 100));

    return {
      monthIndex: i + 1,
      label,
      consumptionKwh,
      productionExpectedKwh: productionExpected,
      productionConservativeKwh: productionConservative,
      billCurrentToman: billCurrent,
      billExpectedToman: billExpected,
      billConservativeToman: billConservative,
      savingsExpectedToman: savingsExpected,
      savingsConservativeToman: savingsConservative,
      coverageExpectedPercent: coverageExpected,
      coverageConservativePercent: coverageConservative,
    };
  });

  const sum = (key) => months.reduce((acc, m) => acc + m[key], 0);

  const annual = {
    consumptionKwh: sum("consumptionKwh"),
    productionExpectedKwh: sum("productionExpectedKwh"),
    productionConservativeKwh: sum("productionConservativeKwh"),
    billCurrentToman: sum("billCurrentToman"),
    billExpectedToman: sum("billExpectedToman"),
    billConservativeToman: sum("billConservativeToman"),
    savingsExpectedToman: sum("savingsExpectedToman"),
    savingsConservativeToman: sum("savingsConservativeToman"),
  };

  return {
    sizing,
    months,
    annual,
    assumptions: {
      ...sizing.assumptions,
      tariffTomanPerKwh: tariff,
      seasonalSolarFactors: SEASONAL_SOLAR,
      seasonalConsumptionFactors: SEASONAL_CONSUMPTION,
      conservativeDerate: CONSERVATIVE_FACTOR,
      note:
        "این اعداد تخمینی هستند و بر اساس میانگین ایران، تعرفه تقریبی و عوامل فصلی ساده‌سازی‌شده محاسبه شده‌اند. " +
        "سایه، جهت سقف، گردوغبار و تعرفه واقعی قبض شما می‌تواند نتیجه را تغییر دهد.",
    },
    disclaimer: "ESTIMATED — نه تضمین مهندسی",
  };
}
