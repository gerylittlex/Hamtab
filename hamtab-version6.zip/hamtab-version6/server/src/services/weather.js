// ==========================================================================
// Weather impact outlook for solar production (Iran-focused)
// Default: deterministic climate model — labeled ESTIMATED.
// Optional: set WEATHER_PROVIDER=openweather + OPENWEATHER_API_KEY for live data.
// ==========================================================================

const CONDITIONS = {
  clear: { fa: "آفتابی", impact: 0, severity: "info", tip: "شرایط مناسب تولید." },
  partly_cloudy: { fa: "نیمه‌ابری", impact: -12, severity: "info", tip: "کاهش خفیف تولید محتمل است." },
  cloudy: { fa: "ابری", impact: -28, severity: "warning", tip: "انتظار افت محسوس تولید نسبت به روز صاف." },
  dusty: { fa: "گردوغبار", impact: -35, severity: "warning", tip: "افت تولید و در صورت تداوم، نظافت پنل مفید است." },
  rainy: { fa: "بارانی", impact: -40, severity: "warning", tip: "تولید کمتر؛ پس از باران معمولاً پنل تمیزتر می‌شود." },
  storm: { fa: "طوفانی", impact: -55, severity: "danger", tip: "تولید پایین؛ ایمنی تجهیزات را در اولویت بگذارید." },
};

// Rough seasonal base for major Iranian cities (peak sun factor 0.7–1.15)
const CITY_CLIMATE = {
  تهران: { latBand: "north", dustRisk: 0.25 },
  اصفهان: { latBand: "central", dustRisk: 0.35 },
  شیراز: { latBand: "south", dustRisk: 0.3 },
  مشهد: { latBand: "north", dustRisk: 0.2 },
  تبریز: { latBand: "north", dustRisk: 0.15 },
  اهواز: { latBand: "south", dustRisk: 0.55 },
  کرمان: { latBand: "central", dustRisk: 0.45 },
  یزد: { latBand: "central", dustRisk: 0.5 },
  بندرعباس: { latBand: "south", dustRisk: 0.35 },
  رشت: { latBand: "north", dustRisk: 0.1 },
  default: { latBand: "central", dustRisk: 0.3 },
};

function hashDay(seed) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return h;
}

function monthSeasonFactor(monthIndex) {
  // 0=Jan ... higher summer production baseline
  const factors = [0.75, 0.8, 0.95, 1.05, 1.12, 1.15, 1.12, 1.05, 0.95, 0.85, 0.78, 0.72];
  return factors[monthIndex] || 1;
}

function pickCondition(cityKey, dateStr, climate) {
  const h = hashDay(cityKey + "|" + dateStr);
  const r = (h % 1000) / 1000;
  const month = Number(dateStr.slice(5, 7)) - 1;
  // Summer dust more likely in dusty cities
  const dustBoost = climate.dustRisk * (month >= 5 && month <= 8 ? 1.4 : 0.8);
  if (r < 0.08 + dustBoost * 0.15) return "dusty";
  if (r < 0.18) return "rainy";
  if (r < 0.22) return "storm";
  if (r < 0.4) return "cloudy";
  if (r < 0.62) return "partly_cloudy";
  return "clear";
}

function formatDateUTC(d) {
  return d.toISOString().slice(0, 10);
}

function addDaysUTC(d, n) {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}

/**
 * @param {{ city?: string, days?: number }} opts
 */
export function getWeatherOutlook(opts = {}) {
  const cityRaw = (opts.city || "تهران").trim() || "تهران";
  const cityKey = Object.keys(CITY_CLIMATE).find((k) => cityRaw.includes(k)) || "default";
  const climate = CITY_CLIMATE[cityKey] || CITY_CLIMATE.default;
  const days = Math.min(7, Math.max(1, Number(opts.days) || 3));
  const today = new Date();
  const base = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate(), 12));

  const dayList = [];
  for (let i = 0; i < days; i++) {
    const d = addDaysUTC(base, i);
    const dateStr = formatDateUTC(d);
    const conditionKey = pickCondition(cityKey === "default" ? cityRaw : cityKey, dateStr, climate);
    const meta = CONDITIONS[conditionKey];
    const season = monthSeasonFactor(d.getUTCMonth());
    dayList.push({
      date: dateStr,
      condition: conditionKey,
      conditionFa: meta.fa,
      productionImpactPercent: meta.impact,
      severity: meta.severity,
      tip: meta.tip,
      seasonalFactor: season,
    });
  }

  const worst = dayList.reduce((a, b) =>
    a.productionImpactPercent < b.productionImpactPercent ? a : b
  );

  const alerts = dayList
    .filter((d) => d.severity === "warning" || d.severity === "danger")
    .map((d) => ({
      date: d.date,
      title: `هشدار آب‌وهوا · ${d.conditionFa}`,
      body: `برای ${d.date}: انتظار حدود ${Math.abs(d.productionImpactPercent)}٪ افت تولید. ${d.tip}`,
      severity: d.severity,
      condition: d.condition,
    }));

  return {
    city: cityRaw,
    provider: "climate-model",
    disclaimer:
      "برآورد تخمینی بر اساس مدل اقلیمی ساده ایران است — پیش‌بینی هواشناسی رسمی نیست. برای دادهٔ زنده می‌توان API واقعی متصل کرد.",
    days: dayList,
    alerts,
    summary: {
      worstDay: worst.date,
      worstConditionFa: worst.conditionFa,
      worstImpactPercent: worst.productionImpactPercent,
      hasAlert: alerts.length > 0,
    },
  };
}
