// ==========================================================================
// HamTab — Development telemetry simulator
// ==========================================================================
// No real inverter/controller hardware or IoT gateway is available in this
// build environment. Per the project rules (never silently fake production
// telemetry), this simulator:
//   - only runs when ENABLE_TELEMETRY_SIMULATOR=true (defaults to true in
//     development, and MUST be false in production — see .env.example)
//   - writes rows tagged source='dev-simulator' into the same `telemetry`
//     table a real device would use via POST /api/controller/:id/ingest
//     (source='device'), so the dashboard/controller UI can show clearly
//     which mode it is in instead of pretending it's live hardware.
// ==========================================================================
import { db } from "../db.js";
import { newId } from "../crypto-utils.js";

const insertTelemetry = db.prepare(`
  INSERT INTO telemetry (id, system_id, solar_production_kw, home_consumption_kw, battery_percent, grid_usage_kw, source, created_at)
  VALUES (?, ?, ?, ?, ?, ?, 'dev-simulator', datetime('now'))
`);
const insertTelemetryAutoId = db.prepare(`
  INSERT INTO telemetry (system_id, solar_production_kw, home_consumption_kw, battery_percent, grid_usage_kw, source)
  VALUES (?, ?, ?, ?, ?, 'dev-simulator')
`);
const listActiveSystems = db.prepare("SELECT id, capacity_kw, battery_percent FROM solar_systems WHERE status = 'ACTIVE'");
const updateSystemBattery = db.prepare("UPDATE solar_systems SET battery_percent = ? WHERE id = ?");
const latestForSystem = db.prepare(
  "SELECT * FROM telemetry WHERE system_id = ? ORDER BY created_at DESC, id DESC LIMIT 1"
);

function clamp(v, min, max) {
  return Math.min(max, Math.max(min, v));
}

function nextTick(system, prev) {
  const hour = new Date().getHours();
  const daylight = hour >= 6 && hour <= 19;
  const sunFactor = daylight ? Math.max(0, Math.sin(((hour - 6) / 13) * Math.PI)) : 0;

  const maxProd = system.capacity_kw;
  const prevProd = prev ? prev.solar_production_kw : maxProd * sunFactor;
  const solar = clamp(prevProd + (Math.random() - 0.5) * 0.4, 0, maxProd * (sunFactor + 0.05));

  const prevCons = prev ? prev.home_consumption_kw : 1.5;
  const consumption = clamp(prevCons + (Math.random() - 0.5) * 0.3, 0.3, maxProd + 2);

  const prevBattery = prev ? prev.battery_percent : system.battery_percent;
  const batteryDelta = (solar - consumption) * 0.8; // rough charge/discharge coupling
  const battery = clamp(prevBattery + batteryDelta, 5, 100);

  const grid = Math.max(0, +(consumption - solar).toFixed(2));

  return {
    solar_production_kw: +solar.toFixed(2),
    home_consumption_kw: +consumption.toFixed(2),
    battery_percent: +battery.toFixed(1),
    grid_usage_kw: grid,
  };
}

let timer = null;

export function startTelemetrySimulator({ intervalMs = 5000 } = {}) {
  if (timer) return;
  timer = setInterval(() => {
    const systems = listActiveSystems.all();
    for (const system of systems) {
      const prev = latestForSystem.get(system.id);
      const point = nextTick(system, prev);
      insertTelemetryAutoId.run(
        system.id,
        point.solar_production_kw,
        point.home_consumption_kw,
        point.battery_percent,
        point.grid_usage_kw
      );
      updateSystemBattery.run(point.battery_percent, system.id);
    }
  }, intervalMs);
  timer.unref?.();
  console.log(`[telemetry-simulator] running (dev-only, tagged source='dev-simulator'), interval=${intervalMs}ms`);
}

export function stopTelemetrySimulator() {
  if (timer) clearInterval(timer);
  timer = null;
}
