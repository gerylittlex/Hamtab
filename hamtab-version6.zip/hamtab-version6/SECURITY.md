# SECURITY.md

## Findings from the original prototype → fix in this rebuild

| # | Finding | Fix |
|---|---|---|
| 1 | Hardcoded `isAuthenticated: true`, no real auth | scrypt-hashed passwords, HMAC-signed tokens, real register/login (`routes/auth.js`) |
| 2 | No authorization / IDOR concept | Every owned resource checked against `req.user.id` server-side (`routes/orders.js`, `routes/systems.js`, `routes/notifications.js`); tested in `tests/orders.test.js` |
| 3 | Client-authoritative pricing | Order price is looked up from `packages` server-side; request-body `price` is ignored (tested) |
| 4 | Fake payment success | Real (if simulated) payment adapter, verified server-side, transactionally tied to order state (`services/payment-adapter.js`) |
| 5 | No input validation | `src/validate.js`, used on every route that accepts a body |
| 6 | No rate limiting | Fixed-window limiter on `/api/auth/*` (`middleware/rate-limit.js`) |
| 7 | No security headers / CSP | Set on every response in `server.js` |

## Threats reviewed

- **SQL injection**: every query is a `node:sqlite` prepared statement
  with bound parameters — there is no string-concatenated SQL anywhere
  in the codebase (grep `db.exec` vs `db.prepare` to verify: `exec` is
  only ever called with static DDL from `db.js`/migrations, never with
  request data).
- **XSS**: the frontend is unchanged server-rendered-free static HTML;
  page scripts that inject user-supplied strings into `innerHTML`
  (package names, neighborhood names, notification text) all originate
  from this backend, which does not currently HTML-escape them
  server-side. **Known gap**: if you add free-text fields a user can set
  (e.g. neighborhood name) and display them elsewhere, escape on output.
  Today's user-controlled strings (name, address) are only ever
  rendered into `.textContent`/form `value`, not `innerHTML` — verified
  by inspection of `dashboard.js`/`api-client.js` — but this should be a
  standing review item as the UI grows.
- **CSRF**: not applicable in the classic cookie-session sense — auth is
  a bearer token the frontend attaches explicitly via JS
  (`Authorization` header), not an ambient cookie the browser would
  attach automatically to a cross-site request.
- **IDOR/BOLA**: see finding #2 above; explicitly tested.
- **Auth bypass**: `requireAuth` throws before any handler body runs if
  the token is missing, malformed, expired, or its `token_version`
  doesn't match the current DB value (covers "log out everywhere" and
  password-change revocation).
- **Password handling**: scrypt (CPU/memory-hard), unique salt per user,
  `timingSafeEqual` comparison, min length 8 enforced server-side.
  Password hashes/salts are never returned by any endpoint (`publicUser`
  / row-mapping functions explicitly whitelist fields).
- **Secrets**: `SESSION_SECRET` required via env var in production (the
  process throws on boot without it); `.env.example` documents every
  variable, `.env` is gitignored; no secret is logged.
- **Rate limiting**: in-memory fixed-window limiter on auth endpoints
  (10 req/min/IP) to slow down credential stuffing / registration abuse.
  Documented in `DEPLOYMENT.md` as needing a shared store behind more
  than one process/instance.
- **Request size**: body reads are capped at 2 MB (`router.js`) to avoid
  a trivial memory-exhaustion DoS via a huge JSON body.
- **Path traversal**: the static file server resolves the requested path
  and rejects anything that escapes the frontend root directory
  (`server.js` `serveStatic`).
- **Dependency vulnerabilities**: N/A by construction — the backend has
  **zero third-party npm dependencies** (see `ARCHITECTURE.md` §1), so
  there is no dependency tree to audit for this build.
- **CORS**: not configured because it's not needed — frontend and API
  are served from the same origin/process. If you ever split them onto
  different origins, you'll need to add explicit CORS handling (and
  probably move off bearer-token-in-JS to something with CSRF
  protection if you also add cookies).

## What wasn't (and shouldn't be) done here

No admin panel, no file uploads, no third-party OAuth — none of these
exist in the product surface, so there's nothing to secure yet. If
they're added later, they need their own review (upload validation /
storage isolation, OAuth state/PKCE, admin-route authorization tests).
