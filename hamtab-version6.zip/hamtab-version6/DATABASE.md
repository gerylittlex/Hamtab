# DATABASE.md

Engine: **SQLite**, via Node 22's built-in `node:sqlite` (no external
driver). File: `server/data/hamtab.db` (WAL mode). Tests use `:memory:`
(`NODE_ENV=test`, see `server/tests/helpers.js`).

## Schema

### `users`
`id, name, email (UNIQUE), phone, password_hash, password_salt, address,
install_location, role (USER|ADMIN), token_version, created_at, updated_at`

### `packages`
`id, name, tier, capacity_kw, panels, battery_kwh, daily_production_kwh,
price, usage_desc, home_size, install_availability, warranty, roi,
components_json, popular, status (ACTIVE|DISCONTINUED), created_at`
Seeded from `server/seed.js` (moved out of the old frontend
`mock-data.js`, which is the source these values were audited against).

### `solar_calculations`
`id, user_id → users (SET NULL), input_json, result_json,
suggested_package_id → packages, created_at`
Every calculator call is logged here, whether or not the caller is
authenticated.

### `orders`
`id, user_id → users (CASCADE), package_id → packages, package_name,
price, address, status (PENDING|PAID|CONFIRMED|SCHEDULED|INSTALLING|
INSTALLED|ACTIVE|CANCELLED), payment_status (UNPAID|PAID|FAILED|
REFUNDED), idempotency_key (UNIQUE), created_at, updated_at`
`price` and `package_name` are **snapshotted at order time** — if a
package's price changes later, past orders keep the price the customer
actually agreed to.

### `payments`
`id, order_id → orders (CASCADE), provider, status (PENDING|SUCCEEDED|
FAILED), amount, raw_response (JSON), created_at`
One row per charge attempt (a failed attempt doesn't block a retry).

### `solar_systems`
`id, user_id → users (CASCADE), order_id → orders, package_id →
packages, package_name, capacity_kw, status (PENDING_INSTALL|ACTIVE|
OFFLINE), installed_on, total_generated_kwh, total_saved_toman,
battery_percent, modes_json, created_at`
Created automatically when an order's payment succeeds.

### `telemetry`
`id (autoincrement), system_id → solar_systems (CASCADE),
solar_production_kw, home_consumption_kw, battery_percent,
grid_usage_kw, source ('dev-simulator'|'device'), created_at`
Indexed on `(system_id, created_at DESC)` for the "latest reading" and
hourly-average queries. `source` is what lets the UI (and this document)
be honest about which readings are simulated vs. real hardware.

### `notifications`
`id, user_id → users (CASCADE), title, body, type (info|success|warning|
error), is_read, created_at`. Indexed on `(user_id, created_at DESC)`.

### `neighborhoods`
`id, name, city, required, estimated_panels, estimated_kw, status,
created_at`

### `neighborhood_participants`
`id, neighborhood_id → neighborhoods (CASCADE), user_id → users
(CASCADE), joined_at`, **`UNIQUE(neighborhood_id, user_id)`** — this
constraint, not application code, is what makes double-joining
impossible even under concurrent requests.

### `neighborhood_activity`
`id (autoincrement), neighborhood_id → neighborhoods (CASCADE), text,
created_at` — a simple activity feed, appended to on create/join.

## Migrations

There is no numbered-migration system. `migrate()` in `src/db.js` runs
idempotent `CREATE TABLE IF NOT EXISTS` statements on every server
start, plus a small `ensureColumn()` helper for additive changes made
after the initial schema (currently just `solar_systems.modes_json`).
This is a deliberate simplification for a project this size — documented
here as a known limitation rather than hidden. A larger project should
move to numbered migration files (e.g. `migrations/0001_init.sql`,
`0002_add_modes.sql`, ...) applied in order and tracked in a
`schema_migrations` table.

## Seeding

`npm run seed` (`server/seed.js`) inserts the 5 packages and 6 example
neighborhoods, using `ON CONFLICT DO UPDATE` / `DO NOTHING` so it's safe
to run repeatedly.

## Backups

SQLite is a single file. For a real deployment, back up
`server/data/hamtab.db` (and its `-wal`/`-shm` siblings, or run
`PRAGMA wal_checkpoint(TRUNCATE)` first) on a schedule — see
`DEPLOYMENT.md`.
