# TESTING.md

## What exists

Automated: `server/tests/*.test.js`, run with Node's built-in test
runner (`npm test` inside `server/`, or `node --test tests/*.test.js`).
No test framework dependency needed. **11/11 passing** as of this
writing — actually run, not just described (see the transcript this
build produced, reproducible by running the command yourself).

| File | Covers |
|---|---|
| `tests/auth.test.js` | Register → login → `/me`; duplicate email rejected; wrong password rejected; weak password / bad email rejected |
| `tests/orders.test.js` | **Price tampering ignored** (server-authoritative pricing); unauthenticated order creation rejected; **IDOR**: user B gets 403 reading user A's order; **idempotency key** prevents duplicate orders on retry; paying an order provisions a system + notification, and double-payment is rejected |
| `tests/neighborhoods_and_calculator.test.js` | **Duplicate neighborhood join rejected** (409) even from a second, distinct join call; calculator is deterministic (same input → same output, twice) and rejects negative input |

Each test spins up a real instance of the router against an in-memory
SQLite DB (`NODE_ENV=test`) on an ephemeral port and talks to it over
real HTTP via `fetch` — these are integration tests, not mocks of the
router.

## What was verified manually (not automated)

- Full static file serving + API on one process, smoke-tested with curl:
  every page returns 200, a bad path returns 404, security headers are
  present (transcript captured during this build).
- End-to-end critical flow via curl: register → login → calculate →
  create order (401 unauthenticated, then 201 authenticated,
  price-tamper attempt ignored) → pay → system provisioned → IDOR
  blocked on a second account → notification present. All exercised
  against the real server process, not just unit-level.
- All frontend JS files pass `node --check` (syntax validity) — see
  build transcript.

## What is NOT covered (be honest about gaps)

- **No headless-browser / E2E test** (e.g. Playwright) driving the
  actual rendered pages — this environment has no network access to
  install one, and none shipped with Node. The manual curl-based
  end-to-end pass above substitutes for the "critical flow" check but
  does not click through the real DOM/forms.
- **No responsive/visual regression testing** — the CSS was not
  modified from the original prototype (see AUDIT_REPORT §5), so this
  wasn't re-verified pixel-by-pixel at each breakpoint; it also wasn't
  broken by anything in this rebuild.
- **No load/performance testing.**
- **Payment failure path** is covered by the adapter's deterministic
  test-failure hook (`amount % 1000 === 13`) but there's no dedicated
  test asserting the order ends up `payment_status: FAILED` after a
  forced decline — worth adding.

## Running the tests yourself

```bash
cd server
npm test
```
