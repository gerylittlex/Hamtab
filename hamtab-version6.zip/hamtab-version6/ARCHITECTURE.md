# ARCHITECTURE.md

## 1. Stack, and why

| Layer | Choice | Why |
|---|---|---|
| Frontend | Existing vanilla HTML/CSS/JS, unchanged in structure | Already worked; no migration justification (see AUDIT_REPORT §6) |
| Backend | Node.js, **built-in `http` only** (no Express) | See "Why no npm packages" below |
| Database | **`node:sqlite`** (Node 22's built-in SQLite binding) | Real relational DB, real constraints/transactions, zero install |
| Auth | scrypt password hashing + HMAC-signed stateless tokens, both via `node:crypto` | No bcrypt/jsonwebtoken available; these are the same primitives those libraries wrap |
| Payments | Adapter interface; dev-simulator by default | No real provider specified, no credentials available (§15, §32 of the brief) |
| Tests | `node --test` (Node's built-in test runner) | No Jest/Mocha available; built-in runner needs nothing extra |

### Why no npm packages
This environment has **no network access** (`npm install` returns `403
Forbidden` against the registry — verified before writing a line of
backend code). Rather than leave the "real backend" requirement unmet,
everything was built on what Node 22 ships with. This is a deliberate
constraint, not a preference — if you deploy this somewhere with registry
access, you could swap in Express/Prisma/etc., but there is no functional
gap today: routing, validation, hashing, tokens, and persistence are all
real and covered by tests.

`node:sqlite` is still labeled **experimental** by Node.js. It behaved
correctly through the whole test suite and manual smoke tests, but pin
your Node version in production and watch the Node changelog — see
`DEPLOYMENT.md`.

## 2. Request flow

```
Browser (static HTML/CSS/JS, served from the same origin)
   │  fetch('/api/...', { headers: { Authorization: 'Bearer <token>' } })
   ▼
server/server.js  — one process, one port
   ├─ /api/*  → server/src/router.js → route handlers (server/src/routes/*.js)
   │              └─ middleware/auth.js (token verify, ownership checks)
   │              └─ validate.js (input validation)
   │              └─ node:sqlite prepared statements (server/src/db.js)
   └─ everything else → static file server (serves ../index.html, ../pages, ../css, ../js)
```

Single origin (frontend + API share one Node process/port) — deliberately
avoids CORS entirely rather than configuring it.

## 3. Auth

- Passwords: `scrypt(password, salt)`, random 16-byte salt per user,
  timing-safe comparison on login.
- Sessions: stateless, HMAC-SHA256-signed tokens (`base64url(payload) +
  "." + signature`), 7-day expiry, carried as `Authorization: Bearer
  <token>`. No session table to join on every request.
- Revocation: each user has a `token_version` column. "Log out
  everywhere" or a password change increments it, which invalidates
  every previously issued token instantly (their embedded `tv` no longer
  matches) without a token blocklist.
- `SESSION_SECRET` must be set via environment variable in production;
  the process refuses to start without one (`src/crypto-utils.js`).

## 4. Authorization / anti-IDOR

Every resource with an owner (`orders`, `solar_systems`, `notifications`)
is fetched with a `WHERE id = ?` and then explicitly checked against
`req.user.id` before being returned — see `ownedSystem()` in
`routes/systems.js` and the ownership checks in `routes/orders.js` and
`routes/notifications.js`. Verified with an automated test
(`tests/orders.test.js`: user B gets `403` reading user A's order).

## 5. Data flow: pricing & payments

```
packages table (backend-owned)
   │
   ▼
POST /api/orders { packageId }   ←── price NEVER read from the request body
   │  price = packages.price (server lookup)
   ▼
orders row (PENDING / UNPAID)
   │
POST /api/orders/:id/pay
   ▼
services/payment-adapter.js
   ├─ dev-simulator (default): synchronous sandbox-style charge()
   └─ ProductionAdapter: throws — refuses to fabricate a result — until a
      real provider is wired in
   │
   ▼ (on SUCCEEDED, inside a DB transaction)
orders.payment_status = PAID, orders.status = CONFIRMED
solar_systems row created (this user now "owns" an active system)
notifications row created
```

## 6. Controller / telemetry architecture

```
solar_systems (1) ── (many) telemetry
                         ▲                    ▲
                         │                    │
          dev-simulator (interval,     POST /api/systems/:id/ingest
          tagged source='dev-simulator') (tagged source='device' —
                                          the real integration point,
                                          unexercised here: no hardware
                                          available in this environment)
```

`GET /api/systems/:id/controller` reads the latest telemetry row and
classifies it `LIVE` (<15s old) / `STALE` (<5min) / `DISCONNECTED` /
`UNKNOWN` (no data yet) purely from the timestamp — the frontend polls
this every 5s and reflects that state instead of assuming "live" forever.

## 7. Database

See `DATABASE.md` for the full schema. Highlights:
- Foreign keys are ON (`PRAGMA foreign_keys = ON`), with `ON DELETE
  CASCADE`/`SET NULL` chosen per relationship.
- `neighborhood_participants` has `UNIQUE(neighborhood_id, user_id)` —
  the actual mechanism preventing duplicate joins, not just app logic
  (verified in `tests/neighborhoods_and_calculator.test.js` under a
  double-join attempt).
- `orders.idempotency_key` is `UNIQUE` — a retried "place order" request
  with the same `Idempotency-Key` header returns the original order
  instead of creating a duplicate.

## 8. What "solar system" calculation logic runs where

The calculator (`services/calculator.js`) is intentionally simple and
**documents its assumptions in its own response** (`result.assumptions`)
rather than presenting a rough estimate as engineering-grade. It now runs
server-side so the recommended package / capacity can't be spoofed from
devtools before an order is placed.

## 9. Deliberately not built

- **Admin panel** — nothing in the brief's product surface required one
  beyond what the `role: 'ADMIN'` column and `requireAdmin` middleware
  already support; building a full admin UI would have been scope
  invention (§39 of the brief explicitly warns against this).
- **Real payment/IoT integration** — no credentials or hardware exist in
  this environment; the adapter boundary is real and tested, the actual
  provider/device call is not (see FINAL_REPORT.md "Remaining").
- **SEO/OG tags, sitemap** — the app is entirely behind interaction (no
  public content pages beyond the landing page); low value for the time
  it would cost versus the sections above.
