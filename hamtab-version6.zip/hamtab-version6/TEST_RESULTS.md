# TEST_RESULTS.md

## Environment

- Node.js v24.15.0
- OS: Linux (container)
- Database for automated tests: `:memory:` (via `NODE_ENV=test`)
- Database for manual API checks: `/tmp/hamtab-audit.db` (`DB_PATH` override)
- Command: `cd server && npm test` → `NODE_ENV=test node --test tests/*.test.js`

## Automated suite

| Test name | Feature / flow | Expected | Actual | Status |
|-----------|----------------|----------|--------|--------|
| register -> login -> me | Auth | Token issued; `/me` returns user | Same | PASS |
| weak password / bad email rejected | Auth validation | 400 responses | Same | PASS |
| joining a neighborhood twice is rejected | Neighborhoods UNIQUE | Second join fails | Same | PASS |
| solar calculator returns deterministic, non-random results | Calculator | Stable output for same input | Same | PASS |
| calculator rejects negative input | Calculator validation | 400 | Same | PASS |
| order creation ignores client-supplied price | Orders | Price from packages table | Same | PASS |
| unauthenticated order creation is rejected | Authz | 401 | Same | PASS |
| a user cannot read another user's order (IDOR) | Authz | 403 | Same | PASS |
| idempotency key prevents duplicate orders | Orders | Second request returns same order | Same | PASS |
| paying an order provisions a solar system and a notification | Pay flow | System + notification created | Same | PASS |
| a forced-decline test payment leaves the order unpaid | Pay failure | Order remains unpaid | Same | PASS |

**Summary:** 11 passed, 0 failed.

## Manual API checks (this audit)

- `GET /` → 200 (index.html)
- `GET /api/packages` → 5 packages
- Register + login → token
- Create order + pay → order CONFIRMED/PAID, system ACTIVE
- `GET /api/systems` → provisioned system listed
- `POST /api/solar/calculate` → deterministic result
- `GET /api/neighborhoods` → seeded list

## Limitations

- No browser-driven E2E (Playwright/Cypress) in this environment.
- No visual/responsive automated checks.
- No load or security fuzzing beyond the intentional integration cases.
- Payment gateway is the development simulator only.
