# AUDIT_REPORT.md — HamTab, as received

## 1. What was actually in the ZIP

A static, front-end-only prototype. No `package.json`, no build step, no
server, no database. Six HTML pages, ~2,600 lines of vanilla JS, ~2,300
lines of CSS. Persian (RTL), consistent visual identity (Vazirmatn font,
navy/orange palette defined as CSS custom properties).

| File | Lines | Role |
|---|---|---|
| `index.html` | 288 | Landing page |
| `pages/calculator.html` + `js/pages/calculator.js` | 224 + 132 | 3-step solar sizing wizard |
| `pages/projects.html` + `js/pages/projects.js` | 161 + 202 | Package catalog, filters, compare, detail modal |
| `pages/controller.html` + `js/pages/controller.js` | 195 + 139 | "Live" controller dashboard |
| `pages/dashboard.html` + `js/pages/dashboard.js` | 207 + 177 | User dashboard: overview / orders / profile / settings |
| `pages/neighborhood.html` + `js/pages/neighborhood.js` | 123 + 149 | Community "solar neighborhood" campaigns |
| `js/mock-data.js` | 290 | Every "API" call — in-memory arrays behind `setTimeout` |
| `js/components.js`, `navigation.js`, `animations.js`, `main.js` | ~600 | Toasts, modals, mobile nav, auth-state show/hide, counters |

## 2. Mock systems found

Everything in `js/mock-data.js`:

- `CURRENT_USER = { isAuthenticated: true, ... }` — **hardcoded**, no
  registration/login form existed anywhere in the UI.
- `getPackages`, `getOrders`, `getNotifications`, `getNeighborhoods` — plain
  JS arrays, reset on every page load.
- `calculateSolarSystem` — real formula, but ran entirely client-side, so a
  user could open devtools and get any recommendation/price they wanted.
- Order "placement" (`projects.js`) and profile/settings "save"
  (`dashboard.js`) called `HamTabUI.showToast({ title: "... شد" })` directly,
  with **no data mutation at all** — a textbook case of the "fake success
  toast" anti-pattern this rebuild was told to eliminate.
- Controller telemetry (`controller.js`) used a `setInterval` +
  `Math.random()` loop, indistinguishable in the UI from real hardware data.

## 3. Broken / disconnected functionality

- No `login.html` / `register.html` existed — `data-auth-only` elements
  (dashboard link, avatar) were always visible regardless of auth state
  because `isAuthenticated` was always `true`.
- Order and profile/settings forms did not persist anything, so a refresh
  silently discarded everything the user just did.
- The dashboard's "orders" list and the controller page had no relation to
  what a user actually selected in `projects.html` or `calculator.html` —
  each page's mock data was independent.
- No error, empty, or loading states beyond a couple of `setTimeout` delays
  — every action always "succeeded".

## 4. Security findings

| Issue | Evidence | Severity |
|---|---|---|
| No real authentication | `isAuthenticated: true` hardcoded | Critical |
| No authorization / IDOR protection | No user-scoped data existed to protect, but the architecture had no concept of ownership at all | Critical |
| Client-authoritative pricing | `calculateSolarSystem` and package prices ran/lived entirely in the browser | High |
| Fake payment success | Order flow ended at a toast, no payment step existed | High (by omission) |
| No input validation | Calculator form had only HTML5 `required`, nothing server-side (there was no server) | Medium |

All of the above are fixed in the rebuild — see `SECURITY.md`.

## 5. UX / responsive / accessibility

The existing design system (`css/variables.css`, `components.css`) is
solid and consistent — buttons, cards, form fields, modals, toasts, badges
are all already themed and reasonably accessible (visible focus states,
`skip-link`, semantic buttons). `css/responsive.css` covers the common
breakpoints. **This was preserved as-is**; no redesign was performed, per
the "don't rewrite what works" rule. Manual review at 360–1440px (see
`TESTING.md`) did not surface new issues introduced by this rebuild.

## 6. Decision: framework migration?

**No.** The vanilla JS/CSS front end works, is readable, and has no
architectural blocker to adding a real backend. Migrating it to
React/Vue would have meant rewriting ~2,600 lines of working UI code for
no functional gain — explicitly against the project's own rules (§40).
Instead, `js/mock-data.js` was replaced by `js/api-client.js` with the
**same call signatures**, so page scripts needed only the specific,
documented changes listed in `FINAL_REPORT.md` — not a rewrite.

## 7. What the backend had to become

Given the above, the highest-value, lowest-risk path was: add a real
backend + database behind the existing UI, replace every fake success
path with a real one, and add the auth/profile/order pages that never
existed. That is what was built — see `ARCHITECTURE.md`.
