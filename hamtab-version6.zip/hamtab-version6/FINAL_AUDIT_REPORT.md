# FINAL_AUDIT_REPORT.md — HamTab Full-Stack Audit

**Date:** 2026-09-19  
**Auditor role:** Independent full-stack engineering audit (architecture, security, QA, UX, production readiness)

## Executive summary

HamTab is a working full-stack Persian (RTL) solar-energy platform: vanilla HTML/CSS/JS frontend served by a zero-dependency Node.js HTTP server using built-in `node:sqlite`. Core business flows (register/login, package catalog, order + simulated payment, system provisioning, controller telemetry, neighborhoods, dashboard) are implemented and backed by a real database rather than client-side mocks.

The application is **not production-ready** for real payments or multi-instance deployment, but it is substantially more complete and safer than a typical prototype. Eleven automated integration tests pass against a live HTTP server and in-memory SQLite.

This audit confirmed prior claims where evidence existed, found and fixed several real defects, and documented remaining limitations honestly.

## Overall project condition

| Area | Condition |
|------|-----------|
| Product functionality | Core flows work end-to-end with real persistence |
| Frontend | Coherent RTL UI; data layer wired to API |
| Backend | Minimal, readable, zero third-party deps |
| Database | SQLite schema with FKs, ownership checks |
| Auth | scrypt + HMAC session tokens; rate-limited |
| Payments | Dev simulator only; production adapter refuses fake success |
| Telemetry | Dev simulator + device ingest endpoint |
| Security | Good baseline; residual XSS/open-redirect issues fixed in this audit |
| Tests | 11 integration tests, all passing |
| Production readiness | **Not ready** for real money or multi-node |

## Architecture overview

- **Frontend:** Static pages under `pages/`, shared CSS, `js/api-client.js` as the only data access layer.
- **Backend:** Single process (`server/server.js`) serves static assets and `/api/*` via a tiny custom router (no Express).
- **DB:** `node:sqlite` DatabaseSync; schema in `src/db.js`; seed in `seed.js`.
- **Auth:** Bearer tokens (HMAC-SHA256 over base64url payload), `token_version` invalidation.
- **Payments:** Adapter interface; `PAYMENT_PROVIDER=dev-simulator` by default.
- **Telemetry:** Optional interval simulator tagged `source: 'dev-simulator'`.

## Feature inventory (verified present)

- Registration / login / me / logout-everywhere / profile update / password change
- Solar calculator (server-side, deterministic)
- Package list / detail
- Order create (server-side price, idempotency key) / pay (simulator)
- Solar system provision on successful payment
- Controller view + modes update + device ingest
- Neighborhoods list / join / create (UNIQUE join constraint)
- Notifications list / mark read
- Dashboard overview, orders, profile, settings

## Audit scope

Inspected repository structure, all server routes, DB schema, auth/crypto, payment adapter, telemetry, frontend API client and page scripts, static HTML/CSS, existing tests, and documentation. Ran seed, full test suite, and live API E2E (register/login/order/pay/systems/calculator/neighborhoods). Static pages served successfully from the same process.

## Findings by severity

### Critical
- None confirmed that allow authentication bypass, arbitrary payment success, or unrestricted IDOR on owned resources. Prior work already enforced ownership checks (covered by tests).

### High
1. **Open redirect on login/register** (`?redirect=` accepted absolute URLs). **Fixed** in this audit via `safeRedirect()`.
2. **Payment success path not fully atomic** — payment row could be written before a failed system provision left order unpaid. **Fixed** — SUCCEEDED payment + order + system + notification now share one SQLite transaction.

### Medium
3. **Stored/reflected XSS risk** via `innerHTML` for notification title/body, package names, neighborhood names without HTML escaping. **Fixed** — `HamTabUI.escapeHtml` + `esc()` helpers in page scripts and toast rendering.
4. **Error toasts used `type: "error"`** which was not mapped to `toast-danger`, so failures appeared unstyled. **Fixed**.
5. **SQLite disk I/O failures on some overlay filesystems** when using default `server/data/` path (WAL). Worked on `/tmp`. Documented; `DB_PATH` env override added for flexibility.

### Low
6. Leftover empty directory `server/src/{routes,services,middleware}` from a bad mkdir. **Removed**.
7. Logout is client-only (token deleted locally); `logout-everywhere` exists but is not wired to the header button — acceptable for stateless tokens, but users may expect server-side invalidation.
8. In-memory rate limiter does not work across multiple processes.
9. No CSRF tokens (Bearer-only API; mitigated for pure SPA-style usage, not for cookie sessions — tokens are not in cookies).
10. CSP allows `'unsafe-inline'` for styles (required by current CSS/JS patterns).

## Confirmed bugs fixed in this audit

See `BUG_FIX_LOG.md`.

## Security findings (summary)

| Control | Status |
|---------|--------|
| Password hashing (scrypt + salt + timingSafeEqual) | Present |
| Session signing (HMAC) + expiry + token_version | Present |
| Auth rate limit | Present (per-process memory) |
| Parameterized SQL only | Present |
| IDOR checks on orders/systems/notifications | Present + tested |
| Server-authoritative package price | Present + tested |
| Path traversal on static files | Guarded |
| Security headers + CSP | Present |
| Open redirect | **Fixed** |
| HTML injection into UI | **Mitigated** |
| Real payment provider | Not configured (by design) |

## UX / responsive

Visual identity is consistent (Vazirmatn, navy/orange tokens). Auth pages exist and integrate with the API. Full visual regression across 375–1920px was not automated in this environment; responsive CSS files are present. Recommend manual device testing before launch.

## Performance

No Lighthouse run in this environment. Bundle is multi-file vanilla JS without a bundler — acceptable for this scale. Telemetry simulator polls every 5s when enabled.

## Testing coverage

11 integration tests (auth, calculator, neighborhoods, orders/IDOR/idempotency/pay). No frontend unit/E2E browser tests. No load tests.

## Unresolved / production blockers

- No real payment gateway credentials or webhook verification in production mode.
- Single-process assumptions (rate limit, SQLite file).
- `SESSION_SECRET` must be set in production (enforced).
- Telemetry simulator must be disabled in production.
- Overlay/FS environments may need `DB_PATH` pointed at a writable native filesystem.
- No automated backup/monitoring/observability stack.
- Admin role exists in schema but no admin UI/routes beyond role check helpers.

## Production-readiness limitations

See `PRODUCTION_READINESS.md`. Do **not** process real customer payments with the current adapter configuration.
